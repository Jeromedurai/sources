﻿using System.Linq;
using Amazon;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Sa.Common.CacheService;
using Sa.Common.CacheService.Repository;
using Sa.Common.SeriLog;
using Serilog.Parsing;
using XtraChef.API.Base.Startup;
using XtraChef.API.Base.Util;
using static Microsoft.AspNetCore.Razor.Language.TagHelperMetadata;

namespace XtraChef.API.Authentication
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Authentication.Startup"/> class.
        /// </summary>
        /// <param name="env"></param>
        public Startup(IWebHostEnvironment env)
        {

            //initialize the startup
            IConfigurationBuilder builder = XcBaseStartup.InitializeStartup(env);

            /*** Begin: API Specific Configuration ***/

            //set version number
            XcBaseStartup.Version = "1.3";

            //add user secrets
            builder.AddUserSecrets<Startup>();

            Configuration = builder.Build();

            Configuration["AWS.Logging:LogGroup"] = "XtraChef.API.Authentication";

            if (Configuration["ConnectionStrings:Default"] != null && Configuration["ConnectionStrings:Default"].Contains("MultipleActiveResultSets"))
            {
                Configuration["ConnectionStrings:Default"] = Configuration["ConnectionStrings:Default"].Replace("MultipleActiveResultSets=True;", "");
            }

            /*** End: API Specific Configuration ***/
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //initialize base services
            XcBaseStartup.InitializeServices(Configuration, services);

            services.AddMvc().AddNewtonsoftJson();

            services.AddDbContext<Context.Authentication>(options =>
            {
                options.UseSqlServer(XcUtil.DecryptConnection.SetConnectionString(Configuration["ConnectionStrings:Default"]));
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(XcBaseStartup.LoggerFactory);
            });

            //initialize scoped instances 
            services.AddScoped(typeof(XtraChef.API.Authentication.Services.Authentication), typeof(XtraChef.API.Authentication.Services.Authentication));
            services.AddScoped(typeof(XtraChef.API.Authentication.Repository.Authentication), typeof(XtraChef.API.Authentication.Repository.Authentication));
            services.AddMediatR(typeof(Sa.Common.SeriLog.LogNotificationHandler));
            services.AddSingleton<LogPublisher>();
            services.AddSingleton<Sa.Common.Aws.DynamoDB.DynamoDBService>(_ => new Sa.Common.Aws.DynamoDB.DynamoDBService(Configuration["AWS:AccessKey"], Configuration["AWS:SecretKey"], Amazon.RegionEndpoint.GetBySystemName(Sa.Common.Aws.Region.CurrentRegion)));
            services.AddSingleton(provider => new SaCacheRepository(provider.GetRequiredService<Sa.Common.Aws.DynamoDB.DynamoDBService>()));
            services.AddSingleton<ICacheService>(provider => new CacheService(
                Sa.Common.Cache.Factory.CacheFactory.CreateInstance(
                    provider.GetRequiredService<LogPublisher>(),
                    Configuration["AWS:ElastiCache:PrimaryEndpoint"],
                    Configuration["AWS:ElastiCache:ReaderEndpoint"]),
                provider.GetRequiredService<SaCacheRepository>()));

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(XcBaseStartup.Version, new OpenApiInfo { Title = "Authentication API", Version = XcBaseStartup.Version });
                c.CustomSchemaIds(i => i.FullName);
            });

            /*** End: API Specific Configuration ***/
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            app.UsePathBase(new PathString("/api.authentication-query")); //use CORS
            //initialize application with base pipeline
            XcBaseStartup.InitializeApplication(Configuration, app, env, loggerFactory);

            /*** Begin: API Specific Configuration ***/

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint($"/swagger/{XcBaseStartup.Version}/swagger.json", $"Authentication API v{XcBaseStartup.Version}");
            });

            /*** End: API Specific Configuration ***/
        }
    }

}
