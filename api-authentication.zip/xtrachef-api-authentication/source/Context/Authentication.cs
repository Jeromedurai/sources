﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using XtraChef.API.Base.Context;

namespace XtraChef.API.Authentication.Context
{
    public class Authentication : XcReadOnlyContext
    {
        #region Variables

        public DbSet<Model.ValidTokenContext> ValidTokenContexts { get; set; }

        #endregion

        #region Constructor 

        /// <summary>
        /// Constructor passing context T to the DbContext
        /// </summary>
        /// <param name="options">Options.</param>
        public Authentication(DbContextOptions<Context.Authentication> options) : base(options) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Ons the model creating.
        /// </summary>
        /// <param name="modelBuilder">Model builder.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //base constructor
            base.OnModelCreating(modelBuilder);
        }

        #endregion

    }
}
