﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using System.Linq;
using XtraChef.API.Base.Attribute;
using XtraChef.API.Base.Controller;
using XtraChef.API.Base.Core;
using XtraChef.API.Base.Model;
using XtraChef.API.Authentication.Services;
using XtraChef.API.Base.Service;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using System;
using XtraChef.API.Base.Model.Security;
using XtraChef.API.Authentication.Model;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace XtraChef.API.Authentication.Controllers
{
    [Route("api/1.0/[controller]")]
    public class AuthenticationController : XcBaseController<Services.Authentication>
    {
        #region Constructor

        public AuthenticationController(Services.Authentication service, IConfiguration configuration, ILoggerFactory loggerFactory) : base(service, configuration, loggerFactory)
        {
        }

        #endregion

        #region Overridden Methods

        #endregion

        #region Public Methods

        /// <summary>
        /// Generate the tenant token.
        /// </summary>
        /// <returns>The token.</returns>
        /// <param name="validationContext">Validation context.</param>
        [AllowAnonymous]
        [HttpPost]
        [Route("tenant-token")]
        [Produces("text/plain")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult GenerateTenantToken([FromBody] ValidationContext validationContext, [FromQuery]string userHostIpAddress = null, [FromQuery]string userAgent = null)
        {
            try
            {
                
                if (ModelState.IsValid)
                {
                    //validate the token context
                    this.Service.ValidateTokenContext(validationContext);

                    //string message;
                    Logger.LogInformation($"Valid token parameters: {validationContext}");

                    //generate a token
                    string token = this.Service.GenerateTenantToken(validationContext);

                    this.Service.PostClientDetails(Request, validationContext, userHostIpAddress, userAgent);

                    //return token
                    return StatusCode(StatusCodes.Status200OK, token);

                }
                else
                {
                    //return error
                    BadRequestObjectResult badObjectResult = new BadRequestObjectResult(ModelState);
                    this.Logger.LogError(badObjectResult.ToString());

                    return StatusCode(StatusCodes.Status400BadRequest, badObjectResult);
                }
            }
            catch (KeyNotFoundException ex)
            {
                //return error
                BadRequestObjectResult badObjectResult = new BadRequestObjectResult(ex.Message);

                return StatusCode(StatusCodes.Status400BadRequest, badObjectResult);
            }
            catch (System.Exception ex)
            {
                /*BadRequestObjectResult badObjectResult = new BadRequestObjectResult(ModelState);*/
                this.Logger.LogError($"error in generating token ({ex.Message}): {ex.InnerException}");

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Generate the tenant token.
        /// </summary>
        /// <returns>The token.</returns>
        /// <param name="validationContext">Validation context.</param>
        [AllowAnonymous]
        [HttpPost]
        [Route("get-Auth0-token")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(Auth0TokenResponse))]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "Bad Request", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Not Found", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, "Internal Server Error", typeof(ApiResult))]
        public IActionResult GenerateAuth0Token([FromBody] Auth0Payload payload)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    //generate the token context
                    Auth0TokenResponse token = this.Service.GetAuth0TokenFromToast(payload);

                    //return token
                    return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = token});

                }
                else
                {
                    //return error
                    BadRequestObjectResult badObjectResult = new BadRequestObjectResult(ModelState);
                    this.Logger.LogError(badObjectResult.ToString());

                    return StatusCode(StatusCodes.Status400BadRequest, new ApiResult() { Exception = badObjectResult });
                }
            }
            catch (KeyNotFoundException ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, new ApiResult() { Exception = ex.Message });
            }
            catch (System.Exception ex)
            {
                this.Logger.LogError($"error in generating token from Auth0 ({ex.Message}): {ex.InnerException}");

                return StatusCode(StatusCodes.Status500InternalServerError, new ApiResult() { Exception = ex.Message });
            }
        }

        /// <summary>
        /// Generate the tenant token.
        /// </summary>
        /// <returns>The token.</returns>
        /// <param name="validationContext">Validation context.</param>
        [AllowAnonymous]
        [HttpPost]
        [Route("get-authentication-token")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(Auth0TokenResponse))]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "Bad Request", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Not Found", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, "Internal Server Error", typeof(ApiResult))]
        public IActionResult GenerateAuthenticationToken([FromBody] AuthenticationPayload payload)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    //generate the token context
                    Auth0TokenResponse token = this.Service.GetAuthenticationTokenFromToast(payload);

                    //return token
                    return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = token });

                }
                else
                {
                    //return error
                    BadRequestObjectResult badObjectResult = new BadRequestObjectResult(ModelState);
                    this.Logger.LogError(badObjectResult.ToString());

                    return StatusCode(StatusCodes.Status400BadRequest, new ApiResult() { Exception = badObjectResult });
                }
            }
            catch (KeyNotFoundException ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, new ApiResult() { Exception = ex.Message });
            }
            catch (System.Exception ex)
            {
                this.Logger.LogError($"error in generating token from Auth0 ({ex.Message}): {ex.InnerException}");

                return StatusCode(StatusCodes.Status500InternalServerError, new ApiResult() { Exception = ex.Message });
            }
        }


        /// <summary>
        /// Generate the m2m auth token.
        /// </summary>
        /// <returns>The token.</returns>
        /// <param name="validationContext">Validation context.</param>
        [XtraChefUseOnly]
        [HttpPost]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(NativeXtraCHEFTokenTokenResponse))]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "Bad Request", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Not Found", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, "Internal Server Error", typeof(ApiResult))]
        [Route("get-native-xtrachef-token")]
        public IActionResult GenerateNativeXtraCHEFToken([FromBody] NativeXtraCHEFPayload payload, [FromQuery(Name = "NativeXtraCHEFType")] string NativeXtraCHEFType)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    //generate the token context
                    NativeXtraCHEFTokenTokenResponse token = this.Service.GetNativeXtraCHEFTokenFromToast(payload, NativeXtraCHEFType);

                    //return token
                    return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = token });

                }
                else
                {
                    //return error
                    BadRequestObjectResult badObjectResult = new BadRequestObjectResult(ModelState);
                    this.Logger.LogError(badObjectResult.ToString());

                    return StatusCode(StatusCodes.Status400BadRequest, new ApiResult() { Exception = badObjectResult });
                }
            }
            catch (KeyNotFoundException ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, new ApiResult() { Exception = ex.Message });
            }
            catch (System.Exception ex)
            {
                this.Logger.LogError($"error in generating token from Auth0 ({ex.Message}): {ex.InnerException}");

                return StatusCode(StatusCodes.Status500InternalServerError, new ApiResult() { Exception = ex.Message });
            }
        }

        #endregion

    }
}
