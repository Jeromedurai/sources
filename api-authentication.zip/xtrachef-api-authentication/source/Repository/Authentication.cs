﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using XtraChef.API.Base.Repository;
using XtraChef.API.Base.Util;
using XtraChef.API.Authentication.Model;
using XtraChef.API.Base.Extensions;
using Sa.Common.Cache.Model;
using System.Xml.Linq;
using XtraChef.API.Base.Model.Validation;

namespace XtraChef.API.Authentication.Repository
{
    public class Authentication : XcBaseQueryRepository<Model.Authentication, Context.Authentication>
    {

        private readonly IConfiguration _configuration;

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Tenant.Repository.Tenant"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="loggerFactory">Logger factory.</param>
        public Authentication(Context.Authentication dbContext, ILoggerFactory loggerFactory, IConfiguration configuration) : base(dbContext, loggerFactory)
        {
            this._configuration = configuration;
        }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="locationId"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async override Task<Model.Authentication> GetById(string tenantId, string locationId, string id)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Validate token context
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="locationId"></param>
        /// <param name="userId"></param>
        /// <param name="userRole"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        public bool ValidateTokenContext(Base.Model.Security.ValidationContext validTokenContext, string spName)
        {
            try
            {
                SqlParameter Tenant = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = Convert.ToInt64(validTokenContext.TenantId)
                };

                SqlParameter tenantGuid = new SqlParameter
                {
                    ParameterName = "@TENANTGUID",
                    SqlDbType = SqlDbType.VarChar,
                    Value = validTokenContext?.TenantGuid ?? string.Empty
                };

                SqlParameter Location = new SqlParameter
                {
                    ParameterName = "@LOCATIONID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = Convert.ToInt64(validTokenContext.LocationId)
                };

                SqlParameter User = new SqlParameter
                {
                    ParameterName = "@USERID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = Convert.ToInt64(validTokenContext.UserId)
                };

                SqlParameter userGuid = new SqlParameter
                {
                    ParameterName = "@USERGUID",
                    SqlDbType = SqlDbType.VarChar,
                    Value = validTokenContext?.UserGuid ?? string.Empty
                };

                SqlParameter UserRole = new SqlParameter
                {
                    ParameterName = "@USERROLE",
                    SqlDbType = SqlDbType.BigInt,
                    Value = Convert.ToInt64(validTokenContext.UserRole)
                };

                Model.ValidTokenContext result = this.DbContext.ValidTokenContexts.FromSqlRaw($"exec {spName} @TENANTID,@TENANTGUID,@LOCATIONID,@USERID,@USERGUID,@USERROLE", Tenant, tenantGuid, Location, User, userGuid, UserRole).AsNoTracking().AsEnumerable().FirstOrDefault();

                if (result != null)
                {
                    validTokenContext.TenantGuid = result.TenantGuid;
                    validTokenContext.UserGuid = result.UserGuid;
                    validTokenContext.ToastUserGuid = result.ToastUserGuid;
                    return result.IsValid;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }
}