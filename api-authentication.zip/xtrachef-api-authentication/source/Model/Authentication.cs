﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XtraChef.API.Base.Core;

namespace XtraChef.API.Authentication.Model
{
    public class Authentication : XcBase
    {
    }
}
