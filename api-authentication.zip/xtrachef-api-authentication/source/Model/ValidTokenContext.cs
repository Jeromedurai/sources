﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace XtraChef.API.Authentication.Model
{
    public class ValidTokenContext
    {
        [Column("ISVALID"),Key]
        public bool IsValid { get; set; }

        [Column("TENANTGUID")]
        public string TenantGuid { get; set; }

        [Column("USERGUID")]
        public string UserGuid { get; set; }

        [Column("TOASTUSERGUID")]
        public string ToastUserGuid { get; set; }
    }
}
