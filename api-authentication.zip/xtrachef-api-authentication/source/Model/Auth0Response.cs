﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XtraChef.API.Authentication.Model
{
    public class Auth0Response
    {
        [JsonProperty("token")]
        public Token Token { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }
    }

    public class Token
    {
        [JsonProperty("tokenType")]
        public string TokenType { get; set; }

        [JsonProperty("scope")]
        public string Scope { get; set; }

        [JsonProperty("expiresIn")]
        public string ExpiresIn { get; set; }

        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }
    }

    public class Auth0TokenResponse 
    {
        [JsonProperty("expiresIn")]
        public string ExpiresIn { get; set; }

        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }
    }

    public class NativeXtraCHEFTokenTokenResponse
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("expires_in")]
        public string ExpiresIn { get; set; }
    }

}
