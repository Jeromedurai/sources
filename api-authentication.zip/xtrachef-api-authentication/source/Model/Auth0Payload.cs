﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XtraChef.API.Authentication.Model
{
    public class Auth0Payload
    {
        [JsonProperty("userAccessType")]
        public string UserAccessType { get; set; }

        [JsonProperty("clientId")]
        public string ClientId { get; set; }

        [JsonProperty("clientSecret")]
        public string ClientSecret { get; set; }

        [JsonProperty("authorizationCode")]
        public string AuthorizationCode { get; set; }

        [JsonProperty("redirectUri")]
        public string RedirectUri { get; set; }
    }

    public class AuthenticationPayload
    {
        [JsonProperty("userAccessType")]
        public string UserAccessType { get; set; }

        [JsonProperty("clientId")]
        public string ClientId { get; set; }

        [JsonProperty("clientSecret")]
        public string ClientSecret { get; set; }

        [JsonProperty("userName")]
        public string UserName { get; set; }

        [JsonProperty("userSecret")]
        public string UserSecret { get; set; }
    }


    public class NativeXtraCHEFPayload
    {
        [JsonProperty("password")]
        public string password { get; set; }

        [JsonProperty("username")]
        public string username { get; set; }

        [JsonProperty("realm")]
        public string realm { get; set; }

        [JsonProperty("scope")]
        public string scope { get; set; }

        [JsonProperty("grant_type")]
        public string grant_type { get; set; }

        [JsonProperty("client_id")]
        public string client_id { get; set; }

        [JsonProperty("audience")]
        public string audience { get; set; }
    }

    public class Constant
    {
        public const string ENCRYPTION_KEY = "EncrptyUsername";
    }
}
