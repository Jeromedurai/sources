﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XtraChef.API.Base.Service;
using XtraChef.API.Base.Util;
using XtraChef.API.Authentication.Model;
using static XtraChef.API.Base.Core.Enum;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Amazon.Runtime.Internal;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using XtraChef.API.Base.Model;
using System.Security.Cryptography;
using System.IO;
using Sa.Common.CacheService;
using Sa.Common.Cache;
using ICacheService = Sa.Common.CacheService.ICacheService;
using static XtraChef.API.Base.Core.Constant;
using System.Xml.Linq;

namespace XtraChef.API.Authentication.Services
{
    public class Authentication : XcBaseService
    {
        #region Variables

        private Repository.Authentication _authenticationRepository;
        private readonly ICacheService _cacheService;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Authentication.Services.Authentication"/> class.
        /// </summary>
        /// <param name="authenticationRepository">Tenant repository.</param>
        /// <param name="loggerFactory">Logger factory.</param>
        public Authentication(Repository.Authentication authenticationRepository, ILoggerFactory loggerFactory, XtraChef.API.Base.Repository.XcAudit xcAudit, XtraChef.API.Base.Repository.XcValidation xcValidation, ICacheService cacheService) : base(xcAudit, xcValidation)
        {
            _cacheService = cacheService;
            _authenticationRepository = authenticationRepository;
            _authenticationRepository.Logger = loggerFactory.CreateLogger<Repository.Authentication>();
        }

        #endregion

        #region  Public Methods

        /// <summary>
        /// Generate tenant token
        /// </summary>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        public string GenerateTenantToken(Base.Model.Security.ValidationContext validationContext)
        {
            var claims = new[] {
                new Claim(Base.Core.Constant.Jwt.CLAIM_USER_ID, validationContext.UserId),
                new Claim(Base.Core.Constant.Jwt.CLAIM_USER_ROLE, validationContext.UserRole),
                new Claim(Base.Core.Constant.Jwt.CLAIM_TENANT_ID, validationContext.TenantId),
                new Claim(Base.Core.Constant.Jwt.CLAIM_LOCATION_ID, validationContext.LocationId),
                new Claim(Base.Core.Constant.Jwt.CLAIM_USER_GUID, validationContext?.UserGuid ?? string.Empty),
                new Claim(Base.Core.Constant.Jwt.CLAIM_TENANT_GUID, validationContext?.TenantGuid ?? string.Empty),
                new Claim(Base.Core.Constant.Jwt.CLAIM_TOAST_USER_GUID, validationContext?.ToastUserGuid ?? string.Empty)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(this.Configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(this.Configuration["Jwt:Issuer"],
                                             this.Configuration["Jwt:Issuer"],
                                             claims,
                                             expires: DateTime.Now.AddMinutes(Double.Parse(this.Configuration["Jwt:Expiration"])),
            signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        /// <summary>
        /// validate token context
        /// </summary>
        /// <param name="validationContext"></param>
        public void ValidateTokenContext(Base.Model.Security.ValidationContext validationContext)
        {
            try
            {
                //logger
                this.Logger.LogInformation($"Validate TenantId,LocationId,UserId and UserRole in token parameters");

                //skip the validation if the internal flag is true
                //NOTE: If it is needed to validate the TenantId,LocationId,UserId and UserRole,Remove the internal flag and give proper context.
                if (validationContext.Internal == false)
                {
                    //local variable
                    bool isInternalTenant = false;

                    //list of internal tenants
                    var internalTenants = this.Configuration["xtraCHEF:InternalTenants"];

                    //if tenant is one of the internal tenant
                    if (internalTenants != null)
                    {
                        var tenantIds = internalTenants?.Split(",");
                        if (tenantIds != null && tenantIds.Any() && tenantIds.Contains(validationContext.TenantId))
                            isInternalTenant = true;
                    }

                    if (!isInternalTenant)
                    {
                        //get spName
                        string spName = this.Configuration["StoredProcedure:ValidateTokenContext"];

                        //null check
                        if (string.IsNullOrEmpty(spName))
                        {
                            //logger
                            this.Logger.LogWarning($"Stored procedure is not configured for ValidateTokenContext");
                            throw new KeyNotFoundException($"Stored procedure is not configured for ValidateTokenContext");
                        }

                        //validate the TenantId,LocationId,UserId and UserRole
                        bool isValid = this._authenticationRepository.ValidateTokenContext(validationContext, spName);

                        if (!isValid)
                        {
                            //logger
                            this.Logger.LogWarning($"Input is invalid");
                            throw new KeyNotFoundException($"Input is invalid");
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        public void PostClientDetails(HttpRequest Request, Base.Model.Security.ValidationContext validationContext, string userHostIpAddress, string userAgent)
        {
            string userHostAddress = String.Empty;
            int index = !string.IsNullOrEmpty(userHostIpAddress) ? userHostIpAddress.IndexOf(":") : 0;
            if (index > 0)
            {
                userHostAddress = !string.IsNullOrEmpty(userHostIpAddress) ? userHostIpAddress.Substring(index + 1) : string.Empty;
            }
            string clientIpAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            if (Request.Headers != null && Request.Headers.ContainsKey("X-Forwarded-For"))
            {
                clientIpAddress = clientIpAddress + "/" + Request.Headers["X-Forwarded-For"];
            }

            ClientDetail client = new ClientDetail
            {
                ClientIp = !string.IsNullOrEmpty(userHostAddress) ? $"{clientIpAddress}/{userHostAddress}" : clientIpAddress,
                UserAgent = userAgent != null ? userAgent : "",
                Type = Request.Method,
                Endpoint = $"{Request.Host.Value}{Request.Path.Value}",
                UserId = validationContext.UserId,
                TenantId = validationContext.TenantId,
                UserRole = this.GetUserRole(validationContext.UserRole),
                LocationId = validationContext.LocationId
            };

            string json = JsonConvert.SerializeObject(client);

            this.Logger.LogInformation($"{json}");
        }

        private string GetUserRole(string roleId)
        {
            string role = string.Empty;

            return roleId switch
            {
                "1" => API.Base.Core.Enum.User.Role.SystemAdmin.ToString(),
                "2" => API.Base.Core.Enum.User.Role.TenantAdmin.ToString(),
                "3" => API.Base.Core.Enum.User.Role.Executive.ToString(),
                "4" => API.Base.Core.Enum.User.Role.DataEntryOperator.ToString(),
                "5" => API.Base.Core.Enum.User.Role.RestaurantManager.ToString(),
                "6" => API.Base.Core.Enum.User.Role.InvoiceCaputre.ToString(),
                "8" => API.Base.Core.Enum.User.Role.RestaurantUser.ToString(),
                _ => roleId,
            };
        }

        /// <summary>
        /// get toast authorization token
        /// </summary>
        /// <param name="validationContext"></param>
        public Auth0TokenResponse GetAuth0TokenFromToast(Auth0Payload payload)
        {
            try
            {
                //logger
                this.Logger.LogInformation($"Calling GetAuth0TokenFromToast() - begin to Authorization code for : {payload.AuthorizationCode}");

                Auth0Response auth0Response = new Auth0Response();
                Auth0TokenResponse tokenResponse = new Auth0TokenResponse();
                HttpClient client = new HttpClient();

                Auth0Payload auth0 = new Auth0Payload
                {
                    UserAccessType = this.Configuration["Toast:auth0:app-xtrachef-web:userAccessType"],
                    ClientId = this.Configuration["Toast:auth0:app-xtrachef-web:clientId"],
                    ClientSecret = this.Configuration["Toast:auth0:app-xtrachef-web:clientSecret"],
                    RedirectUri = payload.RedirectUri,
                    AuthorizationCode = payload.AuthorizationCode
                };
                string baseUri = this.Configuration["Toast:auth0:m2m-app-xtrachef:Auth0AuthenticationBaseUrl"];
                string requestUri = $"{baseUri}/authentication/login";
                string RequestJson = JsonConvert.SerializeObject(auth0);

                XtraChef.API.Base.Rest.HttpRequestObject httpRequestObject = new XtraChef.API.Base.Rest.HttpRequestObject();
                XtraChef.API.Base.Rest.Client RestClient = new API.Base.Rest.Client();
                if (httpRequestObject.Headers == null)
                {
                    httpRequestObject.Headers = new Dictionary<string, string>();
                }

                httpRequestObject.URL = requestUri.ToString();
                httpRequestObject.RequestContentType = "application/json";
                httpRequestObject.REQUESTTYPE = API.Base.Rest.Constant.POST;
                httpRequestObject.Content = RequestJson; //make a post call
                var response = RestClient.ExecuteAsync(httpRequestObject).Result; //get response
                var result = response.Content;

                if (response.IsSuccessful)
                {
                    auth0Response = JsonConvert.DeserializeObject<Auth0Response>(result);

                    if (auth0Response != null && auth0Response.Token != null)
                    {
                        tokenResponse.AccessToken = auth0Response.Token.AccessToken;
                        tokenResponse.ExpiresIn = auth0Response.Token.ExpiresIn;
                    }
                }
                else
                {
                    throw new System.Exception($"Unable to fetch access token from Auth0 for Authorization code : {payload.AuthorizationCode}");
                }

                this.Logger.LogInformation($"Called GetAuth0TokenFromToast() - Authorization code for : {payload.AuthorizationCode}");

                return tokenResponse;
            }
            catch (KeyNotFoundException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                this.Logger.LogError($"Error while fetch access token from Auth0 for Authorization code  - {payload.AuthorizationCode}: {ex.Message}");
                this.Logger.LogError($"Inner Exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace: {ex.StackTrace}");
                throw ex;
            }
        }

        /// <summary>
        /// get toast authorization token
        /// </summary>
        /// <param name="validationContext"></param>
        public Auth0TokenResponse GetAuthenticationTokenFromToast(AuthenticationPayload payload)
        {
            try
            {
                //logger
                this.Logger.LogInformation($"Calling GetAuthenticationTokenFromToast() for user : {payload.UserName}");

                Auth0Response auth0Response = new Auth0Response();
                Auth0TokenResponse tokenResponse = new Auth0TokenResponse();
                HttpClient client = new HttpClient();

                AuthenticationPayload auth0 = new AuthenticationPayload
                {
                    UserAccessType = "TOAST_WEB_ACCESS",
                    ClientId = this.Configuration["Toast:auth0:app-xtrachef-web:clientId"],
                    ClientSecret = this.Configuration["Toast:auth0:app-xtrachef-web:clientSecret"],
                    UserName = payload.UserName,
                    UserSecret = this.Decrypt(payload.UserSecret)
                };
                string baseUri = this.Configuration["Toast:auth0:m2m-app-xtrachef:Auth0AuthenticationBaseUrl"];
                string requestUri = $"{baseUri}/authentication/login";
                string RequestJson = JsonConvert.SerializeObject(auth0);

                XtraChef.API.Base.Rest.HttpRequestObject httpRequestObject = new XtraChef.API.Base.Rest.HttpRequestObject();
                XtraChef.API.Base.Rest.Client RestClient = new API.Base.Rest.Client();
                if (httpRequestObject.Headers == null)
                {
                    httpRequestObject.Headers = new Dictionary<string, string>();
                }

                httpRequestObject.URL = requestUri.ToString();
                httpRequestObject.RequestContentType = "application/json";
                httpRequestObject.REQUESTTYPE = API.Base.Rest.Constant.POST;
                httpRequestObject.Content = RequestJson; //make a post call
                var response = RestClient.ExecuteAsync(httpRequestObject).Result; //get response
                var result = response.Content;

                if (response.IsSuccessful)
                {
                    auth0Response = JsonConvert.DeserializeObject<Auth0Response>(result);

                    if (auth0Response != null && auth0Response.Token != null)
                    {
                        tokenResponse.AccessToken = auth0Response.Token.AccessToken;
                        tokenResponse.ExpiresIn = auth0Response.Token.ExpiresIn;
                    }
                }
                else
                {
                    throw new System.Exception($"Unable to fetch access token from Auth0 for user : {payload.UserName}");
                }

                this.Logger.LogInformation($"Called GetAuthenticationTokenFromToast() for user : {payload.UserName}");

                return tokenResponse;
            }
            catch (KeyNotFoundException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                this.Logger.LogError($"Error while fetch access token from Auth0 for - {payload.UserName}: {ex.Message}");
                this.Logger.LogError($"Inner Exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace: {ex.StackTrace}");
                throw ex;
            }
        }

        public string Decrypt(string cipherText)
        {
            string encryptionKey = Constant.ENCRYPTION_KEY;

            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(encryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = System.Text.Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        /// <summary>
        /// get toast authorization token
        /// </summary>
        /// <param name="validationContext"></param>
        public NativeXtraCHEFTokenTokenResponse GetNativeXtraCHEFTokenFromToast(NativeXtraCHEFPayload payload, string NativeXtraCHEFType)
        {
            try
            {
                //logger
                this.Logger.LogInformation($"Calling GetNativeXtraCHEFTokenFromToast() for user : {payload.username}");

                NativeXtraCHEFTokenTokenResponse auth0Response = new NativeXtraCHEFTokenTokenResponse();
                NativeXtraCHEFTokenTokenResponse tokenResponse = new NativeXtraCHEFTokenTokenResponse();
                HttpClient client = new HttpClient();

                NativeXtraCHEFPayload auth0 = new NativeXtraCHEFPayload();

                if (NativeXtraCHEFType == "External")
                {
                    auth0.realm = this.Configuration["Toast:auth0:native-external-xtrachef:realm"];
                    auth0.scope = this.Configuration["Toast:auth0:native-external-xtrachef:scope"];
                    auth0.grant_type = this.Configuration["Toast:auth0:native-external-xtrachef:grantType"];
                    auth0.client_id = this.Configuration["Toast:auth0:native-external-xtrachef:clientId"];
                    auth0.audience = this.Configuration["Toast:auth0:native-external-xtrachef:audience"];
                    auth0.username = payload.username;
                    auth0.password = this.Decrypt(payload.password);
                }
                else
                {
                    auth0.realm = this.Configuration["Toast:auth0:native-internal-xtrachef:realm"];
                    auth0.scope = this.Configuration["Toast:auth0:native-internal-xtrachef:scope"];
                    auth0.grant_type = this.Configuration["Toast:auth0:native-internal-xtrachef:grantType"];
                    auth0.client_id = this.Configuration["Toast:auth0:native-internal-xtrachef:clientId"];
                    auth0.audience = this.Configuration["Toast:auth0:native-internal-xtrachef:audience"];
                    auth0.username = payload.username;
                    auth0.password = this.Decrypt(payload.password);
                }

                string baseUri = this.Configuration["Toast:auth0:m2m-app-xtrachef:Auth0AuthenticationBaseUrl"];
                string requestUri = $"{baseUri}/authentication/oauth/token";
                string RequestJson = JsonConvert.SerializeObject(auth0);

                XtraChef.API.Base.Rest.HttpRequestObject httpRequestObject = new XtraChef.API.Base.Rest.HttpRequestObject();
                XtraChef.API.Base.Rest.Client RestClient = new API.Base.Rest.Client();
                if (httpRequestObject.Headers == null)
                {
                    httpRequestObject.Headers = new Dictionary<string, string>();
                }

                httpRequestObject.URL = requestUri.ToString();
                httpRequestObject.RequestContentType = "application/json";
                httpRequestObject.REQUESTTYPE = API.Base.Rest.Constant.POST;
                httpRequestObject.Content = RequestJson; //make a post call
                var response = RestClient.ExecuteAsync(httpRequestObject).Result; //get response
                var result = response.Content;

                if (response.IsSuccessful)
                {
                    auth0Response = JsonConvert.DeserializeObject<NativeXtraCHEFTokenTokenResponse>(result);

                    if (auth0Response != null && auth0Response.AccessToken != null)
                    {
                        tokenResponse.AccessToken = auth0Response.AccessToken;
                        tokenResponse.ExpiresIn = auth0Response.ExpiresIn;
                    }
                }
                else
                {
                    throw new System.Exception($"Unable to fetch access token from Auth0 for user : {payload.username}");
                }

                this.Logger.LogInformation($"Called GetNativeXtraCHEFTokenFromToast() for user : {payload.username}");

                return tokenResponse;
            }
            catch (KeyNotFoundException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                this.Logger.LogError($"Error while fetch access token from Auth0 for - {payload.username}: {ex.Message}");
                this.Logger.LogError($"Inner Exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace: {ex.StackTrace}");
                throw ex;
            }
        }

        #endregion

    }
}
