﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Http;
using Sa.Common.ADO.DataAccess;
using Sa.Common.WebAPI.Base.Extensions;
using CorrelationId.DependencyInjection;
using Microsoft.AspNetCore.Mvc;
using Sa.Common.WebAPI.Base;
using System.Reflection;
using System;
using Sa.Common.Aws;
using Sa.Common.Utility;
using Microsoft.Extensions.Hosting;
using Sa.Common.SeriLog;
using MediatR;
using Amazon;
using System.Linq;
using Sa.Common.ADO.CicdDataAccess;

namespace XtraChef.API.Security.Query
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        private string _AccessKey;
        private string _SecretKey;
        private readonly  string[] _AllowOrigins;
        private RegionEndpoint _RegionEndpoint;
        private ILoggerFactory _loggerFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Startup"/> class.
        /// </summary>
        /// <param name="env"></param>
        public Startup(IWebHostEnvironment env)
        {
            IConfigurationBuilder builder = StartupExtension.AddConfig(env);
            //build Configuration
            Configuration = builder.Build();
            StartupExtension.AddLogger(Configuration);
            //Change the application version here
            Configuration["APIVersion"] = "security-query";
            Configuration["AWS.Logging:LogGroup"] = "XtraChef.API.Security.Query";
            if (
                Configuration["ConnectionStrings:Default"] != null
                && Configuration["ConnectionStrings:Default"].Contains("MultipleActiveResultSets")
            )
            {
                Configuration["ConnectionStrings:Default"] = Configuration[
                    "ConnectionStrings:Default"
                ].Replace("MultipleActiveResultSets=True;", "");
            }
            if (Configuration["ConnectionStrings:Default_SSL"] != null && Configuration["ConnectionStrings:Default_SSL"].Contains("MultipleActiveResultSets"))
            {
                Configuration["ConnectionStrings:Default_SSL"] = Configuration["ConnectionStrings:Default_SSL"].Replace("MultipleActiveResultSets=True;", "");
            }
            string _BaseUrl = Convert.ToString(Configuration["APIUrl:BaseUrl"]);
            string _EcsBaseUrl = Convert.ToString(Configuration["APIUrl:EcsBaseUrl"]);
            _AllowOrigins = new string[] { _BaseUrl.Remove(_BaseUrl.Length - 1), _EcsBaseUrl.Remove(_EcsBaseUrl.Length - 1) };
            if (env.EnvironmentName == "Dev")
            {
                var localHostUrls = Configuration["APIUrl:LocalHostUrl"].Split(",");
                foreach(string item in localHostUrls)
                {
                    _AllowOrigins = _AllowOrigins.Concat(new string[] { Convert.ToString(item) }).ToArray();
                }
            }
            /*** End: API Specific Configuration ***/
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().AddNewtonsoftJson();
            services.AddHttpContextAccessor();
            services.TryAddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddSwaggerExtension(Configuration);
            services.AddSingleton(Configuration);
            services.AddApiVersioningExtension();
            services.AddHealthChecks();
            services.AddControllers();
            services.AddApplicationLayer(Assembly.GetExecutingAssembly());
            services.AddLoggingLayer();
            services
                .AddCors(
                    options =>
                        options.AddPolicy(
                            "AllowAllOrigins",
                            builder =>
                            {
                                builder.WithOrigins(_AllowOrigins)
                                    .AllowAnyMethod()
                                    .AllowAnyHeader();
                            }
                        )
                )
                .AddDefaultCorrelationId(x =>
                {
                    x.AddToLoggingScope = true;
                    x.UpdateTraceIdentifier = false;
                })
                .AddApiVersioning(options =>
                {
                    options.ReportApiVersions = true;
                    options.AssumeDefaultVersionWhenUnspecified = true;
                    options.DefaultApiVersion = new ApiVersion(1, 0);
                });

            _AccessKey = !string.IsNullOrEmpty(Configuration["AWS:AccessKey"])
                ? Configuration["AWS:AccessKey"]
                : throw new Exception("Missing environment variable 'AWS:AccessKey'");

            _SecretKey = !string.IsNullOrEmpty(Configuration["AWS:SecretKey"])
                ? Configuration["AWS:SecretKey"]
                : throw new Exception("Missing environment variable 'AWS:SecretKey'");

            _RegionEndpoint = Amazon.RegionEndpoint.GetBySystemName(Region.CurrentRegion);
            
            //Aurora configuration
            services.AddSingleton<PostgressDataAccess>(_ => new PostgressDataAccess(SetAuroraConnectionString(Configuration["AuroraV2:ConnectionString"])));

            services.AddScoped(
                typeof(Sa.Common.WebAPI.Base.Repository.AuditRepository),
                typeof(Sa.Common.WebAPI.Base.Repository.AuditRepository)
            );
            services.AddScoped(
                typeof(Sa.Common.WebAPI.Base.Repository.ValidationRepository),
                typeof(Sa.Common.WebAPI.Base.Repository.ValidationRepository)
            );
            services.AddSingleton(
                _ =>
                    new Sa.Common.Aws.DynamoDB.DynamoDBService(
                        _AccessKey,
                        _SecretKey,
                        _RegionEndpoint
                    )
            );
            services.AddSingleton<CicdDataAccess>(
                _ =>
                    new CicdDataAccess(
                        XcUtil.DecryptConnection.SetConnectionString(
                            Configuration["ConnectionStrings:Default"]
                        )
                    )
            );
            services
                .AddDbContext<Sa.Common.WebAPI.Base.Context.AuditContext>(options =>
                {
                    options.UseSqlServer(
                        XcUtil.DecryptConnection.SetConnectionString(
                            Configuration["ConnectionStrings:Default_SSL"]
                        )
                    );
                    options.EnableSensitiveDataLogging(true);
                    options.UseLoggerFactory(_loggerFactory);
                })
                .AddDbContext<Sa.Common.WebAPI.Base.Context.ValidationContext>(options =>
                {
                    options.UseSqlServer(
                        XcUtil.DecryptConnection.SetConnectionString(
                            Configuration["ConnectionStrings:Default_SSL"]
                        )
                    );
                    options.EnableSensitiveDataLogging(true);
                    options.UseLoggerFactory(_loggerFactory);
                });

            services.AddMediatR(typeof(Sa.Common.SeriLog.LogNotificationHandler));
            services.AddSingleton<LogPublisher>();

            /*** Begin: API Specific Configuration ***/

            #region Feature

            //adding DbContext 'Feature'
            services.AddDbContext<Context.Feature>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Feature
            services.AddScoped(typeof(Services.Feature), typeof(Services.Feature));
            services.AddScoped(typeof(Repository.Feature), typeof(Repository.Feature));
            services.AddScoped(typeof(Factory.Feature), typeof(Factory.Feature));

            #endregion

            #region Module

            //adding DbContext 'Module'
            services.AddDbContext<Context.Module>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Module
            services.AddScoped(typeof(Services.Module), typeof(Services.Module));
            services.AddScoped(typeof(Repository.Module), typeof(Repository.Module));
            services.AddScoped(typeof(Factory.Module), typeof(Factory.Module));

            #endregion

            #region AccessGroup

            //adding DbContext 'AccessGroup'
            services.AddDbContext<Context.AccessGroup>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Access Group
            services.AddScoped(
                typeof(Services.AccessGroupDetail),
                typeof(Services.AccessGroupDetail)
            );
            services.AddScoped(
                typeof(Repository.AccessGroupDetail),
                typeof(Repository.AccessGroupDetail)
            );
            services.AddScoped(
                typeof(Factory.AccessGroupDetail),
                typeof(Factory.AccessGroupDetail)
            );

            #endregion

            #region AccessGroup Upload

            //adding DbContext 'AccessGroup'
            services.AddDbContext<Context.AccessGroupDetail>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Access Group
            services.AddScoped(typeof(Services.AccessGroup), typeof(Services.AccessGroup));
            services.AddScoped(typeof(Repository.AccessGroup), typeof(Repository.AccessGroup));
            services.AddScoped(typeof(Factory.AccessGroup), typeof(Factory.AccessGroup));

            #endregion

            #region Security

            //adding DbContext 'Security'
            services.AddDbContext<Context.Security>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Module
            services.AddScoped(typeof(Services.Security), typeof(Services.Security));
            services.AddScoped(typeof(Repository.Security), typeof(Repository.Security));
            services.AddScoped(typeof(Factory.Security), typeof(Factory.Security));

            #endregion

            #region Package

            //adding DbContext 'Package'
            services.AddDbContext<Context.Package>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Package Code
            services.AddScoped(typeof(Services.Package), typeof(Services.Package));
            services.AddScoped(typeof(Repository.Package), typeof(Repository.Package));
            services.AddScoped(typeof(Factory.Package), typeof(Factory.Package));

            #endregion

            #region Package Detail

            //adding DbContext 'PackageDetailContext'
            services.AddDbContext<Context.PackageDetail>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Package Code
            services.AddScoped(typeof(Services.PackageDetail), typeof(Services.PackageDetail));
            services.AddScoped(typeof(Repository.PackageDetail), typeof(Repository.PackageDetail));
            services.AddScoped(typeof(Factory.PackageDetail), typeof(Factory.PackageDetail));

            #endregion

            #region Tenanat Access Package

            //adding DbContext 'TenanatAccessPackageContext'
            services.AddDbContext<Context.TenantAccessPackage>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Tenant Access Package Code
            services.AddScoped(
                typeof(Services.TenantAccessPackage),
                typeof(Services.TenantAccessPackage)
            );
            services.AddScoped(
                typeof(Repository.TenantAccessPackage),
                typeof(Repository.TenantAccessPackage)
            );
            services.AddScoped(
                typeof(Factory.TenantAccessPackage),
                typeof(Factory.TenantAccessPackage)
            );

            #endregion

            #region Dependency Module

            //adding DbContext 'DependencyModuleContext'
            services.AddDbContext<Context.DependencyModule>(options =>
            {
                options.UseSqlServer(
                    XcUtil.DecryptConnection.SetConnectionString(
                        Configuration["ConnectionStrings:Default_SSL"]
                    ),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(60)
                );
                options.EnableSensitiveDataLogging(true);
                options.UseLoggerFactory(_loggerFactory);
            });

            //initialize scoped instance for Tenant Access Package Code
            services.AddScoped(
                typeof(Services.DependencyModule),
                typeof(Services.DependencyModule)
            );
            services.AddScoped(
                typeof(Repository.DependencyModule),
                typeof(Repository.DependencyModule)
            );
            services.AddScoped(typeof(Factory.DependencyModule), typeof(Factory.DependencyModule));

            #endregion

            //Register the Swagger generator, defining one or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(
                    Configuration["APIVersion"],
                    new OpenApiInfo
                    {
                        Title = "XtraChef API Security Query",
                        Version = Configuration["APIVersion"]
                    }
                );
            });

            /*** End: API Specific Configuration ***/
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(
            IApplicationBuilder app,
            IWebHostEnvironment env,
            ILoggerFactory loggerFactory
        )
        {
            _loggerFactory = loggerFactory;
            app.UsePathBase(new PathString("/api.security-query"));
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseSwaggerExtension();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseCors(options => options.WithOrigins(_AllowOrigins).AllowAnyHeader().AllowAnyMethod());
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseErrorHandlingMiddleware();
            app.UseHealthChecks("/version");
            app.UseEndpoints(endpoints => { endpoints.MapControllers(); });

            /*** End: API Specific Configuration ***/
        }


        public static string SetAuroraConnectionString(string connectionString)
        {
            var builder = new Npgsql.NpgsqlDataSourceBuilder(connectionString);
            builder.ConnectionStringBuilder.Password = Sa.Common.Security.Encryption.EnDecrypt(builder.ConnectionStringBuilder.Password, true);
            return builder.ConnectionString;
        }

    }
}