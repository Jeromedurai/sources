﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;
using System.Configuration;
using System.Linq;

namespace XtraChef.API.Security.Query.Services
{
    public class DependencyModule : APIServiceBase
    {
        #region Variables

        private readonly Repository.DependencyModule Repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Service.Module"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public DependencyModule(
            Repository.DependencyModule repository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //Module
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        public Model.DependencyModules GetDependencyModuleById(string moduleCode)
        {
            try
            {
                Model.DependencyModule dependencyModule = this.Repository
                    .GetDependencyModuleById(moduleCode)
                    .Result;

                Model.DependencyModules dependencyModules = new Model.DependencyModules();

                if (dependencyModule != null)
                {
                    dependencyModules.Pk = dependencyModule.Pk;
                    dependencyModules.ModuleCode = dependencyModule.ModuleCode;
                    dependencyModules.DependencyModulesCode = dependencyModule.DependencyModulesCode
                        .Trim()
                        .Split(",")
                        .Select(x => x)
                        .ToList();
                }

                return dependencyModule == null ? null : dependencyModules;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Module GetModuleById Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
