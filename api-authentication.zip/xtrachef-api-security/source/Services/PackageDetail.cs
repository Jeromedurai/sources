﻿using System.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;

namespace XtraChef.API.Security.Query.Services
{
    public class PackageDetail : APIServiceBase
    {
        #region Variables

        private readonly Repository.PackageDetail Repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Service.PackageDetail"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public PackageDetail(
            Repository.PackageDetail repository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //PackageDetail
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        public Model.PackageDetail GetPackageDetail(string packageCode, string moduleFeatureCode)
        {
            try
            {
                // declare variables
                string spPD = this.Configuration["StoredProcedure:GetPackageDetail"];
                Model.PackageDetail packageDetail = this.Repository
                    .GetPackageDetail(packageCode, moduleFeatureCode, spPD)
                    .Result;

                return packageDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Package Detail GetPackageDetailById Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
