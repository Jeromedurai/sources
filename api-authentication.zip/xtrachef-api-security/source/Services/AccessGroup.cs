﻿using System.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;

namespace XtraChef.API.Security.Query.Services
{
    public class AccessGroup : APIServiceBase
    {
        #region Variables

        private readonly Repository.AccessGroup Repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Service.AccessGroup"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public AccessGroup(
            Repository.AccessGroup repository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //AccessGroup
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        public Model.AccessGroup GetAccessGroupById(string accessGroupId)
        {
            try
            {
                Model.AccessGroup userGroupDetail = this.Repository
                    .GetAccessGroupById(accessGroupId)
                    .Result;

                return userGroupDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetAccessGroupById Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public Model.AccessGroupList GetAccessGroups()
        {
            try
            {
                string tenantId = this.TenantId;
                string locationId = this.LocationId;
                Model.AccessGroupList accessGroupList = this.Repository
                    .GetAccessGroups(tenantId, locationId)
                    .Result;

                return accessGroupList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetAccessGroups Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
