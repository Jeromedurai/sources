﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace XtraChef.API.Security.Query.Services
{
    public class Feature : APIServiceBase
    {
        #region Variables

        private readonly Repository.Feature Repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Service.Feature"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public Feature(
            Repository.Feature repository,
            Repository.Module moduleRepository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //Feature
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        public Model.Feature GetFeatureById(string featureId)
        {
            try
            {
                Model.ModuleFeature featureItem = this.Repository.GetFeatureById(featureId).Result;

                Model.Feature featureDetail = new Model.Feature();

                if (featureItem != null)
                {
                    featureDetail = this.Repository.GetFeature(featureItem);
                }

                return featureDetail == null ? null : featureDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetFeatureById Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.ModuleFeature> GetFeaturesByModuleId(string moduleId)
        {
            try
            {
                List<Model.ModuleFeature> featureDetail = this.Repository
                    .GetFeaturesByModuleId(moduleId)
                    .Result;

                return featureDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetFeatureByModuleId Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.ModuleFeature> GetFeaturesDetail()
        {
            try
            {
                List<Model.ModuleFeature> featuresDetail = this.Repository
                    .GetFeaturesDetail()
                    .Result;

                return featuresDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetFeaturesDetail Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<Model.LocationConfigResponse> GetLocationFeatures(
            string tenantId,
            string configKey,
            string entityId
        )
        {
            try
            {
                Model.LocationConfigResponse featuresDetail = new Model.LocationConfigResponse();
                bool allLocation = false;

                string spName = this.Configuration[
                    "StoredProcedure:GetLocationEntityConfigurations"
                ];

                if (string.IsNullOrEmpty(spName))
                {
                    //logger
                    await this.Logger.LogWarning(
                        $"Stored procedure is not configured for GetLocationEntityConfigurations"
                    );
                    throw new KeyNotFoundException(
                        $"Stored procedure is not configured for GetLocationEntityConfigurations"
                    );
                }

                string orderspName = this.Configuration["StoredProcedure:GetSharedOrderGuides"];

                if (string.IsNullOrEmpty(orderspName))
                {
                    //logger
                    await this.Logger.LogWarning(
                        $"Stored procedure is not configured for GetSharedOrderGuides"
                    );
                    throw new KeyNotFoundException(
                        $"Stored procedure is not configured for GetSharedOrderGuides"
                    );
                }

                List<Model.LocationEntityConfig> locationEntities =
                    await this.Repository.GetLocationEntity(tenantId, entityId, configKey, spName);
                List<Model.OrderGuide> orderGuides = await this.Repository.GetOrderGuideKey(
                    tenantId,
                    entityId,
                    orderspName
                );

                if (orderGuides != null && orderGuides.Count > 0)
                {
                    allLocation = orderGuides.Select(s => s.AllLocation).FirstOrDefault();
                }

                featuresDetail.AllLocation = allLocation;
                featuresDetail.IncludeIds = new List<long>();
                featuresDetail.ExcludeIds = new List<long>();
                if (locationEntities != null && locationEntities.Count > 0)
                {
                    if (allLocation)
                    {
                        featuresDetail.ExcludeIds = locationEntities
                            .Select(s => s.ConfigValue)
                            .ToList();
                    }
                    else
                    {
                        featuresDetail.IncludeIds = locationEntities
                            .Select(s => s.ConfigValue)
                            .ToList();
                    }
                }

                return featuresDetail;
            }
            catch (KeyNotFoundException ex)
            {
                //Error logging
                await this.Logger.LogError(
                    $"Error while calling GetLocationFeatures : ({ex.Message})"
                );
                throw;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError(
                    $"Error while calling GetLocationFeatures : ({ex.Message})"
                );
                await this.Logger.LogError($"Inner Exception : {ex.InnerException}");
                await this.Logger.LogError(ex.StackTrace);
                throw;
            }
        }

        #endregion
    }
}
