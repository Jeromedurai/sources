﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;
using System;
using System.Configuration;

namespace XtraChef.API.Security.Query.Services
{
    public class TenantAccessPackage : APIServiceBase
    {
        #region Variables

        private readonly Repository.TenantAccessPackage Repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Service.TenantAccessPackage"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public TenantAccessPackage(
            Repository.TenantAccessPackage repository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //TenantAccessPackage
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        public Model.TenantAccessPackage GetTenantAccessPackage(
            string tenantId,
            string locationId,
            string packageCode
        )
        {
            try
            {
                // declare variables
                string spTAP = this.Configuration["StoredProcedure:GetTenantAccessPackage"];
                Model.TenantAccessPackage tenantAccessPackage = this.Repository
                    .GetTenantAccessPackage(tenantId, locationId, packageCode, spTAP)
                    .Result;

                return tenantAccessPackage;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetTenantAccessPackageById Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public Model.TenantAccessPackage GetTenantAccessPackages()
        {
            try
            {
                // declare variables
                long tenantId = Convert.ToInt64(this.TenantId);
                long locationId = Convert.ToInt64(this.LocationId);

                Model.TenantAccessPackage tenantAccessPackage = this.Repository
                    .GetTenantAccessPackages(tenantId, locationId)
                    .Result;

                return tenantAccessPackage;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetTenantAccessPackages Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
