﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;
using System.Collections.Generic;
using System.Configuration;

namespace XtraChef.API.Security.Query.Services
{
    public class AccessGroupDetail : APIServiceBase
    {
        #region Variables

        private readonly Repository.AccessGroupDetail Repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Service.AccessGroupDetail"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public AccessGroupDetail(
            Repository.AccessGroupDetail repository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //AccessGroupDetail
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        public Model.AccessGroupDetail GetAccessGroupDetail(
            string accessGroupId,
            string moduleFeatureCode
        )
        {
            try
            {
                // declare variables
                string spMAGD = this.Configuration["StoredProcedure:GetModuleAccessGroupDetail"];
                Model.AccessGroupDetail accessGroupDetail = this.Repository
                    .GetAccessGroupDetail(accessGroupId, moduleFeatureCode, spMAGD)
                    .Result;

                return accessGroupDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetAccessGroupById Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public Model.UserGroupMapping GetUserGroupMapping(
            string accessGroupId,
            string tenantId,
            string locationId,
            string userRoleId,
            string userId
        )
        {
            try
            {
                // declare variables
                string spMUGM = this.Configuration["StoredProcedure:GetModuleUserGroupMapping"];
                Model.UserGroupMapping userGroupMappingDetail = this.Repository
                    .GetUserGroupMapping(
                        accessGroupId,
                        tenantId,
                        locationId,
                        userRoleId,
                        userId,
                        spMUGM
                    )
                    .Result;

                return userGroupMappingDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetUserGroupMapping Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.AccessGroupDetail> GetAccessGroupDetails()
        {
            try
            {
                List<Model.AccessGroupDetail> userGroupDetail = this.Repository
                    .GetAccessGroupDetails()
                    .Result;

                return userGroupDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetAccessGroupDetails Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
