﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace Sa.Common.ADO.CicdDataAccess
{
    /// <summary>
    ///   This class performs database functions.
    /// </summary>
    public class CicdDataAccess
    {
        #region private variables

        private readonly string _ConnectionString;
        private readonly int _CommandTimeOut;

        #endregion

        #region Constructor

        /// <summary>
        ///  Initializes a new instance of the DataAccess class
        /// </summary>
        /// <param name="connectionString">Database Connection string</param>
        /// <param name="commandTimeout">Command Timout(Defaut value is 30) </param>
        public CicdDataAccess(string connectionString, int commandTimeout = 30)
        {
            _ConnectionString = connectionString;
            _CommandTimeOut = commandTimeout;
        }

        #endregion

        #region private methods

        /// <summary>
        ///   Enterprise connection string name from configuration
        /// </summary>
        /// <param name="ConnectionName"></param>
        private Database GetDatabase(string ConnectionString = null)
        {
            if (ConnectionString == null)
            {
                return new Microsoft.Practices.EnterpriseLibrary.Data.Sql.SqlDatabase(
                    _ConnectionString
                );
            }
            else
            {
                return new Microsoft.Practices.EnterpriseLibrary.Data.Sql.SqlDatabase(
                    ConnectionString
                );
            }
        }

        /// <summary>
        ///   This is private helper method
        /// </summary>
        /// <param name="SPName"> Name of the Store procedure</param>
        /// <param name="parameterValues">parameter values for input of store procedure</param>
        /// <returns>DbCommand</returns>
        private DbCommand GetCmd(Database db, string SPName, params object[] parameterValues)
        {
            DbCommand cmd = null;
            if (parameterValues == null)
            {
                cmd = db.GetStoredProcCommand(SPName);
            }
            else
            {
                cmd = db.GetStoredProcCommand(SPName, parameterValues);

                foreach (SqlParameter parameter in cmd.Parameters)
                {
                    if (parameter.SqlDbType == SqlDbType.Structured)
                    {
                        string name = parameter.TypeName;
                        int index = name.IndexOf(".");
                        if (index == -1)
                        {
                            continue;
                        }
                        name = name.Substring(index + 1);
                        if (name.Contains("."))
                        {
                            parameter.TypeName = name;
                        }
                    }
                }
            }

            cmd.CommandTimeout = _CommandTimeOut;
            return cmd;
        }
        #endregion

        #region public methods

        /// <summary>
        ///   Executes the reader.
        /// </summary>
        /// <param name="SPName">Name of the SP</param>
        /// <param name="parameterValues">parameter values in order of creation</param>
        /// <returns></returns>
        public IDataReader ExecuteReader(string SPName, params object[] parameterValues)
        {
            try
            {
                Database db = GetDatabase();
                IDataReader result = db.ExecuteReader(GetCmd(db, SPName, parameterValues));

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion
    }
}
