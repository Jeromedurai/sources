﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using XtraChef.API.Security.Query.Model;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;
using Sa.Common.SeriLog;
using static Sa.Common.Utility.XcUtil;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace XtraChef.API.Security.Query.Services
{
    public class Security : APIServiceBase
    {
        #region Variables

        private readonly Repository.Security Repository;
        readonly string MSSQL = "mssql";

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Services.Security"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public Security(
            Repository.Security repository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //Security
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Module Enabled Entity.
        /// </summary>
        /// <param name="endpointDesc">EndpointDesc.</param>
        public bool GetModuleEnabled(SecurityAccess SecurityAccess)
        {
            try
            {
                // declare variables
                string spMFA = this.Configuration["StoredProcedure:GetModuleFeaturesAccess"];
                string spATL = this.Configuration["StoredProcedure:GetAccessTenantLocations"];
                long userId = Convert.ToInt64(this.UserId);
                long tenantId = Convert.ToInt64(this.TenantId);
                long userRoleId = Convert.ToInt64(this.UserRole);

                bool moduleEnabled = this.Repository
                    .GetModuleEnabled(userId, tenantId, userRoleId, SecurityAccess, spMFA, spATL)
                    .Result;

                //return moduleEnabled
                return moduleEnabled;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"GetModuleEnabled Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Endpoint Enabled Entity By Endpoint.
        /// </summary>
        /// <param name="">Endpoint</param>
        public Model.Features GetEndpointEnabled(string endpoint)
        {
            try
            {
                #region Variables
                // declare variables
                string spEE = this.Configuration["StoredProcedure:GetEndpointEnabled"];
                #endregion

                Model.Features featureItemEnabled = this.Repository.GetEndpointEnabled(
                    endpoint,
                    spEE
                );

                // return featureItemEnabled
                return featureItemEnabled;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"GetEndpointEnabled Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Module feature Access Entity.
        /// </summary>
        /// <param name="securityAccess">SecurityAccess.</param>
        public AccessSetting GetModuleEndpointAccess(SecurityAccess securityAccess)
        {
            try
            {
                #region Instances
                List<ModuleFeatureList> moduleFeatures = null;
                AccessSetting accessSetting = new AccessSetting();
                #endregion

                //get the user module feature
                moduleFeatures = GetModuleFeaturesAccess(securityAccess);

                //check the null and get the access level of endpoint
                if ((moduleFeatures != null) && (moduleFeatures.Count > 0))
                {
                    // /*convert endpoint to lower case*/
                    moduleFeatures.ForEach(moduleFeature =>
                    {
                        moduleFeature.features
                            .Where(
                                featureAccess =>
                                    featureAccess.Endpoint.ToLower()
                                    == securityAccess.Endpoint.ToLower()
                            )
                            .ToList()
                            .ForEach(featureAccess =>
                            {
                                accessSetting.ID = featureAccess.FeatureCode;
                                accessSetting.AccessLevel = featureAccess.AccessLevel;
                                accessSetting.Endpoint = featureAccess.Endpoint;
                            });
                    });
                }

                return accessSetting;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"GetModuleFeatureAccess Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Module Features Access Entity.
        /// </summary>
        /// <param name="securityAccess">SecurityAccess.</param>
        public List<Model.ModuleFeatureList> GetModuleFeaturesAccess(
            Model.SecurityAccess securityAccess
        )
        {
            try
            {
                #region Instances
                List<ModuleFeatureList> moduleFeatureList = new List<ModuleFeatureList>();
                List<Model.ModuleFeatures> moduleFeatureAccessList = null;
                #endregion

                #region Variables
                byte disabled = 0;
                string spMFA = this.Configuration["StoredProcedure:GetModuleFeaturesAccess"];
                string spMF = this.Configuration["StoredProcedure:GetModuleFeatures"];
                string spTAP = this.Configuration["StoredProcedure:GetTenantAccessPackages"];
                string spATL = this.Configuration["StoredProcedure:GetAccessTenantLocations"];
                long userId = Convert.ToInt64(this.UserId);
                long tenantId = Convert.ToInt64(this.TenantId);
                long locationId = Convert.ToInt64(this.LocationId);
                long userRoleId = Convert.ToInt64(this.UserRole);
                List<long> restrictAmfForLockedWeblinkRoleIds = this.Configuration[
                    "xtraCHEF:RestrictAmfForLockedWeblinkRoleIds"
                ]
                    .Trim()
                    .Split(",")
                    .Select(x => Convert.ToInt64(x))
                    .ToList();
                bool checkSumValid = Convert.ToBoolean(
                    this.Configuration["xtraCHEF:AMFCheckSumRequired"]
                );
                #endregion

                //get the Module Feature Access List
                moduleFeatureAccessList = this.Repository
                    .GetModuleFeaturesAccess(
                        userId,
                        tenantId,
                        locationId,
                        userRoleId,
                        securityAccess,
                        spMF,
                        spMFA,
                        spTAP,
                        spATL,
                        restrictAmfForLockedWeblinkRoleIds
                    )
                    .Result;

                //get the module feature access list with appropiate data
                if ((moduleFeatureAccessList != null) && (moduleFeatureAccessList.Count > 0))
                {
                    List<string> moduleCodes = moduleFeatureAccessList
                        .Select(x => x.ModuleCode)
                        .Distinct()
                        .ToList();
                    foreach (string moduleCode in moduleCodes)
                    {
                        List<FeaturesDetail> featuresAccess = new List<FeaturesDetail>();
                        moduleFeatureAccessList
                            .Where(moduleFeature => moduleFeature.ModuleCode == moduleCode)
                            .ToList()
                            .ForEach(moduleFeatureAccess =>
                            {
                                string checkSum = string.Empty;
                                if (checkSumValid)
                                {
                                    // In order for user to prevent an URL tempering, we should add a check sum value to the URL. Here is the step to generate a check sum.
                                    checkSum = EncryptionHelper.EnDecrypt(
                                        $"tenantId={tenantId}&userId={userId}&roleId={userRoleId}&featureCode={moduleFeatureAccess.FeatureCode}".Trim()
                                    );
                                }
                                FeaturesDetail featureAccess = new FeaturesDetail();
                                featureAccess.FeatureCode = moduleFeatureAccess.FeatureCode;
                                featureAccess.FeatureName = moduleFeatureAccess.FeatureName;
                                featureAccess.Caption = moduleFeatureAccess.Caption;
                                featureAccess.WebLink = string.IsNullOrEmpty(
                                    moduleFeatureAccess.WebLink
                                )
                                    ? ""
                                    : (
                                        checkSumValid
                                            ? $"{moduleFeatureAccess.WebLink}?featureCode={moduleFeatureAccess.FeatureCode}&chksum={checkSum}"
                                            : moduleFeatureAccess.WebLink
                                    );
                                featureAccess.Endpoint = string.IsNullOrEmpty(
                                    moduleFeatureAccess.Endpoint
                                )
                                    ? ""
                                    : moduleFeatureAccess.Endpoint;
                                featureAccess.ParentFeatureKey =
                                    moduleFeatureAccess.ParentFeatureKey;
                                featureAccess.AccessLevel =
                                    moduleFeatureAccess.AccessLevel == null
                                        ? disabled
                                        : moduleFeatureAccess.AccessLevel;
                                featureAccess.PackageCodes = moduleFeatureAccess.PackageCodes;
                                featuresAccess.Add(featureAccess);
                            });
                        ModuleFeatureList moduleFeatureDetail = new ModuleFeatureList();
                        moduleFeatureDetail.ModuleCode = moduleCode;
                        moduleFeatureDetail.ModuleName = moduleFeatureAccessList
                            .Where(moduleFeature => moduleFeature.ModuleCode == moduleCode)
                            .FirstOrDefault()
                            .ModuleName;
                        moduleFeatureDetail.features = featuresAccess;
                        moduleFeatureList.Add(moduleFeatureDetail);
                    }
                }

                //return the module feature with access level
                return moduleFeatureList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetModuleFeaturesAccess Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.MenuAccess> GetMenusAccess(Model.SecurityAccess securityAccess)
        {
            try
            {
                #region Instances
                List<Model.MenuAccess> menuAccessList = null;
                List<ModuleFeatureList> moduleFeatures = new List<ModuleFeatureList>();
                List<Model.MenuAccess> menusAccess = new List<Model.MenuAccess>();
                List<Model.TenantPackage> tenantPackage = new List<Model.TenantPackage>();
                #endregion

                #region Variables
                byte enabled = 1;
                byte disabled = 0;
                string spMA = this.Configuration["StoredProcedure:GetMenusAccess"];
                string spTAP = this.Configuration["StoredProcedure:GetTenantAccessPackages"];
                string spATL = this.Configuration["StoredProcedure:GetAccessTenantLocations"];
                long userId = Convert.ToInt64(this.UserId);
                long tenantId = Convert.ToInt64(this.TenantId);
                long locationId = Convert.ToInt64(this.LocationId);
                long userRoleId = Convert.ToInt64(this.UserRole);
                List<long> restrictAmfForLockedWeblinkRoleIds = this.Configuration[
                    "xtraCHEF:RestrictAmfForLockedWeblinkRoleIds"
                ]
                    .Trim()
                    .Split(",")
                    .Select(x => Convert.ToInt64(x))
                    .ToList();
                bool checkSumValid = Convert.ToBoolean(
                    this.Configuration["xtraCHEF:AMFCheckSumRequired"]
                );
                #endregion

                //get the menu access list
                menuAccessList = this.Repository.GetMenusAccess(spMA).Result;

                //get the user module feature
                moduleFeatures = GetModuleFeaturesAccess(securityAccess);

                //Get the tenant module access using moduleCode and locationIds.
                tenantPackage = this.Repository
                    .GetTenantPackage(
                        securityAccess,
                        userId,
                        tenantId,
                        locationId,
                        userRoleId,
                        spTAP,
                        spATL
                    )
                    .Result;

                //check the null and get distinct module with access level
                menuAccessList.ForEach(menuAccess =>
                {
                    menuAccess.WebUrl = menuAccess.WebLink; //adding weblink into weburl to check that user access is provided
                    string checkSum = string.Empty;
                    if (checkSumValid)
                    {
                        // In order for user to prevent an URL tempering, we should add a check sum value to the URL. Here is the step to generate a check sum.
                        checkSum = EncryptionHelper.EnDecrypt(
                            $"tenantId={tenantId}&userId={userId}&roleId={userRoleId}&moduleCode={menuAccess.ModuleCode}".Trim()
                        );
                    }
                    moduleFeatures
                        .Where(item => item.ModuleCode == menuAccess.ModuleCode)
                        .ToList()
                        .ForEach(moduleFeatureItem =>
                        {
                            //if all feature is disbled then we should disabled the menu also.
                            if (moduleFeatureItem.features.Any(item => item.AccessLevel == enabled))
                            {
                                menuAccess.AccessLevel = enabled; //if any feature is enabled then we must enabled the menu also.
                                menuAccess.WebLink = string.IsNullOrEmpty(menuAccess.WebLink)
                                    ? ""
                                    : (
                                        checkSumValid
                                            ? $"{menuAccess.WebLink}?moduleCode={menuAccess.ModuleCode}&chksum={checkSum}"
                                            : menuAccess.WebLink
                                    );
                                List<string> packageCodes = new List<string>();
                                tenantPackage
                                    .Where(data => data.ModuleCode == menuAccess.ModuleCode)
                                    .ToList()
                                    .ForEach(tenantPackageItem =>
                                    {
                                        menuAccess.Priority = tenantPackageItem.Priority;
                                        menuAccess.LandingPageUrl = string.IsNullOrEmpty(
                                            tenantPackageItem.LandingPageUrl
                                        )
                                            ? ""
                                            : (
                                                checkSumValid
                                                    ? $"{tenantPackageItem.LandingPageUrl}?moduleCode={menuAccess.ModuleCode}&chksum={checkSum}"
                                                    : tenantPackageItem.LandingPageUrl
                                            ); //if tenant didn't bought package then give WebLink = LockedWebLink.
                                        if (!packageCodes.Contains(tenantPackageItem.PackageCode))
                                        {
                                            packageCodes.Add(tenantPackageItem.PackageCode);
                                        }
                                        menuAccess.PackageCodes = packageCodes;
                                    });
                            }
                            else
                            {
                                menuAccess.AccessLevel = disabled; //if all feature is disbled then we should disabled the menu also.
                                if (
                                    tenantPackage.Any(
                                        item => item.ModuleCode == menuAccess.ModuleCode
                                    )
                                )
                                {
                                    menuAccess.Priority = 0;
                                    menuAccess.WebLink = "";
                                    menuAccess.LandingPageUrl = "";
                                }
                                else
                                {
                                    menuAccess.Priority = 0;
                                    menuAccess.WebLink =
                                        (
                                            string.IsNullOrEmpty(menuAccess.LockedWebLink)
                                            || restrictAmfForLockedWeblinkRoleIds.Contains(
                                                userRoleId
                                            )
                                        )
                                            ? ""
                                            : (
                                                checkSumValid
                                                    ? $"{menuAccess.LockedWebLink}?moduleCode={menuAccess.ModuleCode}&chksum={checkSum}"
                                                    : menuAccess.LockedWebLink
                                            ); //if tenant didn't bought package then give WebLink = LockedWebLink.
                                    menuAccess.LandingPageUrl = "";
                                }
                            }
                        });
                });

                return menuAccessList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Module GetMenus Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public Model.ModuleAccess GetModuleAccess(Model.SecurityAccess securityAccess)
        {
            try
            {
                #region Instances
                List<ModuleFeatureList> moduleFeaturesAccess = null;
                List<Model.TenantPackage> tenantPackage = null;
                Model.ModuleAccess moduleAccess = new Model.ModuleAccess();
                #endregion

                #region Variables
                string spTAP = this.Configuration["StoredProcedure:GetTenantAccessPackages"];
                string spATL = this.Configuration["StoredProcedure:GetAccessTenantLocations"];
                long userId = Convert.ToInt64(this.UserId);
                long tenantId = Convert.ToInt64(this.TenantId);
                long locationId = Convert.ToInt64(this.LocationId);
                long userRoleId = Convert.ToInt64(this.UserRole);
                #endregion

                // Get the tenant module access using moduleCode and locationIds.
                tenantPackage = this.Repository
                    .GetTenantPackage(
                        securityAccess,
                        userId,
                        tenantId,
                        locationId,
                        userRoleId,
                        spTAP,
                        spATL
                    )
                    .Result;
                if (
                    tenantPackage.Count > 0
                    && tenantPackage.Any(
                        tenantPackageItem =>
                            tenantPackageItem.ModuleCode.ToLower()
                            == securityAccess.ModuleCode.ToLower()
                    )
                )
                {
                    // Get the module feature access using moduleCode and locationIds.
                    moduleFeaturesAccess = GetModuleFeaturesAccess(securityAccess);
                    if (
                        moduleFeaturesAccess.Count > 0
                        && moduleFeaturesAccess.Any(
                            moduleFeaturesAccessItem =>
                                moduleFeaturesAccessItem.ModuleCode.ToLower()
                                == securityAccess.ModuleCode.ToLower()
                        )
                    )
                    {
                        bool tenantAccess = false;
                        moduleFeaturesAccess
                            .Where(
                                moduleFeaturesAccessItem =>
                                    moduleFeaturesAccessItem.ModuleCode.ToLower()
                                    == securityAccess.ModuleCode.ToLower()
                            )
                            .ToList()
                            .ForEach(moduleFeature =>
                            {
                                if (moduleFeature.features.Any(item => item.AccessLevel == 1))
                                {
                                    tenantAccess = true;
                                }
                            });
                        if (tenantAccess == true)
                        {
                            moduleAccess.access = true;
                            moduleAccess.message =
                                $"This User or UserRole have access for this Module";
                        }
                        else
                        {
                            moduleAccess.access = false;
                            moduleAccess.message =
                                $"This User or UserRole doesn't have access for this Module";
                        }
                    }
                    else
                    {
                        moduleAccess.access = false;
                        moduleAccess.message =
                            $"This User or UserRole doesn't have access for this Module";
                    }
                }
                else
                {
                    moduleAccess.access = false;
                    moduleAccess.message = $"This feature doesn't include in your package";
                }
                return moduleAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Get Package Access Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.ModuleFeatureList> GetModuleFeaturesAccessWithTenantId(
            Model.SecurityAccessWithTenantId securityAccess
        )
        {
            try
            {
                #region Instances
                List<ModuleFeatureList> moduleFeatureList = new List<ModuleFeatureList>();
                List<Model.ModuleFeatures> moduleFeatureAccessList = null;
                #endregion

                #region Variables
                byte disabled = 0;
                string spMFA = this.Configuration["StoredProcedure:GetModuleFeaturesAccess"];
                string spMF = this.Configuration["StoredProcedure:GetModuleFeatures"];
                string spTAP = this.Configuration["StoredProcedure:GetTenantAccessPackages"];
                string spATL = this.Configuration["StoredProcedure:GetAccessTenantLocations"];
                long userId = Convert.ToInt64(securityAccess.UserId);
                long tenantId = Convert.ToInt64(securityAccess.TenantId);
                long locationId = Convert.ToInt64(this.LocationId);
                long userRoleId = Convert.ToInt64(securityAccess.RoleId);
                List<long> restrictAmfForLockedWeblinkRoleIds = this.Configuration[
                    "xtraCHEF:RestrictAmfForLockedWeblinkRoleIds"
                ]
                    .Trim()
                    .Split(",")
                    .Select(x => Convert.ToInt64(x))
                    .ToList();
                bool checkSumValid = Convert.ToBoolean(
                    this.Configuration["xtraCHEF:AMFCheckSumRequired"]
                );
                #endregion
                Model.SecurityAccess SecAccess = new Model.SecurityAccess()
                {
                    ModuleCode = securityAccess.ModuleCode,
                    Endpoint = securityAccess.Endpoint,
                    LocationIds = securityAccess.LocationIds
                };
                //get the Module Feature Access List
                moduleFeatureAccessList = this.Repository
                    .GetModuleFeaturesAccess(
                        userId,
                        tenantId,
                        locationId,
                        userRoleId,
                        SecAccess,
                        spMF,
                        spMFA,
                        spTAP,
                        spATL,
                        restrictAmfForLockedWeblinkRoleIds
                    )
                    .Result;

                //get the module feature access list with appropiate data
                if ((moduleFeatureAccessList != null) && (moduleFeatureAccessList.Count > 0))
                {
                    List<string> moduleCodes = moduleFeatureAccessList
                        .Select(x => x.ModuleCode)
                        .Distinct()
                        .ToList();
                    foreach (string moduleCode in moduleCodes)
                    {
                        List<FeaturesDetail> featuresAccess = new List<FeaturesDetail>();
                        moduleFeatureAccessList
                            .Where(moduleFeature => moduleFeature.ModuleCode == moduleCode)
                            .ToList()
                            .ForEach(moduleFeatureAccess =>
                            {
                                string checkSum = string.Empty;
                                if (checkSumValid)
                                {
                                    // In order for user to prevent an URL tempering, we should add a check sum value to the URL. Here is the step to generate a check sum.
                                    checkSum = EncryptionHelper.EnDecrypt(
                                        $"tenantId={tenantId}&userId={userId}&roleId={userRoleId}&featureCode={moduleFeatureAccess.FeatureCode}".Trim()
                                    );
                                }
                                FeaturesDetail featureAccess = new FeaturesDetail();
                                featureAccess.FeatureCode = moduleFeatureAccess.FeatureCode;
                                featureAccess.FeatureName = moduleFeatureAccess.FeatureName;
                                featureAccess.Caption = moduleFeatureAccess.Caption;
                                featureAccess.WebLink = string.IsNullOrEmpty(
                                    moduleFeatureAccess.WebLink
                                )
                                    ? ""
                                    : (
                                        checkSumValid
                                            ? $"{moduleFeatureAccess.WebLink}?featureCode={moduleFeatureAccess.FeatureCode}&chksum={checkSum}"
                                            : moduleFeatureAccess.WebLink
                                    );
                                featureAccess.Endpoint = string.IsNullOrEmpty(
                                    moduleFeatureAccess.Endpoint
                                )
                                    ? ""
                                    : moduleFeatureAccess.Endpoint;
                                featureAccess.ParentFeatureKey =
                                    moduleFeatureAccess.ParentFeatureKey;
                                featureAccess.AccessLevel =
                                    moduleFeatureAccess.AccessLevel == null
                                        ? disabled
                                        : moduleFeatureAccess.AccessLevel;
                                featureAccess.PackageCodes = moduleFeatureAccess.PackageCodes;
                                featuresAccess.Add(featureAccess);
                            });
                        ModuleFeatureList moduleFeatureDetail = new ModuleFeatureList();
                        moduleFeatureDetail.ModuleCode = moduleCode;
                        moduleFeatureDetail.ModuleName = moduleFeatureAccessList
                            .Where(moduleFeature => moduleFeature.ModuleCode == moduleCode)
                            .FirstOrDefault()
                            .ModuleName;
                        moduleFeatureDetail.features = featuresAccess;
                        moduleFeatureList.Add(moduleFeatureDetail);
                    }
                }

                //return the module feature with access level
                return moduleFeatureList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError(
                    $"When GetModuleFeaturesAccessWithTenantId Error : {ex.Message}"
                );
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.ModuleFeatureList> GetModuleFeaturesAccessNew(
            Model.SecurityAccessWithTenantId securityAccess,
            System.Guid guidId
        )
        {
            try
            {
                #region Instances
                List<Model.NewModuleFeatureAccess> moduleFeatureAccess = null;
                List<ModuleFeatureList> moduleFeatureList = new List<ModuleFeatureList>();

                #endregion

                #region Variables
                byte disabled = 0;
                
                long locationId =
                    securityAccess.LocationIds.Count > 0
                        ? Convert.ToInt64(securityAccess.LocationIds[0])
                        : 0;
                #endregion

                this.Logger.LogInfo(
                    $"Service GetModuleFeaturesAccessNew Start (new module features access) - guidId : {guidId}"
                );
                //get the menu access list
                if(securityAccess.DB != null && securityAccess.DB.ToLower() == MSSQL)
                {
                    string spMFAN = "XC_GET_MODULE_FEATURE_ACCESS_NEW";
                    moduleFeatureAccess = this.Repository
                    .GetModuleFeaturesAccessNewMSSQL(securityAccess, locationId, spMFAN)
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetModuleFeaturesAccessNewMSSQL End (new module features access) - guidId : {guidId}"
                    );

                }
                else
                {
                    moduleFeatureAccess = this.Repository
                    .GetModuleFeaturesAccessNewPostgresql(securityAccess, locationId)
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetModuleFeaturesAccessNewPostgresql End (new module features access) - guidId : {guidId}"
                    );
                }

                if (moduleFeatureAccess.Count > 0)
                {
                    List<FeaturesDetail> featuresAccess = new List<FeaturesDetail>();
                    foreach (
                        Model.NewModuleFeatureAccess newModuleFeatureAccessItem in moduleFeatureAccess
                    )
                    {
                        FeaturesDetail featureAccess = new FeaturesDetail();
                        featureAccess.FeatureCode = newModuleFeatureAccessItem.ModulefeatureCode;
                        featureAccess.FeatureName = newModuleFeatureAccessItem.Name;
                        featureAccess.AccessLevel =
                            newModuleFeatureAccessItem.AccessLevel == null
                                ? disabled
                                : newModuleFeatureAccessItem.AccessLevel;
                        featureAccess.Caption = newModuleFeatureAccessItem.Caption;
                        featureAccess.WebLink =
                            featureAccess.AccessLevel == disabled
                            || string.IsNullOrEmpty(newModuleFeatureAccessItem.WebLink)
                                ? ""
                                : newModuleFeatureAccessItem.WebLink;
                        featureAccess.Endpoint = string.IsNullOrEmpty(
                            newModuleFeatureAccessItem.Endpoint
                        )
                            ? ""
                            : newModuleFeatureAccessItem.Endpoint;
                        featureAccess.ParentFeatureKey = string.IsNullOrEmpty(
                            newModuleFeatureAccessItem.ParentFeatureKey
                        )
                            ? null
                            : newModuleFeatureAccessItem.ParentFeatureKey;
                        featureAccess.PackageCodes =
                            newModuleFeatureAccessItem.PackageCode == null
                                ? null
                                : newModuleFeatureAccessItem.PackageCode
                                    .Split('|', StringSplitOptions.RemoveEmptyEntries)
                                    .ToList()
                                    .Count > 0
                                    ? newModuleFeatureAccessItem.PackageCode
                                        .Split('|', StringSplitOptions.RemoveEmptyEntries)
                                        .ToList()
                                    : null;
                        featureAccess.AllowAllLocation =
                            newModuleFeatureAccessItem.AllowAllLocation;
                        featuresAccess.Add(featureAccess);
                    }
                    ModuleFeatureList moduleFeatureDetail = new ModuleFeatureList()
                    {
                        ModuleCode = moduleFeatureAccess[0].ModulefeatureCode,
                        ModuleName = moduleFeatureAccess[0].Name,
                        features = featuresAccess
                    };
                    moduleFeatureList.Add(moduleFeatureDetail);
                }
                return moduleFeatureList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Module GetMenus Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.MenuAccess> GetMenusAccessNew(
            Model.SecurityAccess securityAccess,
            System.Guid guidId
        )
        {
            try
            {
                #region Instances
                List<Model.NewMenuAccess> newMenuAccess = null;
                List<Model.MenuAccess> menuAccessList = new List<Model.MenuAccess>();
                #endregion

                #region Variables
                byte disabled = 0;
                
                long userId = Convert.ToInt64(this.UserId);
                long tenantId = Convert.ToInt64(this.TenantId);
                long locationId =
                    securityAccess.LocationIds.Count > 0
                        ? Convert.ToInt64(securityAccess.LocationIds[0])
                        : 0;
                long userRoleId = Convert.ToInt64(this.UserRole);
                List<long> restrictAmfForLockedWeblinkRoleIds = this.Configuration[
                    "xtraCHEF:RestrictAmfForLockedWeblinkRoleIds"
                ]
                    .Trim()
                    .Split(",")
                    .Select(x => Convert.ToInt64(x))
                    .ToList();
                bool checkSumValid = Convert.ToBoolean(
                    this.Configuration["xtraCHEF:AMFCheckSumRequired"]
                );
                #endregion

                this.Logger.LogInfo(
                    $"Service GetMenusAccessNew Start (new menus access) - guidId : {guidId}"
                );
                //get the menu access list
                if(securityAccess.DB != null && securityAccess.DB.ToLower() == MSSQL)
                {
                    string spMAN = "XC_GET_MENU_ACCESS_NEW";
                    newMenuAccess = this.Repository
                    .GetMenusAccessNewMSSQL(userId, tenantId, locationId, userRoleId, spMAN)
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetMenusAccessNewMSSQL End (new menus access) - guidId : {guidId}"
                    );
                }
                else
                {
                    newMenuAccess = this.Repository
                    .GetMenusAccessNewPostgresql(userId, tenantId, locationId, userRoleId)
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetMenusAccessNewPostgresql End (new menus access) - guidId : {guidId}"
                    );
                }
                
                if (newMenuAccess.Count > 0)
                {
                    foreach (Model.NewMenuAccess newMenuAccessItem in newMenuAccess)
                    {
                        Model.MenuAccess menuAccessItem = new Model.MenuAccess();
                        menuAccessItem.WebUrl = newMenuAccessItem.WebLink; //adding weblink into weburl to check that user access is provided
                        menuAccessItem.ModuleId = newMenuAccessItem.ModuleId;
                        menuAccessItem.ModuleCode = newMenuAccessItem.ModuleCode;
                        menuAccessItem.ModuleName = newMenuAccessItem.ModuleName;
                        menuAccessItem.MenuCaption = newMenuAccessItem.MenuCaption;
                        menuAccessItem.PackageCodes =
                            newMenuAccessItem.AccessLevel == disabled
                            || newMenuAccessItem.PackageCode == null
                                ? null
                                : newMenuAccessItem.PackageCode
                                    .Split('|', StringSplitOptions.RemoveEmptyEntries)
                                    .ToList();
                        menuAccessItem.WebLink =
                            newMenuAccessItem.AccessLevel == disabled
                                ? (
                                    restrictAmfForLockedWeblinkRoleIds.Contains(userRoleId)
                                        ? ""
                                        : newMenuAccessItem.LockedWebLink
                                )
                                : newMenuAccessItem.WebLink; //if tenant didn't bought package then give WebLink = LockedWebLink.
                        menuAccessItem.AccessLevel = newMenuAccessItem.AccessLevel;
                        menuAccessItem.Beta = newMenuAccessItem.Beta;
                        menuAccessItem.Priority =
                            newMenuAccessItem.AccessLevel == disabled
                                ? disabled
                                : newMenuAccessItem.Priority;
                        menuAccessItem.SequenceNumber = newMenuAccessItem.SequenceNumber;
                        menuAccessItem.LandingPageUrl =
                            newMenuAccessItem.AccessLevel == disabled
                                ? ""
                                : newMenuAccessItem.LandingPageUrl;
                        menuAccessItem.MenuGroup = newMenuAccessItem.MenuGroup;
                        menuAccessItem.GroupId =
                            newMenuAccessItem.GroupId == 0 ? null : newMenuAccessItem.GroupId;
                        menuAccessItem.GroupIdDescription =
                            newMenuAccessItem.GroupIdDescription == ""
                                ? null
                                : newMenuAccessItem.GroupIdDescription;
                        menuAccessItem.GroupIdSortOrder =
                            newMenuAccessItem.GroupIdSortOrder == 0
                                ? null
                                : newMenuAccessItem.GroupIdSortOrder;
                        menuAccessItem.AllowAllLocation = newMenuAccessItem.AllowAllLocation;
                        menuAccessList.Add(menuAccessItem);
                    }
                }
                return menuAccessList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Module GetMenus Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.MobileMenuAccessList> GetMobileMenusAccess(
            Model.SecurityAccess securityAccess,
            System.Guid guidId
        )
        {
            try
            {
                #region Instances
                List<Model.MobileMenuAccess> newMenuAccess = null;
                List<Model.MobileMenuAccessList> menuAccessList =
                    new List<Model.MobileMenuAccessList>();
                #endregion

                #region Variables
                byte disabled = 0;
                long userId = Convert.ToInt64(this.UserId);
                long tenantId = Convert.ToInt64(this.TenantId);
                long locationId =
                    securityAccess.LocationIds.Count > 0
                        ? Convert.ToInt64(securityAccess.LocationIds[0])
                        : 0;
                string versionNumber = securityAccess.versionNumber;
                long userRoleId = Convert.ToInt64(this.UserRole);
                List<long> restrictAmfForLockedWeblinkRoleIds = this.Configuration[
                    "xtraCHEF:RestrictAmfForLockedWeblinkRoleIds"
                ]
                    .Trim()
                    .Split(",")
                    .Select(x => Convert.ToInt64(x))
                    .ToList();
                bool checkSumValid = Convert.ToBoolean(
                    this.Configuration["xtraCHEF:AMFCheckSumRequired"]
                );
                #endregion

                this.Logger.LogInfo(
                    $"Service GetMobileMenusAccess Start (new mobile menus access) - guidId : {guidId}"
                );
                //get the menu access list
                if(securityAccess.DB != null && securityAccess.DB.ToLower() == MSSQL)
                {
                    string spMAN = "XC_GET_MOBILE_MENU_ACCESS";
                    newMenuAccess = this.Repository
                    .GetMobileMenusAccessMSSQL(
                        userId,
                        tenantId,
                        locationId,
                        userRoleId,
                        versionNumber,
                        spMAN
                    )
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetMobileMenusAccessMSSQL End (new mobile menus access) - guidId : {guidId}"
                    );
                }
                else
                {
                    newMenuAccess = this.Repository
                    .GetMobileMenusAccessPostgresql(
                        userId,
                        tenantId,
                        locationId,
                        userRoleId,
                        versionNumber
                    )
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetMobileMenusAccessPostgresql End (new mobile menus access) - guidId : {guidId}"
                    );
                }

                if (newMenuAccess.Count > 0)
                {
                    foreach (Model.MobileMenuAccess newMenuAccessItem in newMenuAccess)
                    {
                        Model.MobileMenuAccessList menuAccessItem =
                            new Model.MobileMenuAccessList();
                        menuAccessItem.WebUrl = newMenuAccessItem.WebLink; //adding weblink into weburl to check that user access is provided
                        menuAccessItem.ModuleId = newMenuAccessItem.ModuleId;
                        menuAccessItem.ModuleCode = newMenuAccessItem.ModuleCode;
                        menuAccessItem.ModuleName = newMenuAccessItem.ModuleName;
                        menuAccessItem.MenuCaption = newMenuAccessItem.MenuCaption;
                        menuAccessItem.PackageCodes =
                            newMenuAccessItem.AccessLevel == disabled
                            || newMenuAccessItem.PackageCode == null
                                ? null
                                : newMenuAccessItem.PackageCode
                                    .Split('|', StringSplitOptions.RemoveEmptyEntries)
                                    .ToList();
                        menuAccessItem.WebLink =
                            newMenuAccessItem.AccessLevel == disabled
                                ? (
                                    restrictAmfForLockedWeblinkRoleIds.Contains(userRoleId)
                                        ? ""
                                        : newMenuAccessItem.LockedWebLink
                                )
                                : newMenuAccessItem.WebLink; //if tenant didn't bought package then give WebLink = LockedWebLink.
                        menuAccessItem.AccessLevel = newMenuAccessItem.AccessLevel;
                        menuAccessItem.Beta = newMenuAccessItem.Beta;
                        menuAccessItem.Priority =
                            newMenuAccessItem.AccessLevel == disabled
                                ? disabled
                                : newMenuAccessItem.Priority;
                        menuAccessItem.SequenceNumber = newMenuAccessItem.SequenceNumber;
                        menuAccessItem.LandingPageUrl =
                            newMenuAccessItem.AccessLevel == disabled
                                ? ""
                                : newMenuAccessItem.LandingPageUrl;
                        menuAccessItem.MenuGroup = newMenuAccessItem.MenuGroup;
                        menuAccessItem.GroupId =
                            newMenuAccessItem.GroupId == 0 ? null : newMenuAccessItem.GroupId;
                        menuAccessItem.GroupIdDescription =
                            newMenuAccessItem.GroupIdDescription == ""
                                ? null
                                : newMenuAccessItem.GroupIdDescription;
                        menuAccessItem.GroupIdSortOrder =
                            newMenuAccessItem.GroupIdSortOrder == 0
                                ? null
                                : newMenuAccessItem.GroupIdSortOrder;
                        menuAccessItem.VersionNumber = newMenuAccessItem.VersionNumber;
                        menuAccessItem.AllowAllLocation = newMenuAccessItem.AllowAllLocation;
                        menuAccessList.Add(menuAccessItem);
                    }
                }
                return menuAccessList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"GetMobileMenusAccess Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.ModuleFeatureList> GetMobileModuleFeaturesAccess(
            Model.SecurityAccessWithTenantId securityAccess,
            System.Guid guidId
        )
        {
            try
            {
                #region Instances
                List<Model.NewModuleFeatureAccess> moduleFeatureAccess = null;
                List<ModuleFeatureList> moduleFeatureList = new List<ModuleFeatureList>();

                #endregion

                #region Variables
                byte disabled = 0;
                long locationId =
                    securityAccess.LocationIds.Count > 0
                        ? Convert.ToInt64(securityAccess.LocationIds[0])
                        : 0;
                #endregion

                this.Logger.LogInfo(
                    $"Service GetMobileModuleFeaturesAccess Start (new mobile module features access) - guidId : {guidId}"
                );
                //get the menu access list
                if(securityAccess.DB != null && securityAccess.DB.ToLower() == MSSQL)
                {
                    string spMFAN = "XC_GET_MOBILE_MODULE_FEATURE_ACCESS";
                    moduleFeatureAccess = this.Repository
                    .GetMobileModuleFeaturesAccessMSSQL(securityAccess, locationId, spMFAN)
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetMobileModuleFeaturesAccessMSSQL End (new mobile module features access) - guidId : {guidId}"
                    );
                }
                else
                {
                    moduleFeatureAccess = this.Repository
                    .GetMobileModuleFeaturesAccessPostgresql(securityAccess, locationId)
                    .Result;
                    this.Logger.LogInfo(
                        $"Service GetMobileModuleFeaturesAccessPostgresql End (new mobile module features access) - guidId : {guidId}"
                    );
                }
                

                if (moduleFeatureAccess.Count > 0)
                {
                    List<FeaturesDetail> featuresAccess = new List<FeaturesDetail>();
                    foreach (
                        Model.NewModuleFeatureAccess newModuleFeatureAccessItem in moduleFeatureAccess
                    )
                    {
                        FeaturesDetail featureAccess = new FeaturesDetail();
                        featureAccess.FeatureCode = newModuleFeatureAccessItem.ModulefeatureCode;
                        featureAccess.FeatureName = newModuleFeatureAccessItem.Name;
                        featureAccess.AccessLevel =
                            newModuleFeatureAccessItem.AccessLevel == null
                                ? disabled
                                : newModuleFeatureAccessItem.AccessLevel;
                        featureAccess.Caption = newModuleFeatureAccessItem.Caption;
                        featureAccess.WebLink =
                            featureAccess.AccessLevel == disabled
                            || string.IsNullOrEmpty(newModuleFeatureAccessItem.WebLink)
                                ? ""
                                : newModuleFeatureAccessItem.WebLink;
                        featureAccess.Endpoint = string.IsNullOrEmpty(
                            newModuleFeatureAccessItem.Endpoint
                        )
                            ? ""
                            : newModuleFeatureAccessItem.Endpoint;
                        featureAccess.ParentFeatureKey = string.IsNullOrEmpty(
                            newModuleFeatureAccessItem.ParentFeatureKey
                        )
                            ? null
                            : newModuleFeatureAccessItem.ParentFeatureKey;
                        featureAccess.PackageCodes =
                            newModuleFeatureAccessItem.PackageCode == null
                                ? null
                                : newModuleFeatureAccessItem.PackageCode
                                    .Split('|', StringSplitOptions.RemoveEmptyEntries)
                                    .ToList()
                                    .Count > 0
                                    ? newModuleFeatureAccessItem.PackageCode
                                        .Split('|', StringSplitOptions.RemoveEmptyEntries)
                                        .ToList()
                                    : null;
                        featureAccess.AllowAllLocation =
                            newModuleFeatureAccessItem.AllowAllLocation;
                        featuresAccess.Add(featureAccess);
                    }
                    ModuleFeatureList moduleFeatureDetail = new ModuleFeatureList()
                    {
                        ModuleCode = moduleFeatureAccess[0].ModulefeatureCode,
                        ModuleName = moduleFeatureAccess[0].Name,
                        features = featuresAccess
                    };
                    moduleFeatureList.Add(moduleFeatureDetail);
                }
                return moduleFeatureList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"GetMobileModuleFeaturesAccess Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
