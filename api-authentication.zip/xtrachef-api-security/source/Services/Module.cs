﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Repository;
using System.Collections.Generic;
using System.Configuration;

namespace XtraChef.API.Security.Query.Services
{
    public class Module : APIServiceBase
    {
        #region Variables

        private readonly Repository.Module Repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Service.Module"/> class.
        /// </summary>
        /// <param name="repository">Repository.</param>
        /// <param name="factory">Factory.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public Module(
            Repository.Module repository,
            IConfiguration configuration,
            LogPublisher logPublisher,
            AuditRepository xcAudit,
            ValidationRepository xcValidation
        )
            : base(configuration, logPublisher, xcAudit, xcValidation)
        {
            //Module
            this.Repository = repository;
        }

        #endregion

        #region Public Methods

        public Model.Module GetModuleById(string moduleId)
        {
            try
            {
                Model.ModuleFeature moduleItem = this.Repository.GetModuleById(moduleId).Result;
                Model.Module moduleDetail = new Model.Module();

                if (moduleItem != null)
                {
                    moduleDetail = this.Repository.GetModule(moduleItem);
                }

                return moduleDetail == null ? null : moduleDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Module GetModuleById Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public List<Model.ModuleFeature> GetModulesDetail()
        {
            try
            {
                List<Model.ModuleFeature> modulesDetail = this.Repository.GetModulesDetail().Result;

                return modulesDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Module GetModulesDetail Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
