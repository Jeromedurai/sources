﻿using Newtonsoft.Json;
using Sa.Common.Utility;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    [Table("XC_PACKAGE_MASTER")]
    public class Package : BaseModel
    {
        #region Overridden Property

        [JsonIgnore, NotMapped]
        public override long Id { get; set; }

        [JsonProperty("guid"), Column("GUID")]
        public override string Guid { get; set; }

        [JsonIgnore, NotMapped]
        public override string TenantId { get; set; }

        [JsonIgnore, NotMapped]
        public override string LocationId { get; set; }

        [
            JsonProperty("created"),
            Column("Created"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime Created { get; set; }

        [JsonProperty("lastModifiedBy"), Column("LastModifiedBy")]
        public new long LastModifiedBy { get; set; }

        [JsonProperty("createdBy"), Column("CreatedBy")]
        public new long CreatedBy { get; set; }

        [
            JsonProperty("lastModified"),
            Column("LastModified"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime LastModified { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        #endregion

        #region Public Property

        [Key, JsonProperty("Pk"), Column("Pk"), DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Pk { get; set; }

        [JsonProperty("description"), Column("Description")]
        public string Description { get; set; }

        [JsonProperty("tagName"), Column("TagName")]
        public string TagName { get; set; }

        [JsonProperty("allowedDocument"), Column("AllowedDocument")]
        public long AllowedDocument { get; set; }

        [JsonProperty("overageCharge"), Column("OverageCharge")]
        public decimal OverageCharge { get; set; }

        [JsonProperty("listPrice"), Column("ListPrice")]
        public decimal ListPrice { get; set; }

        [JsonProperty("listPriceType"), Column("ListPriceType")]
        public int ListPriceType { get; set; }

        [JsonProperty("validFrom"), Column("ValidFrom")]
        public DateTime ValidFrom { get; set; }

        [JsonProperty("expiresOn"), Column("ExpiresOn")]
        public DateTime ExpiresOn { get; set; }

        [JsonProperty("json"), Column("Json")]
        public string Json { get; set; }

        [JsonProperty("code"), Column("Code")]
        public string Code { get; set; }

        #endregion
    }
}
