﻿using Newtonsoft.Json;
using Sa.Common.Utility;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    [Table("XC_MODULE_FEATURE_MASTER")]
    public class ModuleFeature : BaseModel
    {
        #region Property

        [Key, JsonProperty("Pk"), Column("Pk")]
        public long Pk { get; set; }

        [JsonProperty("moduleFeatureCode"), Column("ModuleFeatureCode")]
        public string ModuleFeatureCode { get; set; }

        [JsonProperty("name"), Column("Name")]
        public string Name { get; set; }

        [JsonProperty("Caption"), Column("Caption")]
        public string Caption { get; set; }

        [JsonProperty("type"), Column("Type")]
        public new string Type { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [JsonProperty("system"), Column("System")]
        public int System { get; set; }

        [JsonProperty("listPrice"), Column("ListPrice")]
        public decimal ListPrice { get; set; }

        [JsonProperty("listPriceType"), Column("ListPriceType")]
        public int ListPriceType { get; set; }

        [JsonProperty("validFrom"), Column("ValidFrom")]
        public DateTime ValidFrom { get; set; }

        [JsonProperty("expiresOn"), Column("ExpiresOn")]
        public DateTime ExpiresOn { get; set; }

        [JsonProperty("active"), Column("Active")]
        public byte Active { get; set; }

        [JsonProperty("parentFeatureKey"), Column("ParentFeatureKey")]
        public string ParentFeatureKey { get; set; }

        [JsonProperty("endpoint"), Column("Endpoint")]
        public string Endpoint { get; set; }

        [JsonProperty("beta"), Column("Beta")]
        public byte Beta { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("priority"), Column("Priority")]
        public long Priority { get; set; }

        [JsonProperty("json"), Column("Json")]
        public string Json { get; set; }

        [JsonProperty("menuGroup"), Column("MenuGroup")]
        public long MenuGroup { get; set; }

        #endregion

        #region  overridden

        [JsonIgnore, NotMapped]
        public override string LocationId { get; set; }

        [
            JsonProperty("created"),
            Column("Created"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime Created { get; set; }

        [JsonProperty("lastModifiedBy"), Column("LastModifiedBy")]
        public new long LastModifiedBy { get; set; }

        [JsonProperty("createdBy"), Column("CreatedBy")]
        public new long CreatedBy { get; set; }

        [
            JsonProperty("lastModified"),
            Column("LastModified"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime LastModified { get; set; }

        [JsonProperty("guid"), Column("GUID")]
        public override string Guid { get; set; }

        [JsonIgnore, NotMapped]
        public override long Id { get; set; }

        [JsonIgnore, NotMapped]
        public override string TenantId { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        #endregion
    }
}
