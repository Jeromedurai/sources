﻿using Newtonsoft.Json;
using Sa.Common.Utility;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    [Table("XC_PACKAGE_DETAIL")]
    public class PackageDetail : BaseModel
    {
        #region Overridden Property

        [Key, JsonProperty("id"), Column("Id")]
        public override long Id { get; set; }

        [JsonIgnore, NotMapped]
        public override string Guid { get; set; }

        [JsonIgnore, NotMapped]
        public override string TenantId { get; set; }

        [JsonIgnore, NotMapped]
        public override string LocationId { get; set; }

        [
            JsonProperty("created"),
            Column("Created"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime Created { get; set; }

        [JsonProperty("lastModifiedBy"), Column("LastModifiedBy")]
        public new long LastModifiedBy { get; set; }

        [JsonProperty("createdBy"), Column("CreatedBy")]
        public new long CreatedBy { get; set; }

        [
            JsonProperty("lastModified"),
            Column("LastModified"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime LastModified { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        #endregion

        #region Public Property

        [JsonProperty("packageCode"), Column("PackageCode")]
        public string PackageCode { get; set; }

        [JsonProperty("packageName"), Column("PackageName")]
        public string PackageName { get; set; }

        [JsonProperty("moduleFeatureCode"), Column("ModuleFeatureCode")]
        public string ModuleFeatureCode { get; set; }

        [JsonProperty("moduleFeatureName"), Column("ModuleFeatureName")]
        public string ModuleFeatureName { get; set; }

        #endregion
    }
}
