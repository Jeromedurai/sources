﻿using Newtonsoft.Json;
using Sa.Common.Utility;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    [Table("XC_MODULE_ACCESS_GROUP_DETAIL")]
    public class AccessGroupDetail : BaseModel
    {
        #region Overridden Property

        [Key, JsonProperty("id"), Column("Id"), DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public override long Id { get; set; }

        [JsonIgnore, NotMapped]
        public override string Guid { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        [JsonIgnore, NotMapped]
        public override string TenantId { get; set; }

        [JsonIgnore, NotMapped]
        public override string LocationId { get; set; }

        [JsonProperty("createdBy"), Column("CreatedBy")]
        public new long CreatedBy { get; set; }

        [
            JsonProperty("created"),
            Column("Created"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime Created { get; set; }

        [JsonProperty("lastModifiedBy"), Column("LastModifiedBy")]
        public new long LastModifiedBy { get; set; }

        [
            JsonProperty("lastModified"),
            Column("LastModified"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime LastModified { get; set; }

        #endregion

        #region Public Property

        [JsonProperty("accessGroupId"), Column("AccessGroupId")]
        public long AccessGroupId { get; set; }

        [JsonProperty("accessGroupName"), Column("AccessGroupName")]
        public string AccessGroupName { get; set; }

        [JsonProperty("moduleFeatureCode"), Column("ModuleFeatureCode")]
        public string ModuleFeatureCode { get; set; }

        [JsonProperty("moduleFeatureName"), Column("ModuleFeatureName")]
        public string ModuleFeatureName { get; set; }

        [JsonProperty("accessLevel"), Column("AccessLevel")]
        public byte? AccessLevel { get; set; }

        #endregion
    }
}
