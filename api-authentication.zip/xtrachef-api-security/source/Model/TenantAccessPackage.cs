﻿using Newtonsoft.Json;
using Sa.Common.Utility;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    [Table("XC_TENANT_ACCESS_PACKAGE")]
    public class TenantAccessPackage : BaseModel
    {
        #region Public Property

        [JsonProperty("packageCode"), Column("PackageCode")]
        public string PackageCode { get; set; }

        [JsonProperty("packageName"), Column("PackageName")]
        public string PackageName { get; set; }

        #endregion

        #region Overridden Property

        [Key, JsonProperty("id"), Column("Id"), DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public override long Id { get; set; }

        [JsonIgnore, NotMapped]
        public override string Guid { get; set; }

        [JsonProperty("tenantId"), Column("TenantId")]
        public new long TenantId { get; set; }

        [JsonProperty("locationId"), Column("LocationId")]
        public new long LocationId { get; set; }

        [
            JsonProperty("created"),
            Column("Created"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime Created { get; set; }

        [JsonProperty("lastModifiedBy"), Column("LastModifiedBy")]
        public new long LastModifiedBy { get; set; }

        [JsonProperty("createdBy"), Column("CreatedBy")]
        public new long CreatedBy { get; set; }

        [
            JsonProperty("lastModified"),
            Column("LastModified"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime LastModified { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        #endregion
    }

    public class TenantAccessPackages
    {
        public long tenantId { get; set; }
        public long locationId { get; set; }
        public List<Packages> packages { get; set; }
    }

    public class Packages
    {
        public long id { get; set; }
        public string name { get; set; }
        public List<Modules> modules { get; set; }
    }

    public class Modules
    {
        public long id { get; set; }
        public long name { get; set; }
        public List<FeatureDetail> features { get; set; }
    }

    public class FeatureDetail
    {
        public long id { get; set; }
        public long name { get; set; }
        public byte access { get; set; }
    }
}
