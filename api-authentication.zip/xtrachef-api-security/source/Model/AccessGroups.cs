﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace XtraChef.API.Security.Query.Model
{
    public class AccessGroupList
    {
        public long tenantId { get; set; }
        public long locationId { get; set; }
        public List<Group> groups { get; set; }
    }

    public class Group
    {
        public long? id { get; set; }
        public string accessGroupName { get; set; }
        public List<AccessGroupModule> modules { get; set; }
    }

    public class AccessGroupModule
    {
        public long? id { get; set; }
        public string moduleName { get; set; }
        public List<AccessGroupFeature> features { get; set; }
    }

    public class AccessGroupFeature
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("featureName")]
        public string featureName { get; set; }

        [JsonProperty("accessLevel")]
        public byte? accessLevel { get; set; }
    }
}
