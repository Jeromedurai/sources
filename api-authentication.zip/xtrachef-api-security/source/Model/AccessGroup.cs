﻿using Newtonsoft.Json;
using Sa.Common.Utility;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    [Table("XC_MODULE_ACCESS_GROUP_MASTER")]
    public class AccessGroup : BaseModel
    {
        #region Overridden Property

        [Key, JsonProperty("id"), Column("Id"), DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public override long Id { get; set; }

        [JsonIgnore, NotMapped]
        public override string Guid { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        [JsonProperty("tenantId"), Column("TenantId")]
        public new long TenantId { get; set; }

        [JsonProperty("locationId"), Column("LocationId")]
        public new long LocationId { get; set; }

        [JsonProperty("createdBy"), Column("CreatedBy")]
        public new long CreatedBy { get; set; }

        [
            JsonProperty("created"),
            Column("Created"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime Created { get; set; }

        [JsonProperty("lastModifiedBy"), Column("LastModifiedBy")]
        public new long LastModifiedBy { get; set; }

        [
            JsonProperty("lastModified"),
            Column("LastModified"),
            JsonConverter(typeof(XcUtil.Date.XcDateConverter))
        ]
        public override DateTime LastModified { get; set; }

        #endregion

        #region Public Property

        [JsonProperty("accessGroupname"), Column("AccessGroupname")]
        public string AccessGroupname { get; set; }

        #endregion
    }
}
