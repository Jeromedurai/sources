﻿using Newtonsoft.Json;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    [Table("XC_DEPENDENCY_MODULE_MASTER")]
    public class DependencyModule : BaseModel
    {
        #region  overridden Property

        [JsonIgnore, NotMapped]
        public override long Id { get; set; }

        [JsonIgnore, NotMapped]
        public override string Guid { get; set; }

        [JsonIgnore, NotMapped]
        public override string TenantId { get; set; }

        [JsonIgnore, NotMapped]
        public override string LocationId { get; set; }

        [JsonIgnore, NotMapped]
        public override DateTime Created { get; set; }

        [JsonIgnore, NotMapped]
        public new long LastModifiedBy { get; set; }

        [JsonIgnore, NotMapped]
        public new long CreatedBy { get; set; }

        [JsonIgnore, NotMapped]
        public override DateTime LastModified { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        #endregion

        #region Public Property

        [Key, JsonProperty("pk"), Column("Pk")]
        public long Pk { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [JsonProperty("dependencyModulesCode"), Column("DependencyModulesCode")]
        public string DependencyModulesCode { get; set; }

        #endregion
    }

    public class DependencyModules
    {
        [JsonProperty("pk"), Column("Pk")]
        public long Pk { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [JsonProperty("dependencyModulesCode"), Column("DependencyModulesCode")]
        public List<string> DependencyModulesCode { get; set; }
    }
}
