﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace XtraChef.API.Security.Query.Model
{
    public class OrderGuide
    {
        [JsonProperty("pk"), Key]
        public long Pk { get; set; }

        [JsonProperty("Name")]
        public string Name { get; set; }

        [JsonProperty("allLocation")]
        public bool AllLocation { get; set; }
    }
}
