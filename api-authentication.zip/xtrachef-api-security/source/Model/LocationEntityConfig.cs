﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace XtraChef.API.Security.Query.Model
{
    public class LocationEntityConfig
    {
        [JsonProperty("pk"), Key]
        public long Pk { get; set; }

        [JsonProperty("configKey")]
        public long ConfigKey { get; set; }

        [JsonProperty("configValue")]
        public long ConfigValue { get; set; }

        [JsonProperty("entityId")]
        public long EntityId { get; set; }

        [JsonProperty("tenantId")]
        public long TenantId { get; set; }

        [JsonProperty("active")]
        public bool Active { get; set; }

        [JsonProperty("created")]
        public DateTime Created { get; set; }

        [JsonProperty("createdBy")]
        public long CreatedBy { get; set; }

        [JsonProperty("lastModified")]
        public DateTime LastModified { get; set; }

        [JsonProperty("lastModifiedBy")]
        public long LastModifiedBy { get; set; }
    }
}
