﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    public class Feature
    {
        #region Property
        [Key, JsonProperty("Pk"), Column("Pk"), DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Pk { get; set; }

        [JsonProperty("guid"), Column("GUID")]
        public string Guid { get; set; }

        [JsonProperty("ModuleFeatureCode"), Column("ModuleFeatureCode")]
        public string ModuleFeatureCode { get; set; }

        [JsonProperty("name"), Column("Name")]
        public string Name { get; set; }

        [JsonProperty("Caption"), Column("Caption")]
        public string Caption { get; set; }

        [JsonProperty("type"), Column("Type")]
        public string Type { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [JsonProperty("moduleName"), Column("ModuleName")]
        public string ModuleName { get; set; }

        [JsonProperty("active"), Column("Active")]
        public byte Active { get; set; }

        [JsonProperty("parentFeatureKey"), Column("ParentFeatureKey")]
        public string ParentFeatureKey { get; set; }

        [JsonProperty("endpoint"), Column("Endpoint")]
        public string Endpoint { get; set; }

        [JsonProperty("beta"), Column("Beta")]
        public byte Beta { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonProperty("priority"), Column("Priority")]
        public long Priority { get; set; }

        [JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("menuGroup"), Column("MenuGroup")]
        public long MenuGroup { get; set; }

        [JsonProperty("system"), Column("System")]
        public int System { get; set; }

        [JsonProperty("listPrice"), Column("ListPrice")]
        public decimal ListPrice { get; set; }

        [JsonProperty("listPriceType"), Column("ListPriceType")]
        public int ListPriceType { get; set; }

        [JsonProperty("validFrom"), Column("ValidFrom")]
        public DateTime ValidFrom { get; set; }

        [JsonProperty("expiresOn"), Column("ExpiresOn")]
        public DateTime ExpiresOn { get; set; }

        [JsonProperty("json"), Column("Json")]
        public string Json { get; set; }

        #endregion
    }
}
