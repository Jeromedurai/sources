﻿using Newtonsoft.Json;
using Sa.Common.WebAPI.Base.Models.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XtraChef.API.Security.Query.Model
{
    public class Security : BaseModel
    {
        [Required, JsonProperty("userId")]
        public long UserId { get; set; }

        [Required, JsonProperty("userRole")]
        public string UserRole { get; set; }

        [Required, JsonProperty("moduleId")]
        public string ModuleCode { get; set; }

        #region  overridden

        [Required, JsonProperty("locationId")]
        public override string LocationId { get; set; }

        [JsonIgnore, NotMapped]
        public new long CreatedBy { get; set; }

        [JsonIgnore, NotMapped]
        public override DateTime Created { get; set; }

        [JsonIgnore, NotMapped]
        public new long LastModifiedBy { get; set; }

        [JsonIgnore, NotMapped]
        public override DateTime LastModified { get; set; }

        [JsonIgnore, NotMapped]
        public override string Guid { get; set; }

        [JsonIgnore, NotMapped]
        public override long Id { get; set; }

        [Required, JsonProperty("tenantId")]
        public override string TenantId { get; set; }

        [JsonIgnore, NotMapped]
        public override string Tags { get; set; }

        #endregion
    }

    public class AccessTenantLocations
    {
        #region Property

        [Key, JsonProperty("tenantId"), Column("TenantId")]
        public long TenantId { get; set; }

        [JsonProperty("locationId"), Column("LocationId")]
        public long LocationId { get; set; }

        #endregion
    }

    public class AccessSetting
    {
        #region Property

        [Key, JsonIgnore, Column("Id")]
        public string ID { get; set; }

        [Required, JsonProperty("accessLevel"), Column("AccessLevel")]
        public byte? AccessLevel { get; set; }

        [Required, JsonProperty("endpoint"), Column("Endpoint")]
        public string Endpoint { get; set; }

        #endregion
    }

    public class FeatureEnabled
    {
        #region Property

        [JsonProperty("endpoint")]
        public string Endpoint { get; set; }

        #endregion
    }

    public class SecurityAccess
    {
        #region Property

        [Required, JsonProperty("moduleCode")]
        public string ModuleCode { get; set; }

        [Required, JsonProperty("endpoint")]
        public string Endpoint { get; set; }

        [JsonProperty("locationIds")]
        public List<string> LocationIds { get; set; }

        [JsonProperty("versionNumber")]
        public string versionNumber { get; set; }

        [JsonProperty("db")]
        public string DB { get; set; }

        #endregion
    }

    public class SecurityAccessWithTenantId
    {
        #region Property

        [Required, JsonProperty("moduleCode")]
        public string ModuleCode { get; set; }

        [Required, JsonProperty("endpoint")]
        public string Endpoint { get; set; }

        [JsonProperty("locationIds")]
        public List<string> LocationIds { get; set; }

        [JsonProperty("tenantId")]
        public string TenantId { get; set; }

        [JsonProperty("roleId")]
        public string RoleId { get; set; }

        [JsonProperty("userId")]
        public string UserId { get; set; }

        [JsonProperty("versionNumber")]
        public string versionNumber { get; set; }

        [JsonProperty("db")]
        public string DB { get; set; }
        #endregion
    }

    public class Features
    {
        #region Property

        [Key]
        public string FeatureCode { get; set; }
        public string FeatureName { get; set; }
        public string ModuleCode { get; set; }
        public string Endpoint { get; set; }
        public string ParentFeatureKey { get; set; }

        #endregion
    }

    public class ModuleFeaturesAccess
    {
        #region Property
        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [Key, JsonProperty("featureCode"), Column("FeatureCode")]
        public string FeatureCode { get; set; }

        [JsonProperty("accessLevel"), Column("AccessLevel")]
        public byte? AccessLevel { get; set; }

        #endregion
    }

    public class MenuAccess
    {
        #region Property
        [JsonProperty("moduleId"), Column("ModuleId")]
        public long ModuleId { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [Key, JsonProperty("moduleName"), Column("ModuleName")]
        public string ModuleName { get; set; }

        [JsonProperty("caption"), Column("Caption")]
        public string MenuCaption { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonIgnore, JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("accessLevel"), NotMapped]
        public byte? AccessLevel { get; set; }

        [JsonProperty("beta"), Column("Beta")]
        public byte? Beta { get; set; }

        [JsonProperty("packageCodes"), NotMapped]
        public List<string> PackageCodes { get; set; }

        [JsonProperty("priority"), NotMapped]
        public long Priority { get; set; }

        [JsonProperty("sequenceNumber"), Column("Priority")]
        public long SequenceNumber { get; set; }

        [JsonProperty("landingPageUrl"), NotMapped]
        public string LandingPageUrl { get; set; }

        [JsonProperty("menuGroup"), Column("MenuGroup")]
        public long MenuGroup { get; set; }

        [JsonProperty("webUrl"), NotMapped]
        public string WebUrl { get; set; }

        [JsonProperty("groupId"), Column("GroupId")]
        public long? GroupId { get; set; }

#nullable enable

        [JsonProperty("groupIdDescription"), Column("GroupIdDescription")]
        public string? GroupIdDescription { get; set; }

#nullable disable

        [JsonProperty("groupIdSortOrder"), Column("GroupIdSortOrder")]
        public long? GroupIdSortOrder { get; set; }

        [JsonProperty("allowAllLocation"), Column("AllowAllLocation")]
        public bool AllowAllLocation { get; set; }
        #endregion
    }

    public class ModuleFeatures
    {
        #region Property

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [JsonProperty("moduleName"), Column("ModuleName")]
        public string ModuleName { get; set; }

        [Key, JsonProperty("featureCode"), Column("FeatureCode")]
        public string FeatureCode { get; set; }

        [JsonProperty("featureName"), Column("FeatureName")]
        public string FeatureName { get; set; }

        [JsonProperty("caption"), Column("Caption")]
        public string Caption { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonIgnore, JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("endpoint"), Column("Endpoint")]
        public string Endpoint { get; set; }

        [JsonProperty("parentFeatureKey"), Column("ParentFeatureKey")]
        public string ParentFeatureKey { get; set; }

        [JsonProperty("accessLevel"), NotMapped]
        public byte? AccessLevel { get; set; }

        [JsonProperty("packageId"), NotMapped]
        public long PackageId { get; set; }

        [JsonProperty("packageCodes"), NotMapped]
        public List<string> PackageCodes { get; set; }

        #endregion
    }

    public class ModuleFeatureList
    {
        #region Property

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [JsonProperty("moduleName"), Column("ModuleName")]
        public string ModuleName { get; set; }

        public List<FeaturesDetail> features { get; set; }

        #endregion
    }

    public class FeaturesDetail
    {
        #region Property

        [Key, JsonProperty("featureCode"), Column("FeatureCode")]
        public string FeatureCode { get; set; }

        [JsonProperty("featureName"), Column("FeatureName")]
        public string FeatureName { get; set; }

        [JsonProperty("caption"), Column("Caption")]
        public string Caption { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonIgnore, JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("endpoint"), Column("Endpoint")]
        public string Endpoint { get; set; }

        [JsonProperty("parentKey"), Column("ParentKey")]
        public string ParentFeatureKey { get; set; }

        [JsonProperty("accessLevel"), NotMapped]
        public byte? AccessLevel { get; set; }

        [JsonProperty("packageCodes"), NotMapped]
        public List<string> PackageCodes { get; set; }

        [JsonProperty("allowAllLocation"), NotMapped]
        public bool AllowAllLocation { get; set; }

        #endregion
    }

    public class TenantPackage
    {
        #region Property
        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [Key, JsonProperty("featureCode"), Column("FeatureCode")]
        public string FeatureCode { get; set; }

        [JsonProperty("packageCode"), Column("PackageCode")]
        public string PackageCode { get; set; }

        [JsonProperty("priority"), Column("Priority")]
        public long Priority { get; set; }

        [JsonProperty("landingPageUrl"), Column("LandingPageUrl")]
        public string LandingPageUrl { get; set; }

        #endregion
    }

    public class Access
    {
        #region Property

        [JsonProperty("accessLevel"), Column("AccessLevel")]
        public Byte AccessLevel { get; set; }

        #endregion
    }

    public class ModuleAccess
    {
        #region Property
        public bool access { get; set; }
        public string message { get; set; }
        #endregion
    }

    public class NewModuleFeatureAccess
    {
        #region Property
        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [JsonProperty("modulefeatureCode"), Column("ModulefeatureCode")]
        public string ModulefeatureCode { get; set; }

        [Key, JsonProperty("name"), Column("Name")]
        public string Name { get; set; }

        [JsonProperty("caption"), Column("Caption")]
        public string Caption { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

#nullable enable
        [JsonIgnore, JsonProperty("endpoint"), Column("Endpoint")]
        public string? Endpoint { get; set; }

#nullable disable
#nullable enable
        [JsonProperty("parentFeatureKey"), Column("ParentFeatureKey")]
        public string? ParentFeatureKey { get; set; }

#nullable disable
        [JsonProperty("accessLevel"), Column("AccessLevel")]
        public byte? AccessLevel { get; set; }

#nullable enable
        [JsonProperty("packageCode"), Column("PackageCode")]
        public string? PackageCode { get; set; }

#nullable disable
        [JsonProperty("allowAllLocation"), Column("AllowAllLocation")]
        public bool AllowAllLocation { get; set; }
        #endregion
    }

    public class NewMenuAccess
    {
        #region Property
        [JsonProperty("moduleId"), Column("ModuleId")]
        public long ModuleId { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [Key, JsonProperty("moduleName"), Column("ModuleName")]
        public string ModuleName { get; set; }

        [JsonProperty("caption"), Column("Caption")]
        public string MenuCaption { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonIgnore, JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("accessLevel"), Column("AccessLevel")]
        public byte? AccessLevel { get; set; }

        [JsonProperty("beta"), Column("Beta")]
        public byte? Beta { get; set; }

#nullable enable
        [JsonProperty("packageCode"), Column("PackageCode")]
        public string? PackageCode { get; set; }

#nullable disable
        [JsonProperty("priority"), Column("Priority")]
        public long Priority { get; set; }

        [JsonProperty("sequenceNumber"), Column("SequenceNumber")]
        public long SequenceNumber { get; set; }

#nullable enable
        [JsonProperty("landingPageUrl"), Column("LandingPageUrl")]
        public string? LandingPageUrl { get; set; }

#nullable disable
        [JsonProperty("menuGroup"), Column("MenuGroup")]
        public long MenuGroup { get; set; }

        [JsonProperty("webUrl"), NotMapped]
        public string WebUrl { get; set; }

        [JsonProperty("groupId"), Column("GroupId")]
        public long? GroupId { get; set; }

#nullable enable
        [JsonProperty("groupIdDescription"), Column("GroupIdDescription")]
        public string? GroupIdDescription { get; set; }

#nullable disable
        [JsonProperty("groupIdSortOrder"), Column("GroupIdSortOrder")]
        public long? GroupIdSortOrder { get; set; }

        [JsonProperty("allowAllLocation"), Column("AllowAllLocation")]
        public bool AllowAllLocation { get; set; }
        #endregion
    }

    public class MobileMenuAccessList
    {
        #region Property
        [JsonProperty("moduleId"), Column("ModuleId")]
        public long ModuleId { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [Key, JsonProperty("moduleName"), Column("ModuleName")]
        public string ModuleName { get; set; }

        [JsonProperty("caption"), Column("Caption")]
        public string MenuCaption { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonIgnore, JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("accessLevel"), NotMapped]
        public byte? AccessLevel { get; set; }

        [JsonProperty("beta"), Column("Beta")]
        public byte? Beta { get; set; }

        [JsonProperty("packageCodes"), NotMapped]
        public List<string> PackageCodes { get; set; }

        [JsonProperty("priority"), NotMapped]
        public long Priority { get; set; }

        [JsonProperty("sequenceNumber"), Column("Priority")]
        public long SequenceNumber { get; set; }

        [JsonProperty("landingPageUrl"), NotMapped]
        public string LandingPageUrl { get; set; }

        [JsonProperty("menuGroup"), Column("MenuGroup")]
        public long MenuGroup { get; set; }

        [JsonProperty("webUrl"), NotMapped]
        public string WebUrl { get; set; }

        [JsonProperty("groupId"), Column("GroupId")]
        public long? GroupId { get; set; }

#nullable enable
        [JsonProperty("groupIdDescription"), Column("GroupIdDescription")]
        public string? GroupIdDescription { get; set; }

#nullable disable
        [JsonProperty("groupIdSortOrder"), Column("GroupIdSortOrder")]
        public long? GroupIdSortOrder { get; set; }

        [JsonProperty("VersionNumber"), Column("VersionNumber")]
        public string VersionNumber { get; set; }

        [JsonProperty("allowAllLocation"), Column("AllowAllLocation")]
        public bool AllowAllLocation { get; set; }
        #endregion
    }

    public class MobileMenuAccess
    {
        #region Property
        [JsonProperty("moduleId"), Column("ModuleId")]
        public long ModuleId { get; set; }

        [JsonProperty("moduleCode"), Column("ModuleCode")]
        public string ModuleCode { get; set; }

        [Key, JsonProperty("moduleName"), Column("ModuleName")]
        public string ModuleName { get; set; }

        [JsonProperty("caption"), Column("Caption")]
        public string MenuCaption { get; set; }

        [JsonProperty("webLink"), Column("WebLink")]
        public string WebLink { get; set; }

        [JsonIgnore, JsonProperty("lockedWebLink"), Column("LockedWebLink")]
        public string LockedWebLink { get; set; }

        [JsonProperty("accessLevel"), Column("AccessLevel")]
        public byte? AccessLevel { get; set; }

        [JsonProperty("beta"), Column("Beta")]
        public byte? Beta { get; set; }

#nullable enable
        [JsonProperty("packageCode"), Column("PackageCode")]
        public string? PackageCode { get; set; }

#nullable disable
        [JsonProperty("priority"), Column("Priority")]
        public long Priority { get; set; }

        [JsonProperty("sequenceNumber"), Column("SequenceNumber")]
        public long SequenceNumber { get; set; }

#nullable enable
        [JsonProperty("landingPageUrl"), Column("LandingPageUrl")]
        public string? LandingPageUrl { get; set; }

#nullable disable
        [JsonProperty("menuGroup"), Column("MenuGroup")]
        public long MenuGroup { get; set; }

        [JsonProperty("webUrl"), NotMapped]
        public string WebUrl { get; set; }

        [JsonProperty("groupId"), Column("GroupId")]
        public long? GroupId { get; set; }

#nullable enable
        [JsonProperty("groupIdDescription"), Column("GroupIdDescription")]
        public string? GroupIdDescription { get; set; }

#nullable disable
        [JsonProperty("groupIdSortOrder"), Column("GroupIdSortOrder")]
        public long? GroupIdSortOrder { get; set; }

        [JsonProperty("VersionNumber"), Column("VersionNumber")]
        public string VersionNumber { get; set; }

        [JsonProperty("allowAllLocation"), Column("AllowAllLocation")]
        public bool AllowAllLocation { get; set; }
        #endregion
    }
}
