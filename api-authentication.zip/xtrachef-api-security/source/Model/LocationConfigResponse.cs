﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace XtraChef.API.Security.Query.Model
{
    public class LocationConfigResponse
    {
        [JsonProperty("allLocation")]
        public bool AllLocation { get; set; }

        [JsonProperty("includeIds")]
        public List<long> IncludeIds { get; set; }

        [JsonProperty("excludeIds")]
        public List<long> ExcludeIds { get; set; }
    }
}
