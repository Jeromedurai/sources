﻿using Sa.Common.WebAPI.Base.Factory;

namespace XtraChef.API.Security.Query.Factory
{
    public class Package : XcBaseFactory<Model.Package> { }
}
