﻿namespace XtraChef.API.Security.Query.Factory
{
    public class Feature { }
}
