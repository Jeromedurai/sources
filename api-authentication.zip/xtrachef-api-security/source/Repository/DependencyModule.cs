﻿using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Sa.Common.WebAPI.Base.Repository;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base.Extensions;

namespace XtraChef.API.Security.Query.Repository
{
    public class DependencyModule
        : BaseQueryRepository<Model.DependencyModule, Context.DependencyModule>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public DependencyModule(Context.DependencyModule dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.DependencyModule> GetById(
            string tenantId,
            string locationId,
            string id
        )
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Module Entity By moduleId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">ModuleId.</param>
        public async Task<Model.DependencyModule> GetDependencyModuleById(string moduleCode)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling Module GetDependencyModuleById");

                //Getting module item aggeregate
                Model.DependencyModule moduleItem = await this.DbContext.dependencyModule
                    .Where(x => x.ModuleCode == moduleCode)
                    .FirstOrDefaultWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called Module GetDependencyModuleById");

                //return
                return moduleItem;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Get Dependency Module By Id Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
