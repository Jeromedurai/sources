﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sa.Common.WebAPI.Base.Repository;
using Sa.Common.SeriLog;

namespace XtraChef.API.Security.Query.Repository
{
    public class PackageDetail : BaseQueryRepository<Model.PackageDetail, Context.PackageDetail>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public PackageDetail(Context.PackageDetail dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.PackageDetail> GetById(
            string tenantId,
            string locationId,
            string id
        )
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Package Entity By packageDetailId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="packageDetailId">PackageDetailId.</param>
        public async Task<Model.PackageDetail> GetPackageDetail(
            string packageCode,
            string moduleFeatureCode,
            string spPD
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling Package GetPackageDetail");

                #region Variables
                // PackageCode
                SqlParameter PackageCode = new SqlParameter
                {
                    ParameterName = "@PACKAGECODE",
                    SqlDbType = SqlDbType.VarChar,
                    Value = packageCode
                };
                // UserId
                SqlParameter ModuleFeatureCode = new SqlParameter
                {
                    ParameterName = "@MODULEFEATURECODE",
                    SqlDbType = SqlDbType.VarChar,
                    Value = moduleFeatureCode
                };

                #endregion

                Model.PackageDetail packageDetail = this.DbContext.packageDetail
                    .FromSqlRaw(
                        $"exec {spPD} @PACKAGECODE, @MODULEFEATURECODE",
                        PackageCode,
                        ModuleFeatureCode
                    )
                    .AsNoTracking()
                    .AsEnumerable()
                    .FirstOrDefault();
                //Logger
                await this.Logger.LogInfo($"Called Package Detail GetPackageDetail");

                //return
                return packageDetail;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Package GetPackageDetail Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
