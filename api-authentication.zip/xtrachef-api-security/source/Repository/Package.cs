﻿using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Sa.Common.WebAPI.Base.Repository;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base.Extensions;

namespace XtraChef.API.Security.Query.Repository
{
    public class Package : BaseQueryRepository<Model.Package, Context.Package>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public Package(Context.Package dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.Package> GetById(string tenantId, string locationId, string id)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Package Entity By packageId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="packageCode">PackageCode.</param>
        public async Task<Model.Package> GetPackage(string packageCode)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling Package GetPackage");

                //Getting Package item aggeregate
                Model.Package package = await this.DbContext.package
                    .Where(x => x.Code == packageCode)
                    .FirstOrDefaultWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called Package GetPackage");

                //return
                return package;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Package GetPackage Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
