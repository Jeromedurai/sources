using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sa.Common.ADO.DataAccess;
using Sa.Common.WebAPI.Base.Repository;
using Sa.Common.SeriLog;
using Sa.Common.ADO.CicdDataAccess;

namespace XtraChef.API.Security.Query.Repository
{
    public class Security : BaseQueryRepository<Model.Security, Context.Security>
    {
        #region Variables
        private readonly CicdDataAccess _dataAccess;
        private readonly PostgressDataAccess _pgDataAccess;
        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="XtraChef.API.Security.Query.Repository.Security"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public Security(
            Context.Security dbContext,
            LogPublisher logPublisher,
            CicdDataAccess dataAccess,
            PostgressDataAccess pgDataAccess
        )
            : base(dbContext, logPublisher)
        {
            _dataAccess = dataAccess;
            _pgDataAccess = pgDataAccess;
        }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.Security> GetById(string tenantId, string locationId, string id)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// GGet the specified Module Enabled Entity.
        /// </summary>
        /// <param name="">UserId</param>
        /// <param name="">UserRole</param>
        /// <param name="">TenantId</param>
        /// <param name="">LocationId</param>
        /// <param name="">ModuleId</param>
        /// <param name="">spName</param>
        public async Task<bool> GetModuleEnabled(
            long userId,
            long tenantId,
            long userRoleId,
            Model.SecurityAccess securityAccess,
            string spMFA,
            string spATL
        )
        {
            try
            {
                #region Instances
                List<Model.AccessTenantLocations> accessTenantLocations = null;
                List<Model.ModuleFeaturesAccess> moduleFeatureAccessList = null;
                #endregion

                #region Variables
                // UserId
                SqlParameter UserId = new SqlParameter
                {
                    ParameterName = "@USERID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = userId
                };
                // UserRole
                SqlParameter UserRole = new SqlParameter
                {
                    ParameterName = "@USERROLE",
                    SqlDbType = SqlDbType.BigInt,
                    Value = userRoleId
                };
                // TenantId
                SqlParameter TenantId = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = tenantId
                };
                // ModuleCode
                SqlParameter ModuleCode = new SqlParameter
                {
                    ParameterName = "@MODULECODE",
                    SqlDbType = SqlDbType.VarChar,
                    Value = securityAccess.ModuleCode == "" ? null : securityAccess.ModuleCode
                };
                List<string> locationIds = null;
                locationIds = securityAccess.LocationIds;
                #endregion

                #region Get Tenant Valied locationIds
                // Locations
                DataTable locationsCollection = new DataTable();
                locationsCollection.Columns.Add("VALUE", typeof(Int64));

                if (locationIds != null && locationIds.Count > 0)
                {
                    DataRow dr;
                    locationIds.ForEach(x =>
                    {
                        dr = locationsCollection.NewRow();
                        dr["VALUE"] = Convert.ToInt64(x);
                        locationsCollection.Rows.Add(dr);
                    });
                }
                SqlParameter Locations = new SqlParameter
                {
                    ParameterName = "@LOCATIONIDS",
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "BIGINT_ARRAY",
                    Value = locationsCollection
                };

                if (locationIds == null)
                {
                    //get the Tenant valied Locations.
                    accessTenantLocations = this.DbContext.accessTenantLocations
                        .FromSqlRaw($"exec {spATL} @TENANTID", TenantId)
                        .AsNoTracking()
                        .ToList();
                }
                else
                {
                    //get the Tenant valied Locations.
                    accessTenantLocations = this.DbContext.accessTenantLocations
                        .FromSqlRaw($"exec {spATL} @TENANTID, @LOCATIONIDS", TenantId, Locations)
                        .AsNoTracking()
                        .ToList();
                }

                List<string> locations = accessTenantLocations
                    .Select(x => x.LocationId.ToString())
                    .Distinct()
                    .ToList();

                locationIds = new List<string>();
                if (securityAccess.LocationIds.Count > 0)
                {
                    //get the all tenent valied location.
                    locationIds = securityAccess.LocationIds
                        .Where(x => locations.Contains(x))
                        .ToList();
                }
                else
                {
                    //get the all tenent valied location when locationId pass empty.
                    locationIds = locations;
                }

                #endregion

                #region LocationIds
                // LocationIds
                DataTable locationIdCollection = new DataTable();
                locationIdCollection.Columns.Add("VALUE", typeof(Int64));

                if (locationIds != null && locationIds.Count > 0)
                {
                    DataRow dr;
                    locationIds.ForEach(x =>
                    {
                        dr = locationIdCollection.NewRow();
                        dr["VALUE"] = Convert.ToInt64(x);
                        locationIdCollection.Rows.Add(dr);
                    });
                }
                SqlParameter LocationIds = new SqlParameter
                {
                    ParameterName = "@LOCATIONIDS",
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "BIGINT_ARRAY",
                    Value = locationIdCollection
                };

                #endregion

                if (!string.IsNullOrEmpty(securityAccess.ModuleCode))
                {
                    //get the ModuleFeatureAccessList
                    moduleFeatureAccessList = this.DbContext.moduleFeaturesAccess
                        .FromSqlRaw(
                            $"exec {spMFA} @USERID, @USERROLE, @TENANTID, @LOCATIONIDS, @MODULECODE",
                            UserId,
                            UserRole,
                            TenantId,
                            LocationIds,
                            ModuleCode
                        )
                        .AsNoTracking()
                        .ToList();
                    //Get the module enabled detail and return boolean value
                    if ((moduleFeatureAccessList != null) && (moduleFeatureAccessList.Count > 0))
                    {
                        //return false if module enabled
                        return true;
                    }
                }

                //return false if module not enabled
                return false;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetModuleEnabled Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Endpoint Enabledd Entity By Endpoint.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="endpoint">Endpoint.</param>
        /// /// <param name="spName">spName.</param>
        public Model.Features GetEndpointEnabled(string endpoint, string spEE)
        {
            try
            {
                #region Variables
                // Endpoint
                SqlParameter Endpoint = new SqlParameter
                {
                    ParameterName = "@ENDPOINT",
                    SqlDbType = SqlDbType.VarChar,
                    Value = endpoint
                };
                #endregion

                Model.Features featureItem = this.DbContext.Features
                    .FromSqlRaw($"exec {spEE} @ENDPOINT", Endpoint)
                    .AsNoTracking()
                    .AsEnumerable()
                    .FirstOrDefault();
                //return featureItem
                return featureItem;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"GetEndpointEnabled Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified User Module Security Feature Entity By userFeaturesAccess .
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="">UserId</param>
        /// <param name="">UserRole</param>
        /// <param name="">TenantId</param>
        /// <param name="">LocationId</param>
        /// <param name="">securityAccess</param>
        /// <param name="">spName</param>
        /// <param name="">spNameAccess</param>
        public async Task<List<Model.ModuleFeatures>> GetModuleFeaturesAccess(
            long userId,
            long tenantId,
            long locationId,
            long userRoleId,
            Model.SecurityAccess securityAccess,
            string spMF,
            string spMFA,
            string spTAP,
            string spATL,
            List<long> restrictAmfForLockedWeblinkRoleIds
        )
        {
            try
            {
                #region Instances
                List<Model.ModuleFeaturesAccess> moduleFeatureAccessList =
                    new List<Model.ModuleFeaturesAccess>();
                List<Model.ModuleFeatures> moduleFeatureList = new List<Model.ModuleFeatures>();
                List<Model.TenantPackage> tenantPackage = new List<Model.TenantPackage>();
                List<Model.AccessTenantLocations> accessTenantLocations = null;
                #endregion

                #region Variables
                byte disabled = 0;
                // UserId
                SqlParameter UserId = new SqlParameter
                {
                    ParameterName = "@USERID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = userId
                };
                // UserRole
                SqlParameter UserRole = new SqlParameter
                {
                    ParameterName = "@USERROLE",
                    SqlDbType = SqlDbType.BigInt,
                    Value = userRoleId
                };
                // TenantId
                SqlParameter TenantId = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = tenantId
                };
                // ModuleCode
                SqlParameter ModuleCode = new SqlParameter
                {
                    ParameterName = "@MODULECODE",
                    SqlDbType = SqlDbType.VarChar,
                    Value = securityAccess.ModuleCode == "" ? null : securityAccess.ModuleCode
                };
                List<string> locationIds = null;
                locationIds = securityAccess.LocationIds;
                #endregion

                #region Get Tenant Valied locationIds
                // Locations
                DataTable locationsCollection = new DataTable();
                locationsCollection.Columns.Add("VALUE", typeof(Int64));

                if (locationIds != null && locationIds.Count > 0)
                {
                    DataRow dr;
                    locationIds.ForEach(x =>
                    {
                        dr = locationsCollection.NewRow();
                        dr["VALUE"] = Convert.ToInt64(x);
                        locationsCollection.Rows.Add(dr);
                    });
                }
                SqlParameter Locations = new SqlParameter
                {
                    ParameterName = "@LOCATIONIDS",
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "BIGINT_ARRAY",
                    Value = locationsCollection
                };

                if (locationIds == null)
                {
                    //get the Tenant valied Locations.
                    accessTenantLocations = this.DbContext.accessTenantLocations
                        .FromSqlRaw($"exec {spATL} @TENANTID", TenantId)
                        .AsNoTracking()
                        .ToList();
                }
                else
                {
                    //get the Tenant valied Locations.
                    accessTenantLocations = this.DbContext.accessTenantLocations
                        .FromSqlRaw($"exec {spATL} @TENANTID, @LOCATIONIDS", TenantId, Locations)
                        .AsNoTracking()
                        .ToList();
                }

                List<string> locations = accessTenantLocations
                    .Select(x => x.LocationId.ToString())
                    .Distinct()
                    .ToList();

                locationIds = new List<string>();
                if (securityAccess.LocationIds.Count > 0)
                {
                    //get the all tenent valied location.
                    locationIds = securityAccess.LocationIds
                        .Where(x => locations.Contains(x))
                        .ToList();
                }
                else
                {
                    //get the all tenent valied location when locationId pass empty.
                    locationIds = locations;
                }

                #endregion

                #region LocationIds
                // LocationIds
                DataTable locationIdCollection = new DataTable();
                locationIdCollection.Columns.Add("VALUE", typeof(Int64));

                if (locationIds != null && locationIds.Count > 0)
                {
                    DataRow dr;
                    locationIds.ForEach(x =>
                    {
                        dr = locationIdCollection.NewRow();
                        dr["VALUE"] = Convert.ToInt64(x);
                        locationIdCollection.Rows.Add(dr);
                    });
                }
                SqlParameter LocationIds = new SqlParameter
                {
                    ParameterName = "@LOCATIONIDS",
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "BIGINT_ARRAY",
                    Value = locationIdCollection
                };

                #endregion

                if (string.IsNullOrEmpty(securityAccess.ModuleCode))
                {
                    //get the ModuleFeatureAccessList
                    moduleFeatureAccessList = this.DbContext.moduleFeaturesAccess
                        .FromSqlRaw(
                            $"exec {spMFA} @USERID, @USERROLE, @TENANTID, @LOCATIONIDS",
                            UserId,
                            UserRole,
                            TenantId,
                            LocationIds
                        )
                        .AsNoTracking()
                        .ToList();
                    //get the ModuleFeatureList
                    moduleFeatureList = this.DbContext.moduleFeatures
                        .FromSqlRaw($"exec {spMF}")
                        .AsNoTracking()
                        .ToList();
                }
                else
                {
                    //get the ModuleFeatureAccessList
                    moduleFeatureAccessList = this.DbContext.moduleFeaturesAccess
                        .FromSqlRaw(
                            $"exec {spMFA} @USERID, @USERROLE, @TENANTID, @LOCATIONIDS, @MODULECODE",
                            UserId,
                            UserRole,
                            TenantId,
                            LocationIds,
                            ModuleCode
                        )
                        .AsNoTracking()
                        .ToList();
                    //get the ModuleFeatureList
                    moduleFeatureList = this.DbContext.moduleFeatures
                        .FromSqlRaw($"exec {spMF} @MODULECODE", ModuleCode)
                        .AsNoTracking()
                        .ToList();
                }

                //Get the Module Feature Access List
                moduleFeatureList.ForEach(featureItem =>
                {
                    if (
                        moduleFeatureAccessList.Any(
                            item =>
                                item.FeatureCode == featureItem.FeatureCode
                                && item.ModuleCode == featureItem.ModuleCode
                        )
                    )
                    {
                        moduleFeatureAccessList
                            .Where(
                                data =>
                                    data.FeatureCode == featureItem.FeatureCode
                                    && data.ModuleCode == featureItem.ModuleCode
                            )
                            .ToList()
                            .ForEach(temp =>
                            {
                                featureItem.AccessLevel = temp.AccessLevel;
                            });
                    }
                    else
                    {
                        if (
                            string.IsNullOrEmpty(featureItem.ParentFeatureKey)
                            && moduleFeatureAccessList.Any(
                                item =>
                                    item.FeatureCode == featureItem.ModuleCode
                                    && item.ModuleCode == featureItem.ModuleCode
                            )
                        ) //ParentFeatureKey is NUll. It mean for this feature not having sub features.
                        {
                            // FeatureCode is equel to ModuleCode means that is module level access provide by xtraCHEF.
                            moduleFeatureAccessList
                                .Where(
                                    item =>
                                        item.FeatureCode == featureItem.ModuleCode
                                        && item.ModuleCode == featureItem.ModuleCode
                                )
                                .ToList()
                                .ForEach(temp =>
                                {
                                    featureItem.AccessLevel = temp.AccessLevel;
                                });
                        }
                        else
                        {
                            string parentKey = featureItem.ParentFeatureKey;
                            bool isSubFeatureCategorised = false;
                            moduleFeatureList
                                .Where(data => data.ParentFeatureKey == parentKey)
                                .ToList()
                                .ForEach(subFeature =>
                                {
                                    if (
                                        moduleFeatureAccessList.Any(
                                            item => item.FeatureCode == subFeature.FeatureCode
                                        )
                                    )
                                    {
                                        isSubFeatureCategorised = true;
                                    }
                                });
                            if (isSubFeatureCategorised)
                            {
                                featureItem.AccessLevel = disabled;
                            }
                            else
                            {
                                for (int i = 0; i < moduleFeatureList.Count; i++)
                                {
                                    bool isAccessLevelAssigned = false;
                                    foreach (
                                        Model.ModuleFeatures data in moduleFeatureList.Where(
                                            temp => parentKey == temp.FeatureCode
                                        )
                                    )
                                    {
                                        if (data.AccessLevel == disabled)
                                        {
                                            moduleFeatureList
                                                .Where(
                                                    item =>
                                                        item.FeatureCode == data.ParentFeatureKey
                                                )
                                                .ToList()
                                                .ForEach(temp =>
                                                {
                                                    parentKey = temp.ParentFeatureKey;
                                                });
                                        }
                                        else
                                        {
                                            featureItem.AccessLevel = data.AccessLevel;
                                            isAccessLevelAssigned = true;
                                            break;
                                        }
                                    }
                                    if (isAccessLevelAssigned)
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                });

                if (securityAccess.ModuleCode == null || securityAccess.ModuleCode == "")
                {
                    //get the Tenant Package
                    tenantPackage = this.DbContext.tenantPackage
                        .FromSqlRaw($"exec {spTAP} @TENANTID, @LOCATIONIDS", TenantId, LocationIds)
                        .AsNoTracking()
                        .ToList();
                }
                else
                {
                    //get the Tenant Package
                    tenantPackage = this.DbContext.tenantPackage
                        .FromSqlRaw(
                            $"exec {spTAP} @TENANTID, @LOCATIONIDS, @MODULECODE",
                            TenantId,
                            LocationIds,
                            ModuleCode
                        )
                        .AsNoTracking()
                        .ToList();
                }

                //Compaire with package access list.
                moduleFeatureList.ForEach(featureItem =>
                {
                    if (
                        tenantPackage.Any(
                            item =>
                                item.FeatureCode == featureItem.FeatureCode
                                || item.FeatureCode == featureItem.ModuleCode
                        )
                    )
                    {
                        List<string> packageCodes = new List<string>();
                        tenantPackage
                            .Where(
                                data =>
                                    data.FeatureCode == featureItem.FeatureCode
                                    || data.FeatureCode == featureItem.ModuleCode
                            )
                            .ToList()
                            .ForEach(temp =>
                            {
                                packageCodes.Add(temp.PackageCode);
                            });
                        featureItem.PackageCodes = packageCodes;
                    }
                    else
                    {
                        featureItem.PackageId = 0;
                        featureItem.PackageCodes = null;
                        featureItem.AccessLevel = 0; // If feature is not in package then access should we desabled.
                        featureItem.WebLink = restrictAmfForLockedWeblinkRoleIds.Contains(
                            userRoleId
                        )
                            ? ""
                            : featureItem.LockedWebLink; //if tenant didn't bought package then give WebLink = LockedWebLink.
                    }
                });

                //if parent feature is disabled then child feature should be disabled.
                moduleFeatureList.ForEach(featureItem =>
                {
                    if (!string.IsNullOrEmpty(featureItem.ParentFeatureKey))
                    {
                        moduleFeatureList
                            .Where(
                                data =>
                                    data.ParentFeatureKey == featureItem.FeatureCode
                                    && (
                                        featureItem.AccessLevel == 0
                                        || featureItem.AccessLevel == null
                                    )
                            )
                            .ToList()
                            .ForEach(featureData =>
                            {
                                featureData.AccessLevel = 0;
                                featureData.WebLink = "";
                            });
                    }
                });

                // return module feature list with access.
                return moduleFeatureList;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogInfo($"GetModuleFeaturesAccess Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Menu Access Entity.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">moduleId.</param>
        public async Task<List<Model.MenuAccess>> GetMenusAccess(string spMA)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetMenusAccess");

                #region Instances
                List<Model.MenuAccess> menusAccess = null;
                #endregion

                menusAccess = this.DbContext.menuAccess
                    .FromSqlRaw($"exec {spMA}")
                    .AsNoTracking()
                    .ToList();

                //Logger
                await this.Logger.LogInfo($"Called GetMenusAccess");

                //return menu with access level
                return menusAccess;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetMenusAccess Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Module Access Entity.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">moduleId.</param>
        public async Task<List<Model.TenantPackage>> GetTenantPackage(
            Model.SecurityAccess securityAccess,
            long userId,
            long tenantId,
            long locationId,
            long userRoleId,
            string spTAP,
            string spATL
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetModuleAccess");

                #region Instances
                List<Model.TenantPackage> tenantPackage = null;
                List<Model.AccessTenantLocations> accessTenantLocations = null;
                #endregion

                #region Variables
                // UserId
                SqlParameter UserId = new SqlParameter
                {
                    ParameterName = "@USERID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = userId
                };
                // UserRole
                SqlParameter UserRole = new SqlParameter
                {
                    ParameterName = "@USERROLE",
                    SqlDbType = SqlDbType.BigInt,
                    Value = userRoleId
                };
                // TenantId
                SqlParameter TenantId = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = tenantId
                };
                // ModuleCode
                SqlParameter ModuleCode = new SqlParameter
                {
                    ParameterName = "@MODULECODE",
                    SqlDbType = SqlDbType.VarChar,
                    Value = securityAccess.ModuleCode == "" ? null : securityAccess.ModuleCode
                };
                List<string> locationIds = securityAccess.LocationIds;
                #endregion
                // Locations
                DataTable locationsCollection = new DataTable();
                locationsCollection.Columns.Add("VALUE", typeof(Int64));

                if (locationIds != null && locationIds.Count > 0)
                {
                    DataRow dr;
                    locationIds.ForEach(x =>
                    {
                        dr = locationsCollection.NewRow();
                        dr["VALUE"] = Convert.ToInt64(x);
                        locationsCollection.Rows.Add(dr);
                    });
                }
                SqlParameter Locations = new SqlParameter
                {
                    ParameterName = "@LOCATIONIDS",
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "BIGINT_ARRAY",
                    Value = locationsCollection
                };

                if (locationIds == null || locationIds.Count > 0)
                {
                    //get the ModuleFeatureAccessList
                    accessTenantLocations = this.DbContext.accessTenantLocations
                        .FromSqlRaw($"exec {spATL} @TENANTID", TenantId)
                        .AsNoTracking()
                        .ToList();
                }
                else
                {
                    //get the ModuleFeatureAccessList
                    accessTenantLocations = this.DbContext.accessTenantLocations
                        .FromSqlRaw($"exec {spATL} @TENANTID, @LOCATIONIDS", TenantId, Locations)
                        .AsNoTracking()
                        .ToList();
                }

                List<string> locations = accessTenantLocations
                    .Select(x => x.LocationId.ToString())
                    .Distinct()
                    .ToList();

                locationIds = new List<string>();
                if (securityAccess.LocationIds.Count > 0)
                {
                    //get the all tenent valied location.
                    locationIds = securityAccess.LocationIds
                        .Where(x => locations.Contains(x))
                        .ToList();
                }
                else
                {
                    //get the all tenent valied location when locationId pass empty.
                    locationIds = locations;
                }

                #region LocationIds
                // LocationIds
                DataTable locationIdCollection = new DataTable();
                locationIdCollection.Columns.Add("VALUE", typeof(Int64));

                if (locationIds != null && locationIds.Count > 0)
                {
                    DataRow dr;
                    locationIds.ForEach(x =>
                    {
                        dr = locationIdCollection.NewRow();
                        dr["VALUE"] = Convert.ToInt64(x);
                        locationIdCollection.Rows.Add(dr);
                    });
                }
                SqlParameter LocationIds = new SqlParameter
                {
                    ParameterName = "@LOCATIONIDS",
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "BIGINT_ARRAY",
                    Value = locationIdCollection
                };

                #endregion

                if (securityAccess.ModuleCode == null || securityAccess.ModuleCode == "")
                {
                    //get the TenantAccessPackage
                    tenantPackage = this.DbContext.tenantPackage
                        .FromSqlRaw($"exec {spTAP} @TENANTID, @LOCATIONIDS", TenantId, LocationIds)
                        .AsNoTracking()
                        .ToList();
                }
                else
                {
                    //get the TenantPackage
                    tenantPackage = this.DbContext.tenantPackage
                        .FromSqlRaw(
                            $"exec {spTAP} @TENANTID, @LOCATIONIDS, @MODULECODE",
                            TenantId,
                            LocationIds,
                            ModuleCode
                        )
                        .AsNoTracking()
                        .ToList();
                }

                //Logger
                await this.Logger.LogInfo($"Called GetModuleAccess");

                //return tenant package
                return tenantPackage;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetModuleAccess Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.NewModuleFeatureAccess>> GetModuleFeaturesAccessNewMSSQL(
            Model.SecurityAccessWithTenantId securityAccess,
            long locationId,
            string spMFAN
        )
        {
            #region Instances
            List<Model.NewModuleFeatureAccess> moduleFeatureAccess =
                new List<Model.NewModuleFeatureAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                IDataReader dataReader = _dataAccess.ExecuteReader(
                    spMFAN,
                    securityAccess.UserId,
                    securityAccess.RoleId,
                    securityAccess.TenantId,
                    locationId,
                    securityAccess.ModuleCode
                );
                while (dataReader.Read())
                {
                    Model.NewModuleFeatureAccess item = new Model.NewModuleFeatureAccess()
                    {
                        ModuleCode =
                            dataReader["ModuleCode"] == null
                                ? ""
                                : dataReader["ModuleCode"].ToString(),
                        ModulefeatureCode =
                            dataReader["ModulefeatureCode"] == null
                                ? ""
                                : dataReader["ModulefeatureCode"].ToString(),
                        Name = dataReader["Name"] == null ? "" : dataReader["Name"].ToString(),
                        Caption =
                            dataReader["Caption"] == null ? "" : dataReader["Caption"].ToString(),
                        WebLink =
                            dataReader["WebLink"] == null ? "" : dataReader["WebLink"].ToString(),
                        Endpoint =
                            dataReader["Endpoint"] == null ? "" : dataReader["Endpoint"].ToString(),
                        AccessLevel = Convert.ToByte(dataReader["AccessLevel"]),
                        ParentFeatureKey =
                            dataReader["ParentFeatureKey"] == null
                                ? null
                                : dataReader["ParentFeatureKey"].ToString(),
                        PackageCode =
                            dataReader["PackageCode"] == null
                                ? ""
                                : dataReader["PackageCode"].ToString().Replace(" ", ""),
                        AllowAllLocation = dataReader["AllowAllLocation"] == null ? false : Convert.ToBoolean(dataReader["AllowAllLocation"])
                    };
                    moduleFeatureAccess.Add(item);
                }
                dataReader.Close();
                return moduleFeatureAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError(
                    $"Module GetModuleFeaturesAccessNew Error : {ex.Message}"
                );
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.NewModuleFeatureAccess>> GetModuleFeaturesAccessNewPostgresql(
            Model.SecurityAccessWithTenantId securityAccess,
            long locationId
        )
        {
            #region Instances
            List<Model.NewModuleFeatureAccess> moduleFeatureAccess =
                new List<Model.NewModuleFeatureAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                DataTable dt = _pgDataAccess.ExecuteDataTableSQL(
                    "GetModuleFeaturesAccess",
                    Convert.ToInt32(securityAccess.UserId),
                    Convert.ToInt32(securityAccess.RoleId),
                    Convert.ToInt32(securityAccess.TenantId),
                    Convert.ToInt32(locationId),
                    securityAccess.ModuleCode);
                foreach(DataRow row in dt.Rows)
                {
                    Model.NewModuleFeatureAccess item = new Model.NewModuleFeatureAccess()
                    {
                        ModuleCode =
                            row["module_code"] == null
                                ? ""
                                : row["module_code"].ToString(),
                        ModulefeatureCode =
                            row["module_feature_code"] == null
                                ? ""
                                : row["module_feature_code"].ToString(),
                        Name = row["name"] == null ? "" : row["name"].ToString(),
                        Caption =
                            row["caption"] == null ? "" : row["caption"].ToString(),
                        WebLink =
                            row["weblink"] == null ? "" : row["weblink"].ToString(),
                        Endpoint =
                            row["endpoint"] == null ? "" : row["endpoint"].ToString(),
                        AccessLevel = Convert.ToByte(row["access_level"]),
                        ParentFeatureKey =
                            row["parent_feature_key"] == null
                                ? null
                                : row["parent_feature_key"].ToString(),
                        PackageCode =
                            row["package_code"] == null
                                ? ""
                                : row["package_code"].ToString().Replace(" ", ""),
                        AllowAllLocation = row["allow_all_location"] == null ? false : Convert.ToBoolean(row["allow_all_location"])
                    };
                    moduleFeatureAccess.Add(item);
                }
                return moduleFeatureAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError(
                    $"Module GetModuleFeaturesAccessNew Error : {ex.Message}"
                );
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.NewMenuAccess>> GetMenusAccessNewMSSQL(
            long userId,
            long tenantId,
            long locationId,
            long userRoleId,
            string spMAN
        )
        {
            #region Instances
            List<Model.NewMenuAccess> newMenuAccess = new List<Model.NewMenuAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                IDataReader dataReader = _dataAccess.ExecuteReader(
                    spMAN,
                    userId,
                    userRoleId,
                    tenantId,
                    locationId
                );
                while (dataReader.Read())
                {
                    Model.NewMenuAccess item = new Model.NewMenuAccess()
                    {
                        ModuleId = Convert.ToInt64(dataReader["ModuleId"]),
                        ModuleCode = dataReader["ModuleCode"].ToString(),
                        ModuleName = dataReader["ModuleName"].ToString(),
                        MenuCaption = dataReader["Caption"].ToString(),
                        WebLink =
                            dataReader["WebLink"] == null ? "" : dataReader["WebLink"].ToString(),
                        LockedWebLink =
                            dataReader["LockedWebLink"] == null
                                ? ""
                                : dataReader["LockedWebLink"].ToString(),
                        AccessLevel = Convert.ToByte(dataReader["AccessLevel"]),
                        Beta = Convert.ToByte(dataReader["Beta"]),
                        PackageCode =
                            dataReader["PackageCode"] == null
                                ? ""
                                : dataReader["PackageCode"].ToString().Replace(" ", ""),
                        Priority = Convert.ToInt64(dataReader["Priority"]),
                        SequenceNumber = Convert.ToInt64(dataReader["SequenceNumber"]),
                        LandingPageUrl =
                            dataReader["LandingPageUrl"] == null
                                ? ""
                                : dataReader["LandingPageUrl"].ToString(),
                        MenuGroup = Convert.ToInt64(dataReader["MenuGroup"]),
                        GroupId =
                            dataReader["GroupId"] == null
                                ? 0
                                : Convert.ToInt64(dataReader["GroupId"]),
                        GroupIdDescription =
                            dataReader["GroupIdDescription"] == null
                                ? null
                                : dataReader["GroupIdDescription"].ToString(),
                        GroupIdSortOrder =
                            dataReader["GroupIdSortOrder"] == null
                                ? 0
                                : Convert.ToInt64(dataReader["GroupIdSortOrder"]),
                        AllowAllLocation = dataReader["AllowAllLocation"] == null ? false : Convert.ToBoolean(dataReader["AllowAllLocation"])
                    };
                    newMenuAccess.Add(item);
                }
                dataReader.Close();
                return newMenuAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Module GetMenus Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.NewMenuAccess>> GetMenusAccessNewPostgresql(
            long userId,
            long tenantId,
            long locationId,
            long userRoleId
        )
        {
            #region Instances
            List<Model.NewMenuAccess> newMenuAccess = new List<Model.NewMenuAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                DataTable dt = _pgDataAccess.ExecuteDataTableSQL("GetMenusAccess",
                    userId,
                    userRoleId,
                    tenantId,
                    locationId);
                foreach(DataRow row in dt.Rows)
                {
                    Model.NewMenuAccess item = new Model.NewMenuAccess()
                    {
                        ModuleId = Convert.ToInt64(row["module_id"]),
                        ModuleCode = row["module_code"].ToString(),
                        ModuleName = row["module_name"].ToString(),
                        MenuCaption = row["caption"].ToString(),
                        WebLink =
                            row["weblink"] == null ? "" : row["weblink"].ToString(),
                        LockedWebLink =
                            row["locked_web_link"] == null
                                ? ""
                                : row["locked_web_link"].ToString(),
                        AccessLevel = Convert.ToByte(row["access_level"]),
                        Beta = Convert.ToByte(row["beta"]),
                        PackageCode =
                            row["package_code"] == null
                                ? ""
                                : row["package_code"].ToString().Replace(" ", ""),
                        Priority = Convert.ToInt64(row["priority"]),
                        SequenceNumber = Convert.ToInt64(row["sequence_number"]),
                        LandingPageUrl =
                            row["landing_page_url"] == null
                                ? ""
                                : row["landing_page_url"].ToString(),
                        MenuGroup = Convert.ToInt64(row["menu_group"]),
                        GroupId =
                            row["group_id"] == null
                                ? 0
                                : Convert.ToInt64(row["group_id"]),
                        GroupIdDescription =
                            row["group_id_description"] == null
                                ? null
                                : row["group_id_description"].ToString(),
                        GroupIdSortOrder =
                            row["group_id_sort_order"] == null
                                ? 0
                                : Convert.ToInt64(row["group_id_sort_order"]),
                        AllowAllLocation = row["allow_all_location"] == null ? false : Convert.ToBoolean(row["allow_all_location"])
                    };
                    newMenuAccess.Add(item);
                }
                return newMenuAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Module GetMenus Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.MobileMenuAccess>> GetMobileMenusAccessMSSQL(
            long userId,
            long tenantId,
            long locationId,
            long userRoleId,
            string versionNumber,
            string spMAN
        )
        {
            #region Instances
            List<Model.MobileMenuAccess> newMenuAccess = new List<Model.MobileMenuAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                IDataReader dataReader = _dataAccess.ExecuteReader(
                    spMAN,
                    userId,
                    userRoleId,
                    tenantId,
                    locationId,
                    versionNumber
                );
                while (dataReader.Read())
                {
                    Model.MobileMenuAccess item = new Model.MobileMenuAccess()
                    {
                        ModuleId = Convert.ToInt64(dataReader["ModuleId"]),
                        ModuleCode = dataReader["ModuleCode"].ToString(),
                        ModuleName = dataReader["ModuleName"].ToString(),
                        MenuCaption = dataReader["Caption"].ToString(),
                        WebLink =
                            dataReader["WebLink"] == null ? "" : dataReader["WebLink"].ToString(),
                        LockedWebLink =
                            dataReader["LockedWebLink"] == null
                                ? ""
                                : dataReader["LockedWebLink"].ToString(),
                        AccessLevel = Convert.ToByte(dataReader["AccessLevel"]),
                        Beta = Convert.ToByte(dataReader["Beta"]),
                        PackageCode =
                            dataReader["PackageCode"] == null
                                ? ""
                                : dataReader["PackageCode"].ToString().Replace(" ", ""),
                        Priority = Convert.ToInt64(dataReader["Priority"]),
                        SequenceNumber = Convert.ToInt64(dataReader["SequenceNumber"]),
                        LandingPageUrl =
                            dataReader["LandingPageUrl"] == null
                                ? ""
                                : dataReader["LandingPageUrl"].ToString(),
                        MenuGroup = Convert.ToInt64(dataReader["MenuGroup"]),
                        GroupId =
                            dataReader["GroupId"] == null
                                ? 0
                                : Convert.ToInt64(dataReader["GroupId"]),
                        GroupIdDescription =
                            dataReader["GroupIdDescription"] == null
                                ? null
                                : dataReader["GroupIdDescription"].ToString(),
                        GroupIdSortOrder =
                            dataReader["GroupIdSortOrder"] == null
                                ? 0
                                : Convert.ToInt64(dataReader["GroupIdSortOrder"]),
                        VersionNumber =
                            dataReader["VersionNumber"] == null
                                ? ""
                                : dataReader["VersionNumber"].ToString(),
                        AllowAllLocation = dataReader["AllowAllLocation"] == null ? false : Convert.ToBoolean(dataReader["AllowAllLocation"])
                    };
                    newMenuAccess.Add(item);
                }
                dataReader.Close();
                return newMenuAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetMobileMenusAccess Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.MobileMenuAccess>> GetMobileMenusAccessPostgresql(
            long userId,
            long tenantId,
            long locationId,
            long userRoleId,
            string versionNumber
        )
        {
            #region Instances
            List<Model.MobileMenuAccess> newMenuAccess = new List<Model.MobileMenuAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                DataTable dt = _pgDataAccess.ExecuteDataTableSQL(
                    "GetMobileMenusAccess",
                    userId,
                    userRoleId,
                    tenantId,
                    locationId,
                    versionNumber
                );
                foreach(DataRow row in dt.Rows)
                {
                    Model.MobileMenuAccess item = new Model.MobileMenuAccess()
                    {
                        ModuleId = Convert.ToInt64(row["module_id"]),
                        ModuleCode = row["module_code"].ToString(),
                        ModuleName = row["module_name"].ToString(),
                        MenuCaption = row["caption"].ToString(),
                        WebLink =
                            row["weblink"] == null ? "" : row["weblink"].ToString(),
                        LockedWebLink =
                            row["locked_web_link"] == null
                                ? ""
                                : row["locked_web_link"].ToString(),
                        AccessLevel = Convert.ToByte(row["access_level"]),
                        Beta = Convert.ToByte(row["beta"]),
                        PackageCode =
                            row["package_code"] == null
                                ? ""
                                : row["package_code"].ToString().Replace(" ", ""),
                        Priority = Convert.ToInt64(row["priority"]),
                        SequenceNumber = Convert.ToInt64(row["sequence_number"]),
                        LandingPageUrl =
                            row["landing_page_url"] == null
                                ? ""
                                : row["landing_page_url"].ToString(),
                        MenuGroup = Convert.ToInt64(row["menu_group"]),
                        GroupId =
                            row["group_id"] == null
                                ? 0
                                : Convert.ToInt64(row["group_id"]),
                        GroupIdDescription =
                            row["group_id_description"] == null
                                ? null
                                : row["group_id_description"].ToString(),
                        GroupIdSortOrder =
                            row["group_id_sort_order"] == null
                                ? 0
                                : Convert.ToInt64(row["group_id_sort_order"]),
                        VersionNumber =
                            row["version_number"] == null
                                ? ""
                                : row["version_number"].ToString(),
                        AllowAllLocation = row["allow_all_location"] == null ? false : Convert.ToBoolean(row["allow_all_location"])
                    };
                    newMenuAccess.Add(item);
                }
                return newMenuAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetMobileMenusAccess Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.NewModuleFeatureAccess>> GetMobileModuleFeaturesAccessMSSQL(
            Model.SecurityAccessWithTenantId securityAccess,
            long locationId,
            string spMFAN
        )
        {
            #region Instances
            List<Model.NewModuleFeatureAccess> moduleFeatureAccess =
                new List<Model.NewModuleFeatureAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                IDataReader dataReader = _dataAccess.ExecuteReader(
                    spMFAN,
                    securityAccess.UserId,
                    securityAccess.RoleId,
                    securityAccess.TenantId,
                    locationId,
                    securityAccess.ModuleCode,
                    securityAccess.versionNumber
                );
                while (dataReader.Read())
                {
                    Model.NewModuleFeatureAccess item = new Model.NewModuleFeatureAccess()
                    {
                        ModuleCode =
                            dataReader["ModuleCode"] == null
                                ? ""
                                : dataReader["ModuleCode"].ToString(),
                        ModulefeatureCode =
                            dataReader["ModulefeatureCode"] == null
                                ? ""
                                : dataReader["ModulefeatureCode"].ToString(),
                        Name = dataReader["Name"] == null ? "" : dataReader["Name"].ToString(),
                        Caption =
                            dataReader["Caption"] == null ? "" : dataReader["Caption"].ToString(),
                        WebLink =
                            dataReader["WebLink"] == null
                                ? ""
                                : dataReader["WebLink"] == null
                                    ? ""
                                    : dataReader["WebLink"].ToString(),
                        Endpoint =
                            dataReader["Endpoint"] == null ? "" : dataReader["Endpoint"].ToString(),
                        AccessLevel = Convert.ToByte(dataReader["AccessLevel"]),
                        ParentFeatureKey =
                            dataReader["ParentFeatureKey"] == null
                                ? null
                                : dataReader["ParentFeatureKey"].ToString(),
                        PackageCode =
                            dataReader["PackageCode"] == null
                                ? ""
                                : dataReader["PackageCode"].ToString().Replace(" ", ""),
                        AllowAllLocation = dataReader["AllowAllLocation"] == null ? false : Convert.ToBoolean(dataReader["AllowAllLocation"])
                    };
                    moduleFeatureAccess.Add(item);
                }
                dataReader.Close();
                return moduleFeatureAccess;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetMobileModuleFeaturesAccess Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        public async Task<List<Model.NewModuleFeatureAccess>> GetMobileModuleFeaturesAccessPostgresql(
            Model.SecurityAccessWithTenantId securityAccess,
            long locationId
        )
        {
            #region Instances
            List<Model.NewModuleFeatureAccess> moduleFeatureAccess =
                new List<Model.NewModuleFeatureAccess>();
            #endregion

            #region Variables
            #endregion

            try
            {
                DataTable dt = _pgDataAccess.ExecuteDataTableSQL(
                    "GetMobileModuleFeaturesAccess",
                    Convert.ToInt32(securityAccess.UserId),
                    Convert.ToInt32(securityAccess.RoleId),
                    Convert.ToInt32(securityAccess.TenantId),
                    locationId,
                    securityAccess.ModuleCode,
                    securityAccess.versionNumber
                );
                foreach (DataRow row in dt.Rows)
                {
                    Model.NewModuleFeatureAccess item = new Model.NewModuleFeatureAccess()
                    {
                        ModuleCode =
                            row["module_code"] == null
                                ? ""
                                : row["module_code"].ToString(),
                        ModulefeatureCode =
                            row["module_feature_code"] == null
                                ? ""
                                : row["module_feature_code"].ToString(),
                        Name = row["name"] == null ? "" : row["name"].ToString(),
                        Caption =
                            row["caption"] == null ? "" : row["caption"].ToString(),
                        WebLink =
                            row["weblink"] == null
                                ? ""
                                : row["weblink"] == null
                                    ? ""
                                    : row["weblink"].ToString(),
                        Endpoint =
                            row["endpoint"] == null ? "" : row["endpoint"].ToString(),
                        AccessLevel = Convert.ToByte(row["access_level"]),
                        ParentFeatureKey =
                            row["parent_feature_key"] == null
                                ? null
                                : row["parent_feature_key"].ToString(),
                        PackageCode =
                            row["package_code"] == null
                                ? ""
                                : row["package_code"].ToString().Replace(" ", ""),
                        AllowAllLocation = row["allow_all_location"] == null ? false : Convert.ToBoolean(row["allow_all_location"])
                    };
                    moduleFeatureAccess.Add(item);
                }
                return moduleFeatureAccess;

            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetMobileModuleFeaturesAccess Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
