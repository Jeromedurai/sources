﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace XtraChef.API.Security.Query.Repository
{
    public class AccessGroupDetail
        : BaseQueryRepository<Model.AccessGroupDetail, Context.AccessGroupDetail>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public AccessGroupDetail(Context.AccessGroupDetail dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.AccessGroupDetail> GetById(
            string tenantId,
            string locationId,
            string id
        )
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Access Group  By accessGroupId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="accessGroupId">AccessGroupId.</param>
        public async Task<Model.AccessGroupDetail> GetAccessGroupDetail(
            string accessGroupId,
            string moduleFeatureCode,
            string spMAGD
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetAccessGroupDetail ");

                #region Variables
                // AccessGroupId
                SqlParameter AccessGroupId = new SqlParameter
                {
                    ParameterName = "@ACCESSGROUPID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = accessGroupId
                };
                // ModuleFeatureCode
                SqlParameter ModuleFeatureCode = new SqlParameter
                {
                    ParameterName = "@MODULEFEATURECODE",
                    SqlDbType = SqlDbType.VarChar,
                    Value = moduleFeatureCode
                };

                #endregion
                //Getting Access Group Detail
                Model.AccessGroupDetail accessGroupDetail = this.DbContext.UserGroupUploads
                    .FromSqlRaw(
                        $"exec {spMAGD} @ACCESSGROUPID, @MODULEFEATURECODE",
                        AccessGroupId,
                        ModuleFeatureCode
                    )
                    .AsNoTracking()
                    .AsEnumerable()
                    .FirstOrDefault();

                //Logger
                await this.Logger.LogInfo($"Called GetAccessGroupDetail");

                //return
                return accessGroupDetail;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetAccessGroupDetail Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified User Group Mapping.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="userGroupId">UserGroupId.</param>
        public async Task<Model.UserGroupMapping> GetUserGroupMapping(
            string accessGroupId,
            string tenantId,
            string locationId,
            string userRoleId,
            string userId,
            string spMUGM
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetUserGroupMapping");

                #region Variables
                // AccessGroupId
                SqlParameter AccessGroupId = new SqlParameter
                {
                    ParameterName = "@ACCESSGROUPID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = accessGroupId
                };
                // TenantId
                SqlParameter TenantId = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = tenantId
                };
                // LocationId
                SqlParameter LocationId = new SqlParameter
                {
                    ParameterName = "@LOCATIONID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = locationId
                };
                // UserId
                SqlParameter UserId = new SqlParameter
                {
                    ParameterName = "@USERID",
                    SqlDbType = SqlDbType.VarChar,
                    Value = userId
                };
                // UserRoleId
                SqlParameter UserRoleId = new SqlParameter
                {
                    ParameterName = "@USERROLEID",
                    SqlDbType = SqlDbType.VarChar,
                    Value = userRoleId
                };

                #endregion
                //Getting Invoice upload aggeregate
                Model.UserGroupMapping userGroupMappingItem = this.DbContext.UserGroupMappings
                    .FromSqlRaw(
                        $"exec {spMUGM} @ACCESSGROUPID, @TENANTID, @LOCATIONID, @USERID, @USERROLEID",
                        AccessGroupId,
                        TenantId,
                        LocationId,
                        UserId,
                        UserRoleId
                    )
                    .AsNoTracking()
                    .AsEnumerable()
                    .FirstOrDefault();

                //Logger
                await this.Logger.LogInfo($"Called GetUserGroupMapping");

                //return
                return userGroupMappingItem;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetUserGroupMappingById Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified User Group.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="userGroupId">UserGroupId.</param>
        public async Task<List<Model.AccessGroupDetail>> GetAccessGroupDetails()
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetAccessGroupDetails ");

                //Local variable
                IQueryable<Model.AccessGroupDetail> query;

                #region Query Builder

                query = DbContext.UserGroupUploads.AsQueryable();

                #endregion

                //Executing query
                List<Model.AccessGroupDetail> modules = await query.ToListAsync();

                //Logger
                await this.Logger.LogInfo($"Called GetAccessGroupDetails");

                //return
                return modules;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"When GetAccessGroupDetails Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
