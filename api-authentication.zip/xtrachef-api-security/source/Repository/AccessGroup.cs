﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base.Extensions;
using Sa.Common.WebAPI.Base.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XtraChef.API.Security.Query.Repository
{
    public class AccessGroup : BaseQueryRepository<Model.AccessGroup, Context.AccessGroup>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public AccessGroup(Context.AccessGroup dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods


        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.AccessGroup> GetById(
            string tenantId,
            string locationId,
            string id
        )
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Access Group By accessGroupId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="accessGroupId">AccessGroupId.</param>
        public async Task<Model.AccessGroup> GetAccessGroupById(string accessGroupId)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetAccessGroupById ");

                //Get Access Group By Id
                Model.AccessGroup accessGroup = await this.DbContext.AccessGroups
                    .Where(x => x.Id.Equals(long.Parse(accessGroupId)))
                    .FirstOrDefaultWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called GetAccessGroupById");

                //return
                return accessGroup;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetAccessGroupById Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified access group By tenantId and locationId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="tenantId">TenantId.</param>
        /// <param name="locationId">LocationId.</param>
        public async Task<Model.AccessGroupList> GetAccessGroups(string tenantId, string locationId)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetAccessGroups");

                //Local variable
                Model.AccessGroupList accessGroups = new Model.AccessGroupList();

                //Local variable
                List<Model.AccessGroup> accessGroupList = this.DbContext.AccessGroups
                    .Where(
                        x =>
                            x.TenantId == long.Parse(tenantId)
                            && x.LocationId == long.Parse(locationId)
                    )
                    .ToListWithNoLock();

                List<Model.Group> groups = new List<Model.Group>();
                accessGroupList.ForEach(accessGroup =>
                {
                    Model.Group groupItem = new Model.Group();

                    List<Model.AccessGroupDetail> accessGroupDetailList =
                        this.DbContext.AccessGroupDetails
                            .Where(x => x.AccessGroupId == accessGroup.Id)
                            .ToListWithNoLock();
                    List<string> moduleFeatureIds = accessGroupDetailList
                        .Select(x => x.ModuleFeatureCode)
                        .Distinct()
                        .ToList();

                    List<Model.ModuleFeature> featurelList = new List<Model.ModuleFeature>();
                    moduleFeatureIds.ForEach(moduleFeatureId =>
                    {
                        Model.ModuleFeature featurelItem = this.DbContext.ModuleFeatures
                            .Where(x => x.ModuleFeatureCode == moduleFeatureId)
                            .FirstOrDefaultWithNoLock();
                        featurelList.Add(featurelItem);
                    });
                    List<string> moduleIds = featurelList
                        .Select(x => x.ModuleCode)
                        .Distinct()
                        .ToList();

                    List<Model.AccessGroupModule> modules = new List<Model.AccessGroupModule>();
                    List<Model.ModuleFeature> modulelList = new List<Model.ModuleFeature>();
                    moduleIds.ForEach(moduleId =>
                    {
                        Model.ModuleFeature moduleItem = this.DbContext.ModuleFeatures
                            .Where(x => x.ModuleFeatureCode == moduleId && x.Type == "Modules")
                            .FirstOrDefaultWithNoLock();
                        modulelList.Add(moduleItem);
                    });
                    modulelList.ForEach(modulelItem =>
                    {
                        Model.AccessGroupModule moduleItem = new Model.AccessGroupModule();
                        List<Model.AccessGroupFeature> features =
                            new List<Model.AccessGroupFeature>();

                        featurelList.ForEach(feature =>
                        {
                            accessGroupDetailList.ForEach(Item =>
                            {
                                if (
                                    feature.ModuleFeatureCode == Item.ModuleFeatureCode
                                    && feature.ModuleCode == modulelItem.ModuleFeatureCode
                                    && !features.Any(item => item.id == Item.ModuleFeatureCode)
                                )
                                {
                                    Model.AccessGroupFeature featureItem =
                                        new Model.AccessGroupFeature()
                                        {
                                            id = feature.ModuleFeatureCode,
                                            featureName = feature.Name,
                                            accessLevel = Item.AccessLevel
                                        };
                                    features.Add(featureItem);
                                }
                            });
                        });

                        moduleItem.id = modulelItem.Pk;
                        moduleItem.moduleName = modulelItem.Name;
                        moduleItem.features = features;
                        modules.Add(moduleItem);
                    });

                    groupItem.id = accessGroup.Id;
                    groupItem.accessGroupName = accessGroup.AccessGroupname;
                    groupItem.modules = modules;
                    groups.Add(groupItem);
                });
                accessGroups.locationId = Convert.ToInt64(locationId);
                accessGroups.groups = groups;
                //Logger
                await this.Logger.LogInfo($"Called GetAccessGroups");

                //return
                return accessGroups;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetAccessGroups Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Module Entity By moduleId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">moduleId.</param>
        public async Task<List<Model.AccessGroup>> GetUserGroups(string tenantId, string locationId)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetUserGroupList");

                #region Query Builder
                IQueryable<Model.AccessGroup> query = this.DbContext.AccessGroups.AsQueryable();

                //tenantId
                if (!string.IsNullOrEmpty(locationId))
                    query = query.Where(x => x.TenantId.Equals(tenantId));

                //LocationId
                if (!string.IsNullOrEmpty(locationId))
                    query = query.Where(x => x.LocationId.Equals(locationId));

                #endregion

                //Executing query
                List<Model.AccessGroup> userGroupItems = await query.ToListAsync();

                //Logger
                await this.Logger.LogInfo($"Called GetUserGroupList");

                //return
                return userGroupItems;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetUserGroupList Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Module Entity By moduleId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">moduleId.</param>
        public async Task<List<Model.AccessGroupDetail>> GetUserGroups(long groupId)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetUserGroupList");

                List<Model.AccessGroupDetail> userGroupList =
                    await this.DbContext.AccessGroupDetails
                        .Where(x => x.AccessGroupId.Equals(groupId))
                        .ToListWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called GetUserGroupList");

                //return
                return userGroupList;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetUserGroupList Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
