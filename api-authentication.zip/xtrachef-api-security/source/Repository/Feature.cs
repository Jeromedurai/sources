﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base.Extensions;
using Sa.Common.WebAPI.Base.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XtraChef.API.Security.Query.Repository
{
    public class Feature : BaseQueryRepository<Model.ModuleFeature, Context.Feature>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public Feature(Context.Feature dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.ModuleFeature> GetById(
            string tenantId,
            string locationId,
            string id
        )
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Feature Entity By featureId .
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="featureId">featureId.</param>
        public async Task<Model.ModuleFeature> GetFeatureById(string featureId)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling Feature GetFeatureById ");

                //Getting Feature aggeregate
                Model.ModuleFeature featureItem = await this.DbContext.moduleFeature
                    .Where(x => x.ModuleFeatureCode == featureId && x.Type == "Features")
                    .FirstOrDefaultWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called Feature GetFeatureById");

                //return
                return featureItem;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Feature GetFeatureById Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Feature Entity By moduleId .
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="featureId">featureId.</param>
        public async Task<List<Model.ModuleFeature>> GetFeaturesByModuleId(string moduleId)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling Feature GetFeaturesByModuleId ");

                //Getting Invoice upload aggeregate
                List<Model.ModuleFeature> featureItem = await this.DbContext.moduleFeature
                    .Where(x => x.ModuleCode == moduleId && x.Type == "Features")
                    .ToListWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called Feature GetFeaturesByModuleId");

                //return
                return featureItem;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Feature GetFeaturesByModuleId Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Feature List Entity.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">moduleId.</param>
        public async Task<List<Model.ModuleFeature>> GetFeaturesDetail()
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetFeaturesDetail");

                //Executing query
                List<Model.ModuleFeature> featuresDetail = await this.DbContext.moduleFeature
                    .AsQueryable()
                    .Where(x => x.Type == "Features")
                    .ToListWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called GetFeaturesDetail");

                //return
                return featuresDetail;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetFeaturesDetail Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// get the location entity.
        /// </summary>
        /// <returns>Lcoation Entity details</returns>
        /// <param name="tenantId">Entity.</param>
        /// <param name="entityId"></param>
        /// <param name="spName"></param>
        public async Task<List<Model.LocationEntityConfig>> GetLocationEntity(
            string tenantId,
            string entityId,
            string configKey,
            string spName
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo(
                    $"Calling GetLocationEntity for tenant : {tenantId} , entityId : {entityId}"
                );

                SqlParameter Tenant = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = System.Data.SqlDbType.BigInt,
                    SqlValue = Convert.ToInt64(tenantId)
                };

                SqlParameter EntityId = new SqlParameter
                {
                    ParameterName = "@ENTITYID",
                    SqlDbType = System.Data.SqlDbType.BigInt,
                    SqlValue = Convert.ToInt64(entityId)
                };

                SqlParameter ConfigId = new SqlParameter
                {
                    ParameterName = "@CONFIGKEY",
                    SqlDbType = System.Data.SqlDbType.BigInt,
                    SqlValue = Convert.ToInt64(configKey)
                };

                SqlParameter Active = new SqlParameter
                {
                    ParameterName = "@ACTIVE",
                    SqlDbType = System.Data.SqlDbType.Bit,
                    SqlValue = true
                };

                List<Model.LocationEntityConfig> locationEntities =
                    await this.DbContext.LocationEntities
                        .FromSqlRaw(
                            $"exec {spName} @TENANTID,@ENTITYID,@CONFIGKEY,@ACTIVE",
                            Tenant,
                            EntityId,
                            ConfigId,
                            Active
                        )
                        .AsNoTracking()
                        .ToListAsync();

                await this.Logger.LogInfo(
                    $"Called GetLocationEntity for tenant : {tenantId} , entityId : {entityId}"
                );

                //return success
                return locationEntities;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError(
                    $"Error while calling GetLocationEntity for tenant : {tenantId} , entityId : {entityId} : {ex.Message}"
                );
                await this.Logger.LogError($"Inner exception:{ex.InnerException}");
                await this.Logger.LogError($"Stack Trace:{ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// get the location entity.
        /// </summary>
        /// <returns>Lcoation Entity details</returns>
        /// <param name="tenantId">Entity.</param>
        /// <param name="entityId"></param>
        /// <param name="spName"></param>
        public async Task<List<Model.OrderGuide>> GetOrderGuideKey(
            string tenantId,
            string entityId,
            string spName
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo(
                    $"Calling GetLocationEntity for tenant : {tenantId} , entityId : {entityId}"
                );

                SqlParameter Tenant = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = System.Data.SqlDbType.BigInt,
                    SqlValue = Convert.ToInt64(tenantId)
                };

                SqlParameter EntityId = new SqlParameter
                {
                    ParameterName = "@ORDERID",
                    SqlDbType = System.Data.SqlDbType.BigInt,
                    SqlValue = Convert.ToInt64(entityId)
                };

                List<Model.OrderGuide> locationEntities = await this.DbContext.OrderGuides
                    .FromSqlRaw($"exec {spName} @TENANTID,@ORDERID", Tenant, EntityId)
                    .AsNoTracking()
                    .ToListAsync();

                await this.Logger.LogInfo(
                    $"Called GetLocationEntity for tenant : {tenantId} , entityId : {entityId}"
                );

                //return success
                return locationEntities;
            }
            catch (System.Exception ex)
            {
                //Error logging
                await this.Logger.LogError(
                    $"Error while calling GetLocationEntity for tenant : {tenantId} , entityId : {entityId} : {ex.Message}"
                );
                await this.Logger.LogError($"Inner exception:{ex.InnerException}");
                await this.Logger.LogError($"Stack Trace:{ex.StackTrace}");
                throw;
            }
        }

        #endregion

        #region Private Methods

        public Model.Feature GetFeature(Model.ModuleFeature feature)
        {
            try
            {
                Model.Feature featureDetail = new Model.Feature()
                {
                    Pk = feature.Pk,
                    Guid = feature.Guid,
                    ModuleFeatureCode = feature.ModuleFeatureCode,
                    Name = feature.Name,
                    Active = feature.Active,
                    Caption = feature.Caption,
                    Type = feature.Type,
                    ModuleCode = feature.ModuleCode,
                    ModuleName = this.DbContext.moduleFeature
                        .Where(
                            x => x.ModuleFeatureCode == feature.ModuleCode && x.Type == "Modules"
                        )
                        .FirstOrDefaultWithNoLockAsync()
                        .Result.Name,
                    ParentFeatureKey = feature.ParentFeatureKey,
                    Endpoint = feature.Endpoint,
                    Beta = feature.Beta,
                    WebLink = feature.WebLink,
                    Priority = feature.Priority,
                    LockedWebLink = feature.LockedWebLink,
                    MenuGroup = feature.MenuGroup,
                    System = feature.System,
                    ListPrice = feature.ListPrice,
                    ListPriceType = feature.ListPriceType,
                    ValidFrom = feature.ValidFrom,
                    ExpiresOn = feature.ExpiresOn,
                    Json = feature.Json
                };

                return featureDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"When GetFeature Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
