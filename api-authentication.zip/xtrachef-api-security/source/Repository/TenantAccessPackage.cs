﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sa.Common.WebAPI.Base.Repository;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base.Extensions;

namespace XtraChef.API.Security.Query.Repository
{
    public class TenantAccessPackage
        : BaseQueryRepository<Model.TenantAccessPackage, Context.TenantAccessPackage>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public TenantAccessPackage(Context.TenantAccessPackage dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.TenantAccessPackage> GetById(
            string tenantId,
            string locationId,
            string id
        )
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Package Entity By tenantAccessPackageId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="tenantAccessPackageId">TenantAccessPackageId.</param>
        public async Task<Model.TenantAccessPackage> GetTenantAccessPackage(
            string tenantId,
            string locationId,
            string packageCode,
            string spTAP
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetTenantAccessPackage");

                #region Variables
                // TenantId
                SqlParameter TenantId = new SqlParameter
                {
                    ParameterName = "@TENANTID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = tenantId
                };
                // LocationId
                SqlParameter LocationId = new SqlParameter
                {
                    ParameterName = "@LOCATIONID",
                    SqlDbType = SqlDbType.BigInt,
                    Value = locationId
                };
                // PackageCode
                SqlParameter PackageCode = new SqlParameter
                {
                    ParameterName = "@PACKAGECODE",
                    SqlDbType = SqlDbType.VarChar,
                    Value = packageCode
                };

                #endregion
                //Getting Package Codes item aggeregate
                Model.TenantAccessPackage tenantAccessPackage = this.DbContext.tenantAccessPackage
                    .FromSqlRaw(
                        $"exec {spTAP} @TENANTID, @LOCATIONID, @PACKAGECODE",
                        TenantId,
                        LocationId,
                        PackageCode
                    )
                    .AsNoTracking()
                    .AsEnumerable()
                    .FirstOrDefault();

                //Logger
                await this.Logger.LogInfo($"Called GetTenantAccessPackage");

                //return
                return tenantAccessPackage;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetTenantAccessPackageById Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Tenant Access Packages Entity.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="tenantId">TenantId.</param>
        /// <param name="locationId">LocationId.</param>
        public async Task<Model.TenantAccessPackage> GetTenantAccessPackages(
            long tenantId,
            long locationId
        )
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetTenantAccessPackages");

                //Getting Package Codes item aggeregate
                Model.TenantAccessPackage tenantAccessPackage =
                    await this.DbContext.tenantAccessPackage
                        .Where(x => x.Id == tenantId)
                        .FirstOrDefaultWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called GetTenantAccessPackages");

                //return
                return tenantAccessPackage;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetTenantAccessPackages Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
