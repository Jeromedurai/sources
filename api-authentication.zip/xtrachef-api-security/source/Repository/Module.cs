﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Sa.Common.WebAPI.Base.Repository;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base.Extensions;

namespace XtraChef.API.Security.Query.Repository
{
    public class Module : BaseQueryRepository<Model.ModuleFeature, Context.Module>
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.Invoice.Command.Repository.Invoice"/> class.
        /// </summary>
        /// <param name="dbContext">Db context.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public Module(Context.Module dbContext, LogPublisher logPublisher)
            : base(dbContext, logPublisher) { }

        #endregion

        #region Overridden Methods

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <returns>The by identifier.</returns>
        /// <param name="tenantId">Tenant identifier.</param>
        /// <param name="locationId">Location identifier.</param>
        /// <param name="id">Identifier.</param>
        public override Task<Model.ModuleFeature> GetById(
            string tenantId,
            string locationId,
            string id
        )
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get the specified Module Entity By moduleId.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">ModuleId.</param>
        public async Task<Model.ModuleFeature> GetModuleById(string moduleId)
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling Module GetModuleById");

                //Getting module item aggeregate
                Model.ModuleFeature moduleItem = await this.DbContext.moduleFeature
                    .Where(x => x.ModuleFeatureCode == moduleId && x.Type == "Modules")
                    .FirstOrDefaultWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called Module GetModuleById");

                //return
                return moduleItem;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"Module GetById Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        /// <summary>
        /// Get the specified Module Entity.
        /// </summary>
        ///  <returns>The by identifier.</returns>
        /// <param name="moduleId">moduleId.</param>
        public async Task<List<Model.ModuleFeature>> GetModulesDetail()
        {
            try
            {
                //Logger
                await this.Logger.LogInfo($"Calling GetModulesDetail");

                //Executing query
                List<Model.ModuleFeature> modulesDetail = await this.DbContext.moduleFeature
                    .AsQueryable()
                    .Where(x => x.Type == "Modules")
                    .ToListWithNoLockAsync();

                //Logger
                await this.Logger.LogInfo($"Called GetModulesDetail");

                //return
                return modulesDetail;
            }
            catch (Exception ex)
            {
                //Error logging
                await this.Logger.LogError($"GetModulesDetail Error : {ex.Message}");
                await this.Logger.LogError($"Inner exception : {ex.InnerException}");
                await this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion

        #region Private Methods

        public Model.Module GetModule(Model.ModuleFeature module)
        {
            try
            {
                Model.Module moduleDetail = new Model.Module()
                {
                    Pk = module.Pk,
                    Guid = module.Guid,
                    ModuleFeatureCode = module.ModuleFeatureCode,
                    Name = module.Name,
                    Caption = module.Caption,
                    Type = module.Type,
                    ModuleCode = module.ModuleCode,
                    Active = module.Active,
                    ParentFeatureKey = module.ParentFeatureKey,
                    Endpoint = module.Endpoint,
                    Beta = module.Beta,
                    WebLink = module.WebLink,
                    Priority = module.Priority,
                    LockedWebLink = module.LockedWebLink,
                    MenuGroup = module.MenuGroup,
                    System = module.System,
                    ListPrice = module.ListPrice,
                    ListPriceType = module.ListPriceType,
                    ValidFrom = module.ValidFrom,
                    ExpiresOn = module.ExpiresOn,
                    Json = module.Json
                };

                return moduleDetail;
            }
            catch (System.Exception ex)
            {
                //Error logging
                this.Logger.LogError($"Module GetModule Error : {ex.Message}");
                this.Logger.LogError($"Inner exception : {ex.InnerException}");
                this.Logger.LogError($"Stack trace : {ex.StackTrace}");
                throw;
            }
        }

        #endregion
    }
}
