﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Model;
using Swashbuckle.AspNetCore.Annotations;

namespace XtraChef.API.Security.Query.Controllers
{
    [Route("api/1.0/[Controller]")]
    [ApiActionFilter]
    public class AccessGroupDetailsController : APIControllerBase<Services.AccessGroupDetail>
    {
        #region Variable

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="T:XtraChef.API.Security.Query.AccessGroupDetailsController"/> class.
        /// </summary>
        /// <param name="service">Service.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public AccessGroupDetailsController(
            Services.AccessGroupDetail service,
            IConfiguration configuration,
            LogPublisher logPublisher
        )
            : base(service, configuration, logPublisher) { }

        #endregion

        #region GET Access Group Detail Methods

        /// <summary>
        /// Get Access Group Detail By accessGroupDetailId.
        /// </summary>
        /// <param name="accessGroupId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{accessGroupId}/modulefeaturecode/{moduleFeatureCode}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetAccessGroupDetail(
            [FromRoute] string accessGroupId,
            [FromRoute] string moduleFeatureCode
        )
        {
            try
            {
                //Local variable
                Model.AccessGroupDetail response = null;
                response = this.Service.GetAccessGroupDetail(accessGroupId, moduleFeatureCode);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get List of Access Group Detail For That Tenant.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("access-group-list")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetAccessGroupDetails()
        {
            try
            {
                //Local variable
                List<Model.AccessGroupDetail> response = null;
                response = this.Service.GetAccessGroupDetails();

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        #endregion

        #region GET User Group Mapping Methods

        /// <summary>
        /// Get User Group Mapping.
        /// </summary>
        /// <param name="accessGroupId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route(
            "{accessGroupId}/tenants/{tenantId}/locations/{locationId}/userroles/{userRoleId}/users/{userId}"
        )]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetUserGroupMapping(
            [FromRoute] string accessGroupId,
            [FromRoute] string tenantId,
            [FromRoute] string locationId,
            [FromRoute] string userRoleId,
            [FromRoute] string userId
        )
        {
            try
            {
                //Local variable
                Model.UserGroupMapping response = null;
                response = this.Service.GetUserGroupMapping(
                    accessGroupId,
                    tenantId,
                    locationId,
                    userRoleId,
                    userId
                );

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        #endregion
    }
}
