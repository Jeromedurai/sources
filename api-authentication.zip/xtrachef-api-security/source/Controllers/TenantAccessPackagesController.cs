﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Model;
using Sa.Common.SeriLog;

namespace XtraChef.API.Security.Query.Controllers
{
    [Route("api/1.0/[Controller]")]
    [ApiActionFilter]
    public class TenantAccessPackagesController : APIControllerBase<Services.TenantAccessPackage>
    {
        #region Variable

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="T:XtraChef.API.Security.Query.ModulesController"/> class.
        /// </summary>
        /// <param name="service">Service.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public TenantAccessPackagesController(
            Services.TenantAccessPackage service,
            IConfiguration configuration,
            LogPublisher logPublisher
        )
            : base(service, configuration, logPublisher) { }

        #endregion

        #region GET Methods

        /// <summary>
        /// Get Module By tenantAccessPackageId.
        /// </summary>
        /// <param name="packageCode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("tenants/{tenantId}/locations/{locationId}/packagecodes/{packageCode}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetTenantAccessPackage(
            [FromRoute] string tenantId,
            [FromRoute] string locationId,
            [FromRoute] string packageCode
        )
        {
            try
            {
                //Local variable
                Model.TenantAccessPackage response = null;
                response = this.Service.GetTenantAccessPackage(tenantId, locationId, packageCode);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Module By tenantAccessPackageId.
        /// </summary>
        /// <param name="tenantAccessPackageId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("{access-packages}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetTenantAccessPackages()
        {
            try
            {
                //Local variable
                Model.TenantAccessPackage response = null;
                response = this.Service.GetTenantAccessPackages();

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        #endregion
    }
}
