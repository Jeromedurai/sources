﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Model;
using Sa.Common.SeriLog;

namespace XtraChef.API.Security.Query.Controllers
{
    [Route("api/1.0/[Controller]")]
    [ApiActionFilter]
    public class FeaturesController : APIControllerBase<Services.Feature>
    {
        #region Variable

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="T:XtraChef.API.Security.Query.FeaturesController"/> class.
        /// </summary>
        /// <param name="service">Service.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public FeaturesController(
            Services.Feature service,
            IConfiguration configuration,
            LogPublisher logPublisher
        )
            : base(service, configuration, logPublisher) { }

        #endregion

        #region Get Methods

        /// <summary>
        /// Get Feature By featureId
        /// </summary>
        /// <param name="featureId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{featureId}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetFeatureById([FromRoute] string featureId)
        {
            try
            {
                //Local variable
                Model.Feature response = null;

                response = this.Service.GetFeatureById(featureId);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Features By moduleId
        /// </summary>
        /// <param name="moduleId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("module/{moduleId}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetFeaturesByModuleId([FromRoute] string moduleId)
        {
            try
            {
                //Local variable
                List<Model.ModuleFeature> response = null;

                response = this.Service.GetFeaturesByModuleId(moduleId);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get List of Features detail.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("features-detail")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetFeaturesDetail()
        {
            try
            {
                //Local variable
                List<Model.ModuleFeature> response = null;
                response = this.Service.GetFeaturesDetail();

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get List of Features detail.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("tenants/{tenantId}/config/{configKey}/entity/{entityId}/get-location-configs")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetLocationFeatures(
            [FromRoute] string tenantId,
            [FromRoute] string configKey,
            [FromRoute] string entityId
        )
        {
            try
            {
                //Local variable
                Model.LocationConfigResponse response = null;
                response = this.Service.GetLocationFeatures(tenantId, configKey, entityId).Result;

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        #endregion
    }
}
