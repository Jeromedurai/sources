﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Model;
using Sa.Common.SeriLog;

namespace XtraChef.API.Security.Query.Controllers
{
    [Route("api/1.0/[Controller]")]
    [ApiActionFilter]
    public class PackageDetailsController : APIControllerBase<Services.PackageDetail>
    {
        #region Variable

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="T:XtraChef.API.Security.Query.ModulesController"/> class.
        /// </summary>
        /// <param name="service">Service.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public PackageDetailsController(
            Services.PackageDetail service,
            IConfiguration configuration,
            LogPublisher logPublisher
        )
            : base(service, configuration, logPublisher) { }

        #endregion

        #region GET Methods

        /// <summary>
        /// Get Module By id.
        /// </summary>
        /// <param name="packageDetailId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("packagecodes/{packageCode}/modulefeaturecodes/{moduleFeatureCode}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetPackageDetail(
            [FromRoute] string packageCode,
            [FromRoute] string moduleFeatureCode
        )
        {
            try
            {
                //Local variable
                Model.PackageDetail response = null;
                response = this.Service.GetPackageDetail(packageCode, moduleFeatureCode);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        #endregion
    }
}
