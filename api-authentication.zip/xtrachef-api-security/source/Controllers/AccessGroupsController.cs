﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Sa.Common.SeriLog;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Model;
using Swashbuckle.AspNetCore.Annotations;

namespace XtraChef.API.Security.Query.Controllers
{
    [Route("api/1.0/[Controller]")]
    [ApiActionFilter]
    public class AccessGroupsController : APIControllerBase<Services.AccessGroup>
    {
        #region Variable

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="T:XtraChef.API.Security.Query.AccessGroupsController"/> class.
        /// </summary>
        /// <param name="service">Service.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public AccessGroupsController(
            Services.AccessGroup service,
            IConfiguration configuration,
            LogPublisher logPublisher
        )
            : base(service, configuration, logPublisher) { }

        #endregion

        #region GET Methods

        /// <summary>
        /// Get Access Group By accessGroupId.
        /// </summary>
        /// <param name="userGroupId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{accessGroupId}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetAccessGroupById([FromRoute] string accessGroupId)
        {
            try
            {
                //Local variable
                Model.AccessGroup response = null;
                response = this.Service.GetAccessGroupById(accessGroupId);

                //return access group
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Access For That TenantId and LocationId.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("access-groups-detail")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetAccessGroups()
        {
            try
            {
                //Local variable
                Model.AccessGroupList response = null;

                response = this.Service.GetAccessGroups();

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        #endregion
    }
}
