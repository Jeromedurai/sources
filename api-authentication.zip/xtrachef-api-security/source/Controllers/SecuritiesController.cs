﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using XtraChef.API.Security.Query.Model;
using Sa.Common.WebAPI.Base;
using Sa.Common.WebAPI.Base.Model;
using Sa.Common.SeriLog;

namespace XtraChef.API.Security.Query.Controllers
{
    [Route("api/1.0/[Controller]")]
    [ApiActionFilter]
    public class SecuritiesController : APIControllerBase<Services.Security>
    {
        #region Variables

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="T:XtraChef.API.Security.Query.SecuritiesController"/> class.
        /// </summary>
        /// <param name="service">Service.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="logPublisher">logPublisher.</param>
        public SecuritiesController(
            Services.Security service,
            IConfiguration configuration,
            LogPublisher logPublisher
        )
            : base(service, configuration, logPublisher) { }

        #endregion

        #region POST Methods

        /// <summary>
        /// Get Module Enabled.
        /// </summary>
        /// <param name="">UserId</param>
        /// <param name="">UserRole</param>
        /// <param name="">TenantId</param>
        /// <param name="">LocationId</param>
        /// <param name="">ModuleId</param>
        /// <returns></returns>
        [HttpPost]
        [Route("module-enabled")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetModuleEnabled([FromBody] SecurityAccess SecurityAccess)
        {
            try
            {
                bool response = this.Service.GetModuleEnabled(SecurityAccess);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Endpoint Enabled For That Endpoint.
        /// </summary>
        /// <param name="">Endpoint</param>
        /// <returns></returns>
        [HttpPost]
        [Route("endpoint-enabled")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetEndpointEnabled([FromBody] FeatureEnabled featureEnabled)
        {
            try
            {
                //Local variable
                string endpoint = null;

                if (featureEnabled.Endpoint != null)
                {
                    //convert the endpoint into string
                    endpoint = featureEnabled.Endpoint.ToString();
                }
                else
                {
                    //return module
                    return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = null });
                }
                //Get Module Enabled
                Model.Features response = this.Service.GetEndpointEnabled(endpoint);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Module feature Access For That UserId, UserRole, TenantId, LocationId, ModuleId and Endpoint.
        /// </summary>
        /// <param name="">UserId</param>
        /// <param name="">UserRole</param>
        /// <param name="">TenantId</param>
        /// <param name="">LocationId</param>
        /// <param name="">ModuleId</param>
        /// <param name="">Endpoint</param>
        /// <returns></returns>
        [HttpPost]
        [Route("module-endpoint-access")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetModuleEndpointAccess([FromBody] SecurityAccess securityAccess)
        {
            try
            {
                //Local variable
                Model.AccessSetting response = new Model.AccessSetting();
                if (securityAccess.ModuleCode == null || securityAccess.ModuleCode == "")
                {
                    //return module
                    return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
                }

                response = this.Service.GetModuleEndpointAccess(securityAccess);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Module Features Access List For That User and Module.
        /// </summary>
        /// <param name="">UserId</param>
        /// <param name="">UserRole</param>
        /// <param name="">TenantId</param>
        /// <param name="">LocationId</param>
        /// <param name="">ModuleId</param>
        /// <returns></returns>
        [HttpPost]
        [InternalUseOnly]
        [Route("module-features-access-old")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetModuleFeaturesAccess(
            [FromBody] SecurityAccessWithTenantId SecurityAccess
        )
        {
            try
            {
                //Local variable
                List<Model.ModuleFeatureList> response = null;

                response = this.Service.GetModuleFeaturesAccessWithTenantId(SecurityAccess);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Menus with access level.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("menus-access-old")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetMenusAccess([FromBody] Model.SecurityAccess securityAccess)
        {
            try
            {
                //Local variable
                List<Model.MenuAccess> response = null;
                response = this.Service.GetMenusAccess(securityAccess);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Module Features Access List For That User and Module.
        /// </summary>
        /// <param name="">UserId</param>
        /// <param name="">UserRole</param>
        /// <param name="">TenantId</param>
        /// <param name="">LocationId</param>
        /// <param name="">ModuleId</param>
        /// <returns></returns>
        [HttpPost]
        [InternalUseOnly]
        [Route("module-features-access")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetModuleFeaturesAccessNew(
            [FromBody] Model.SecurityAccessWithTenantId securityAccess
        )
        {
            try
            {
                System.Guid guidId = System.Guid.NewGuid();
                DateTime startTime = DateTime.Now;
                this.Logger.LogInfo(
                    $"Controller GetModuleFeaturesAccessNew Start (new module features access) - guidId : {guidId}"
                );
                //Local variable
                List<Model.ModuleFeatureList> response = this.Service.GetModuleFeaturesAccessNew(
                    securityAccess,
                    guidId
                );
                this.Logger.LogInfo(
                    $"Total Time {DateTime.Now - startTime} Controller GetModuleFeaturesAccessNew End (new module features access) - guidId : {guidId}"
                );

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Menus with access level.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("menus-access")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetMenusAccessNew([FromBody] Model.SecurityAccess securityAccess)
        {
            try
            {
                System.Guid guidId = System.Guid.NewGuid();
                DateTime startTime = DateTime.Now;
                this.Logger.LogInfo(
                    $"Controller GetMenusAccessNew Start (new menus access) - guidId : {guidId}"
                );
                //Local variable
                List<Model.MenuAccess> response = this.Service.GetMenusAccessNew(
                    securityAccess,
                    guidId
                );
                this.Logger.LogInfo(
                    $"Total Time {DateTime.Now - startTime} Controller GetMenusAccessNew End (new menus access) - guidId : {guidId}"
                );

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get module with access.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("module-access")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetModuleAccess([FromBody] Model.SecurityAccess securityAccess)
        {
            try
            {
                //Local variable
                Model.ModuleAccess response = null;
                response = this.Service.GetModuleAccess(securityAccess);

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Mobile Menus with access level.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("mobile-menus-access")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetMobileMenusAccess([FromBody] Model.SecurityAccess securityAccess)
        {
            try
            {
                System.Guid guidId = System.Guid.NewGuid();
                DateTime startTime = DateTime.Now;
                this.Logger.LogInfo(
                    $"Controller GetMobileMenusAccess Start (new mobile menus access) - guidId : {guidId}"
                );
                //Local variable
                List<Model.MobileMenuAccessList> response = this.Service.GetMobileMenusAccess(
                    securityAccess,
                    guidId
                );
                this.Logger.LogInfo(
                    $"Total Time {DateTime.Now - startTime} Controller GetMobileMenusAccess End (new mobile menus access) - guidId : {guidId}"
                );

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        /// <summary>
        /// Get Mobile Module Features Access List For That User and Module.
        /// </summary>
        /// <param name="">UserId</param>
        /// <param name="">UserRole</param>
        /// <param name="">TenantId</param>
        /// <param name="">LocationId</param>
        /// <param name="">ModuleId</param>
        /// <returns></returns>
        [HttpPost]
        [InternalUseOnly]
        [Route("mobile-module-features-access")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Exception", typeof(ApiResult))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        public IActionResult GetMobileModuleFeaturesAccess(
            [FromBody] Model.SecurityAccessWithTenantId securityAccess
        )
        {
            try
            {
                System.Guid guidId = System.Guid.NewGuid();
                DateTime startTime = DateTime.Now;
                this.Logger.LogInfo(
                    $"Controller GetMobileModuleFeaturesAccess Start (new mobile module features access) - guidId : {guidId}"
                );
                //Local variable
                List<Model.ModuleFeatureList> response = this.Service.GetMobileModuleFeaturesAccess(
                    securityAccess,
                    guidId
                );
                this.Logger.LogInfo(
                    $"Total Time {DateTime.Now - startTime} Controller GetMobileModuleFeaturesAccess End (new mobile module features access) - guidId : {guidId}"
                );

                //return module
                return StatusCode(StatusCodes.Status200OK, new ApiResult() { Data = response });
            }
            catch (KeyNotFoundException ex)
            {
                //return 404
                return StatusCode(
                    StatusCodes.Status404NotFound,
                    new ApiResult() { Exception = ex.Message }
                );
            }
            catch (System.Exception ex)
            {
                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new ApiResult() { Exception = ex.Message }
                );
            }
        }

        #endregion
    }
}
