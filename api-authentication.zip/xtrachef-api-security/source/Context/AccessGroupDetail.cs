﻿using Microsoft.EntityFrameworkCore;
using Sa.Common.WebAPI.Base.Context;

namespace XtraChef.API.Security.Query.Context
{
    public class AccessGroupDetail : ReadOnlyContext
    {
        #region Variables

        public DbSet<Model.AccessGroupDetail> UserGroupUploads { get; set; }
        public DbSet<Model.UserGroupMapping> UserGroupMappings { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Context.AccessGroupDetail"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public AccessGroupDetail(DbContextOptions<Context.AccessGroupDetail> options)
            : base(options) { }

        #endregion

        #region Model builder

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Model.AccessGroupDetail>().HasKey(k => new { k.Id });
        }

        #endregion
    }
}
