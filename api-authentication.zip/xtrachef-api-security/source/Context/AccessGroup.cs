﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Sa.Common.WebAPI.Base.Context;

namespace XtraChef.API.Security.Query.Context
{
    public class AccessGroup : ReadOnlyContext
    {
        #region Variables

        public DbSet<Model.AccessGroupDetail> AccessGroupDetails { get; set; }
        public DbSet<Model.AccessGroup> AccessGroups { get; set; }
        public DbSet<Model.ModuleFeature> ModuleFeatures { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Context.AccessGroup"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public AccessGroup(DbContextOptions<Context.AccessGroup> options)
            : base(options) { }

        #endregion

        #region Model builder

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Model.AccessGroup>().HasKey(k => new { k.Id });

            // set property for module custom category
            SetModuleProperties(modelBuilder);
        }

        #endregion

        #region Private methods

        /// <summary>
        /// set property for module custom category
        /// </summary>
        /// <param name="modelBuilder"></param>
        private static void SetModuleProperties(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Model.ModuleFeature>().HasKey(k => new { k.Pk });
        }

        #endregion
    }
}
