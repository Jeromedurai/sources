﻿using Microsoft.EntityFrameworkCore;
using Sa.Common.WebAPI.Base.Context;

namespace XtraChef.API.Security.Query.Context
{
    public class DependencyModule : ReadOnlyContext
    {
        #region Variables

        public DbSet<Model.DependencyModule> dependencyModule { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Context.Module"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public DependencyModule(DbContextOptions<Context.DependencyModule> options)
            : base(options) { }

        #endregion

        #region Model builder

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //entity property setup
            SetDependencyModuleProperties(modelBuilder);
        }

        #endregion

        #region Privete Methods

        /// <summary>
        /// Set Inoivce image properties
        /// </summary>
        /// <param name="modelBuilder"></param>
        private static void SetDependencyModuleProperties(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Model.ModuleFeature>().HasKey(m => new { m.Pk });
        }

        #endregion
    }
}
