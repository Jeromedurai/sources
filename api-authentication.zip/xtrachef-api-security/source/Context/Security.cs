﻿using Microsoft.EntityFrameworkCore;
using Sa.Common.WebAPI.Base.Context;

namespace XtraChef.API.Security.Query.Context
{
    public class Security : ReadOnlyContext
    {
        #region Context property

        public DbSet<Model.Features> Features { get; set; }
        public DbSet<Model.ModuleFeatures> moduleFeatures { get; set; }
        public DbSet<Model.ModuleFeaturesAccess> moduleFeaturesAccess { get; set; }
        public DbSet<Model.TenantPackage> tenantPackage { get; set; }
        public DbSet<Model.AccessTenantLocations> accessTenantLocations { get; set; }
        public DbSet<Model.MenuAccess> menuAccess { get; set; }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Context.Security"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public Security(DbContextOptions<Context.Security> options)
            : base(options) { }
        #endregion

        #region Overridden Methods

        /// <summary>
        /// Ons the model creating.
        /// </summary>
        /// <param name="modelBuilder">Model builder.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            // Do nothing because of modelBuilder.
        }

        #endregion
    }
}
