﻿using Microsoft.EntityFrameworkCore;
using Sa.Common.WebAPI.Base.Context;

namespace XtraChef.API.Security.Query.Context
{
    public class TenantAccessPackage : ReadOnlyContext
    {
        #region Variables

        public DbSet<Model.TenantAccessPackage> tenantAccessPackage { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Context.Module"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public TenantAccessPackage(DbContextOptions<Context.TenantAccessPackage> options)
            : base(options) { }

        #endregion

        #region PackageCode builder

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //entity property setup
            SetPackageCodeProperties(modelBuilder);
        }

        #endregion

        #region Privete Methods

        /// <summary>
        /// Set Package Code properties
        /// </summary>
        /// <param name="modelBuilder"></param>
        private static void SetPackageCodeProperties(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Model.TenantAccessPackage>().HasKey(m => new { m.Id });
        }

        #endregion
    }
}
