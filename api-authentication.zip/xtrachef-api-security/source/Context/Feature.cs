﻿using Microsoft.EntityFrameworkCore;
using Sa.Common.WebAPI.Base.Context;

namespace XtraChef.API.Security.Query.Context
{
    public class Feature : ReadOnlyContext
    {
        #region Variables

        public DbSet<Model.ModuleFeature> moduleFeature { get; private set; }
        public DbSet<Model.LocationEntityConfig> LocationEntities { get; private set; }
        public DbSet<Model.OrderGuide> OrderGuides { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Context.Feature"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public Feature(DbContextOptions<Context.Feature> options)
            : base(options) { }

        #endregion

        #region Model builder

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //entity property setup
            SetFeatureProperties(modelBuilder);
        }

        #endregion

        #region Private methods

        /// <summary>
        /// set property for feature custom category
        /// </summary>
        /// <param name="modelBuilder"></param>
        private static void SetFeatureProperties(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Model.ModuleFeature>().HasKey(f => new { f.Pk });
        }

        #endregion
    }
}
