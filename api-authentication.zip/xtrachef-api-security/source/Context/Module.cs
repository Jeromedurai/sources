﻿using Microsoft.EntityFrameworkCore;
using Sa.Common.WebAPI.Base.Context;

namespace XtraChef.API.Security.Query.Context
{
    public class Module : ReadOnlyContext
    {
        #region Variables

        public DbSet<Model.ModuleFeature> moduleFeature { get; private set; }
        public DbSet<Model.TenantPackage> tenantPackage { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:XtraChef.API.Security.Query.Context.Module"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public Module(DbContextOptions<Context.Module> options)
            : base(options) { }

        #endregion

        #region Model builder

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //entity property setup
            SetModuleProperties(modelBuilder);
        }

        #endregion

        #region Privete Methods

        /// <summary>
        /// Set Inoivce image properties
        /// </summary>
        /// <param name="modelBuilder"></param>
        private static void SetModuleProperties(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Model.ModuleFeature>().HasKey(m => new { m.Pk });
        }

        #endregion
    }
}
